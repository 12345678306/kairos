"use client"

import type { SupabaseClient } from "@supabase/supabase-js"

// Type definitions
export interface Goal {
  id: string
  userId: string
  title: string
  description?: string
  targetValue: number
  currentValue: number
  date: string
  completed: boolean
  createdAt: string
  updatedAt: string
}

export interface UserPoints {
  userId: string
  points: number
  createdAt: string
  updatedAt: string
}

// Helper function to generate a unique ID
export function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
}

// Goals storage functions
export function getGoals(userId: string): Goal[] {
  if (typeof window === "undefined") return []

  try {
    const goalsJson = localStorage.getItem(`goals_${userId}`)
    return goalsJson ? JSON.parse(goalsJson) : []
  } catch (error) {
    console.error("Error getting goals from localStorage:", error)
    return []
  }
}

export function saveGoals(userId: string, goals: Goal[]): void {
  if (typeof window === "undefined") return

  try {
    localStorage.setItem(`goals_${userId}`, JSON.stringify(goals))
  } catch (error) {
    console.error("Error saving goals to localStorage:", error)
  }
}

export function addGoal(userId: string, goal: Omit<Goal, "id" | "userId" | "createdAt" | "updatedAt">): Goal {
  const goals = getGoals(userId)

  const newGoal: Goal = {
    id: generateId(),
    userId,
    ...goal,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }

  goals.push(newGoal)
  saveGoals(userId, goals)

  return newGoal
}

export function updateGoal(userId: string, goalId: string, updates: Partial<Goal>): Goal | null {
  const goals = getGoals(userId)
  const goalIndex = goals.findIndex((g) => g.id === goalId)

  if (goalIndex === -1) return null

  const updatedGoal = {
    ...goals[goalIndex],
    ...updates,
    updatedAt: new Date().toISOString(),
  }

  goals[goalIndex] = updatedGoal
  saveGoals(userId, goals)

  return updatedGoal
}

export function deleteGoal(userId: string, goalId: string): boolean {
  const goals = getGoals(userId)
  const filteredGoals = goals.filter((g) => g.id !== goalId)

  if (filteredGoals.length === goals.length) return false

  saveGoals(userId, filteredGoals)
  return true
}

// Points management functions
export function getUserPoints(userId: string): UserPoints | null {
  if (typeof window === "undefined") return null

  try {
    const pointsJson = localStorage.getItem(`points_${userId}`)
    return pointsJson ? JSON.parse(pointsJson) : null
  } catch (error) {
    console.error("Error getting user points from localStorage:", error)
    return null
  }
}

export function saveUserPoints(userPoints: UserPoints): void {
  if (typeof window === "undefined") return

  try {
    localStorage.setItem(`points_${userPoints.userId}`, JSON.stringify(userPoints))
  } catch (error) {
    console.error("Error saving user points to localStorage:", error)
  }
}

export async function addPoints(
  userId: string | undefined,
  pointsToAdd: number,
  supabase?: SupabaseClient,
  toast?: any,
): Promise<UserPoints | null> {
  if (!userId) return null

  try {
    // Get current points from localStorage
    let userPoints = getUserPoints(userId)

    if (userPoints) {
      // Update existing points
      userPoints.points += pointsToAdd
      userPoints.updatedAt = new Date().toISOString()
    } else {
      // Create new points record
      userPoints = {
        userId,
        points: pointsToAdd,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
    }

    // Save to localStorage
    saveUserPoints(userPoints)

    // If Supabase client is provided, also update in database for backward compatibility
    if (supabase) {
      try {
        // Check if user has a points record in Supabase - don't use .single()
        const { data: pointsData, error } = await supabase
          .from("user_points")
          .select("*")
          .eq("user_id", userId)
          .order("created_at", { ascending: false })
          .limit(1)

        if (error) {
          throw error
        }

        if (pointsData && pointsData.length > 0) {
          // Update existing points in Supabase
          await supabase
            .from("user_points")
            .update({
              points: pointsData[0].points + pointsToAdd,
              updated_at: new Date().toISOString(),
            })
            .eq("id", pointsData[0].id) // Use the record's unique ID instead of user_id
        } else {
          // Create new points record in Supabase
          await supabase.from("user_points").insert({
            user_id: userId,
            points: pointsToAdd,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          })
        }
      } catch (supabaseError) {
        console.error("Error updating points in Supabase:", supabaseError)

        // Show toast notification if available
        if (toast) {
          toast({
            title: "Database Error",
            description: "Points were saved locally but couldn't be updated in the database.",
          })
        }
      }
    }

    return userPoints
  } catch (error) {
    console.error("Error adding points:", error)
    return null
  }
}

// Assignment storage functions
export interface Assignment {
  id: string
  userId: string
  title: string
  description?: string
  dueDate: string
  completed: boolean
  subject: string
  priority: "low" | "medium" | "high"
  createdAt: string
  updatedAt: string
}

export function getAssignments(userId: string): Assignment[] {
  if (typeof window === "undefined") return []

  try {
    const assignmentsJson = localStorage.getItem(`assignments_${userId}`)
    return assignmentsJson ? JSON.parse(assignmentsJson) : []
  } catch (error) {
    console.error("Error getting assignments from localStorage:", error)
    return []
  }
}

export function saveAssignments(userId: string, assignments: Assignment[]): void {
  if (typeof window === "undefined") return

  try {
    localStorage.setItem(`assignments_${userId}`, JSON.stringify(assignments))
  } catch (error) {
    console.error("Error saving assignments to localStorage:", error)
  }
}

export function addAssignment(
  userId: string,
  assignment: Omit<Assignment, "id" | "userId" | "createdAt" | "updatedAt">,
): Assignment {
  const assignments = getAssignments(userId)

  const newAssignment: Assignment = {
    id: generateId(),
    userId,
    ...assignment,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }

  assignments.push(newAssignment)
  saveAssignments(userId, assignments)

  return newAssignment
}

export function updateAssignment(
  userId: string,
  assignmentId: string,
  updates: Partial<Assignment>,
): Assignment | null {
  const assignments = getAssignments(userId)
  const assignmentIndex = assignments.findIndex((a) => a.id === assignmentId)

  if (assignmentIndex === -1) return null

  const updatedAssignment = {
    ...assignments[assignmentIndex],
    ...updates,
    updatedAt: new Date().toISOString(),
  }

  assignments[assignmentIndex] = updatedAssignment
  saveAssignments(userId, assignments)

  return updatedAssignment
}

export function deleteAssignment(userId: string, assignmentId: string): boolean {
  const assignments = getAssignments(userId)
  const filteredAssignments = assignments.filter((a) => a.id !== assignmentId)

  if (filteredAssignments.length === assignments.length) return false

  saveAssignments(userId, filteredAssignments)
  return true
}
