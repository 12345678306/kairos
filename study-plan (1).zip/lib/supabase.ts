const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://mock-supabase-url.supabase.co"
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "mock-anon-key"

// Mock query builder that supports method chaining
class MockQueryBuilder {
  private table: string
  private selectColumns = "*"
  private filters: Array<{ column: string; value: any }> = []
  private orderBy: { column: string; ascending: boolean } | null = null
  private limitCount: number | null = null
  private isSingle = false

  constructor(table: string) {
    this.table = table
  }

  select(columns = "*") {
    this.selectColumns = columns
    return this
  }

  eq(column: string, value: any) {
    this.filters.push({ column, value })
    return this
  }

  order(column: string, options: { ascending?: boolean } = {}) {
    this.orderBy = { column, ascending: options.ascending !== false }
    return this
  }

  limit(count: number) {
    this.limitCount = count
    return this
  }

  single() {
    this.isSingle = true
    return this
  }

  async then(resolve: (result: any) => void, reject?: (error: any) => void) {
    // Mock data based on table
    let mockData: any[] = []

    if (this.table === "assignments") {
      mockData = [
        {
          id: 1,
          title: "Math Homework Chapter 5",
          description: "Complete exercises 1-20 from algebra textbook",
          deadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
          completed: false,
          user_id: "mock-user-id",
          subject_id: 1,
          subjects: { name: "Mathematics", color: "#3B82F6" },
        },
        {
          id: 2,
          title: "History Essay",
          description: "Write a 1000-word essay on World War II",
          deadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(),
          completed: false,
          user_id: "mock-user-id",
          subject_id: 2,
          subjects: { name: "History", color: "#EF4444" },
        },
        {
          id: 3,
          title: "Science Lab Report",
          description: "Complete chemistry lab report on acids and bases",
          deadline: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
          completed: false,
          user_id: "mock-user-id",
          subject_id: 3,
          subjects: { name: "Chemistry", color: "#10B981" },
        },
      ]
    } else if (this.table === "subjects") {
      mockData = [
        { id: 1, name: "Mathematics", color: "#3B82F6", user_id: "mock-user-id" },
        { id: 2, name: "History", color: "#EF4444", user_id: "mock-user-id" },
        { id: 3, name: "Chemistry", color: "#10B981", user_id: "mock-user-id" },
        { id: 4, name: "English", color: "#8B5CF6", user_id: "mock-user-id" },
        { id: 5, name: "Physics", color: "#F59E0B", user_id: "mock-user-id" },
      ]
    } else if (this.table === "goals") {
      mockData = [
        {
          id: 1,
          title: "Complete all assignments on time",
          description: "Finish all homework before deadlines",
          target_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          completed: false,
          user_id: "mock-user-id",
        },
      ]
    } else if (this.table === "user_points") {
      mockData = [
        {
          id: 1,
          user_id: "mock-user-id",
          points: 150,
          created_at: new Date().toISOString(),
        },
      ]
    } else if (this.table === "rewards") {
      mockData = [
        {
          id: 1,
          name: "30 minutes of gaming",
          description: "Play your favorite video game",
          points_required: 50,
          category: "entertainment",
          duration_minutes: 30,
        },
        {
          id: 2,
          name: "Watch a movie",
          description: "Enjoy a movie of your choice",
          points_required: 100,
          category: "entertainment",
          duration_minutes: 120,
        },
      ]
    }

    // Apply filters
    let filteredData = mockData.filter((item) => {
      return this.filters.every((filter) => {
        return item[filter.column] === filter.value
      })
    })

    // Apply ordering
    if (this.orderBy) {
      filteredData.sort((a, b) => {
        const aVal = a[this.orderBy!.column]
        const bVal = b[this.orderBy!.column]

        if (aVal < bVal) return this.orderBy!.ascending ? -1 : 1
        if (aVal > bVal) return this.orderBy!.ascending ? 1 : -1
        return 0
      })
    }

    // Apply limit
    if (this.limitCount) {
      filteredData = filteredData.slice(0, this.limitCount)
    }

    const result = {
      data: this.isSingle ? filteredData[0] || null : filteredData,
      error: null,
    }

    resolve(result)
    return result
  }
}

// Mock insert/update operations
class MockInsertBuilder {
  private table: string
  private insertData: any

  constructor(table: string, data: any) {
    this.table = table
    this.insertData = data
  }

  select(columns = "*") {
    return this
  }

  single() {
    return this
  }

  async then(resolve: (result: any) => void, reject?: (error: any) => void) {
    // Generate a mock ID for the inserted data
    const mockId = Math.floor(Math.random() * 1000) + 1
    const insertedData = { ...this.insertData, id: mockId }

    const result = {
      data: insertedData,
      error: null,
    }

    resolve(result)
    return result
  }
}

class MockUpdateBuilder {
  private table: string
  private updateData: any
  private filters: Array<{ column: string; value: any }> = []

  constructor(table: string, data: any) {
    this.table = table
    this.updateData = data
  }

  eq(column: string, value: any) {
    this.filters.push({ column, value })
    return this
  }

  async then(resolve: (result: any) => void, reject?: (error: any) => void) {
    const result = {
      data: [{ ...this.updateData, id: 1 }],
      error: null,
    }

    resolve(result)
    return result
  }
}

// Mock Supabase client for development
const mockSupabaseClient = {
  auth: {
    signInWithPassword: async ({ email, password }: { email: string; password: string }) => {
      return {
        data: {
          user: {
            id: "mock-user-id",
            email: email,
            user_metadata: { name: "Test User" },
          },
          session: {
            access_token: "mock-access-token",
            refresh_token: "mock-refresh-token",
          },
        },
        error: null,
      }
    },
    signUp: async ({ email, password }: { email: string; password: string }) => {
      return {
        data: {
          user: {
            id: "mock-user-id",
            email: email,
            user_metadata: { name: "New User" },
          },
          session: null,
        },
        error: null,
      }
    },
    signOut: async () => {
      return { error: null }
    },
    getSession: async () => {
      if (typeof window !== "undefined") {
        const mockSession = localStorage.getItem("mock-session")
        if (mockSession) {
          return {
            data: {
              session: JSON.parse(mockSession),
            },
            error: null,
          }
        }
      }
      return { data: { session: null }, error: null }
    },
    onAuthStateChange: (callback: (event: string, session: any) => void) => {
      return {
        data: { subscription: { unsubscribe: () => {} } },
      }
    },
  },
  from: (table: string) => ({
    select: (columns?: string) => new MockQueryBuilder(table).select(columns),
    insert: (data: any) => new MockInsertBuilder(table, data),
    update: (data: any) => new MockUpdateBuilder(table, data),
    delete: () => ({
      eq: (column: string, value: any) =>
        Promise.resolve({
          data: [],
          error: null,
        }),
    }),
  }),
}

export const supabase = mockSupabaseClient as any
export const createBrowserClient = () => mockSupabaseClient as any
export const createServerClient = () => mockSupabaseClient as any
export const getBrowserClient = () => mockSupabaseClient as any
