import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Validate file type
    if (file.type !== "application/pdf") {
      return NextResponse.json({ error: "Only PDF files are allowed" }, { status: 400 })
    }

    // Validate file size (10MB limit)
    const maxSize = 10 * 1024 * 1024 // 10MB
    if (file.size > maxSize) {
      return NextResponse.json({ error: "File size too large. Maximum 10MB allowed." }, { status: 400 })
    }

    // Mock PDF content extraction
    const mockContent = `
    Mathematics Assignment - APC Summer 2021 Week 1a
    
    Problem Set:
    1. Solve for x: 2x + 5 = 13
    2. Factor the expression: x² - 9
    3. Simplify: (3x + 2)(x - 4)
    4. Find the slope of the line passing through (2, 3) and (5, 9)
    5. Solve the system of equations:
       2x + y = 7
       x - y = 2
    6. Calculate the area of a triangle with base 8 and height 6
    7. Convert 45° to radians
    8. Evaluate: log₂(16)
    9. Find the derivative of f(x) = 3x² + 2x - 1
    10. Solve: |2x - 3| = 7
    
    Instructions:
    - Show all work for full credit
    - Round decimal answers to 2 decimal places
    - Use proper mathematical notation
    - Submit by end of week
    `

    return NextResponse.json({
      success: true,
      content: mockContent,
      metadata: {
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type,
        extractedAt: new Date().toISOString(),
        pageCount: 2,
        wordCount: 150,
      },
    })
  } catch (error) {
    console.error("PDF extraction error:", error)
    return NextResponse.json({ error: "Failed to extract PDF content" }, { status: 500 })
  }
}
