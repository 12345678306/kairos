import { type NextRequest, NextResponse } from "next/server"

const SYSTEM_PROMPT = `You are an AI chatbot designed to assist students by breaking down assignments into manageable tasks. Follow these guidelines strictly:

1. **Criteria Fulfillment:**
   - When a user presents a new assignment, ensure they provide the following three pieces of information:
     a. **Assignment Description**: Ask the user to specify what the assignment is and the subject it pertains to.
     b. **Due Date**: Inquire about the deadline for submission.
     c. **Assignment Name**: Request the user to provide a name for the assignment.

2. **Information Gathering:**
   - If any of the three criteria are missing in the user's initial response, actively ask follow-up questions until you obtain all necessary information. Do not proceed until you have complete details.

3. **PDF Request:**
   - Once you have all three criteria, ask the user to upload a PDF of the assignment for enhanced accuracy in your analysis.

4. **Assignment Analysis:**
   - Analyze the assignment based on the user's input thoroughly. Break down the assignment into smaller, manageable tasks.

5. **Task Scheduling:**
   - Assign these broken-down tasks to different days. Present this schedule visually on a calendar format, ensuring clarity for the user to understand their timeline.

6. **Handling Changes:**
   - If the user indicates that they cannot complete a part of an assignment on a specific day, ask them to suggest an alternative day for that task.

7. **Navigating Uncertainties:**
   - In situations where you are uncertain about how to proceed, utilize your best judgment to navigate the scenario.

8. **Strict Focus:**
   - Refrain from discussing any topics outside of assignment breakdowns. If the user tries to divert the conversation, politely redirect them with a response such as: "I'm sorry, I don't have knowledge about that topic. However, I'm here to help you break down any assignments you have at school."

9. **Time Estimates (if asked):**
   - If the user requests time estimates for a specific assignment, provide a thoughtful response based on typical assignment completion times. Please give the lower end of time estimates, ones that fit the smartest of the smartest students. don't give a time range, just give the number that is at the lowest end of the range

Remember, your sole purpose is to aid students in managing their assignments effectively without deviating from this core function.`

interface AssignmentInfo {
  description?: string
  dueDate?: string
  name?: string
}

// Simple in-memory storage for conversation context
const conversationContext = new Map<string, AssignmentInfo>()

function getConversationId(messages: any[]): string {
  if (messages.length > 0) {
    return messages[0].id || "default"
  }
  return "default"
}

function extractAssignmentInfo(message: string, existingInfo: AssignmentInfo): AssignmentInfo {
  const lowerMessage = message.toLowerCase()
  const newInfo = { ...existingInfo }

  // Extract assignment description/subject
  if (!newInfo.description) {
    if (lowerMessage.includes("math") || lowerMessage.includes("algebra") || lowerMessage.includes("calculus")) {
      newInfo.description = "Mathematics assignment"
    } else if (lowerMessage.includes("english") || lowerMessage.includes("essay") || lowerMessage.includes("writing")) {
      newInfo.description = "English/Writing assignment"
    } else if (
      lowerMessage.includes("science") ||
      lowerMessage.includes("chemistry") ||
      lowerMessage.includes("physics")
    ) {
      newInfo.description = "Science assignment"
    } else if (lowerMessage.includes("history") || lowerMessage.includes("social studies")) {
      newInfo.description = "History assignment"
    }
  }

  // Extract due date
  if (!newInfo.dueDate) {
    const datePatterns = [
      /due\s+(on\s+)?([a-zA-Z]+\s+\d{1,2})/i,
      /deadline\s+(is\s+)?([a-zA-Z]+\s+\d{1,2})/i,
      /(monday|tuesday|wednesday|thursday|friday|saturday|sunday)/i,
      /(tomorrow|today|next week|this week)/i,
      /(\d{1,2}\/\d{1,2})/,
      /(january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2}/i,
    ]
    for (const pattern of datePatterns) {
      const match = message.match(pattern)
      if (match) {
        newInfo.dueDate = match[0]
        break
      }
    }
  }

  // Extract assignment name
  if (!newInfo.name) {
    const namePatterns = [
      /called\s+"([^"]+)"/i,
      /named\s+"([^"]+)"/i,
      /title\s+(is\s+)?"([^"]+)"/i,
      /(chapter\s+\d+)/i,
      /(homework\s+\d+)/i,
      /(assignment\s+\d+)/i,
    ]
    for (const pattern of namePatterns) {
      const match = message.match(pattern)
      if (match) {
        newInfo.name = match[1] || match[0]
        break
      }
    }
  }

  return newInfo
}

function isCompleteBreakdown(response: string, assignmentInfo: AssignmentInfo): boolean {
  const hasAllInfo = assignmentInfo.description && assignmentInfo.dueDate && assignmentInfo.name
  const hasBreakdownKeywords =
    response.toLowerCase().includes("breakdown") ||
    response.toLowerCase().includes("schedule") ||
    response.toLowerCase().includes("daily tasks") ||
    response.toLowerCase().includes("day 1") ||
    response.toLowerCase().includes("today") ||
    response.toLowerCase().includes("tomorrow")

  return !!(hasAllInfo && hasBreakdownKeywords && response.length > 200)
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    let userMessage = ""
    let messages = []

    if (body.messages && Array.isArray(body.messages)) {
      messages = body.messages
      const lastMessage = messages[messages.length - 1]
      userMessage = lastMessage?.content || ""
    } else if (body.message) {
      userMessage = body.message
    }

    if (!userMessage || userMessage.trim() === "") {
      return NextResponse.json({ error: "Message is required" }, { status: 400 })
    }

    const conversationId = getConversationId(messages)
    const existingInfo = conversationContext.get(conversationId) || {}
    const updatedInfo = extractAssignmentInfo(userMessage, existingInfo)
    conversationContext.set(conversationId, updatedInfo)

    const openaiApiKey = process.env.OPENAI_API_KEY
    if (!openaiApiKey) {
      return NextResponse.json({ error: "OpenAI API key is missing" }, { status: 500 })
    }

    const openaiMessages = [
      {
        role: "system",
        content: SYSTEM_PROMPT + `\n\nCurrent assignment info: ${JSON.stringify(updatedInfo)}`,
      },
    ]

    if (messages && Array.isArray(messages)) {
      for (const msg of messages) {
        if (msg.sender === "user") {
          openaiMessages.push({ role: "user", content: msg.content })
        } else if (msg.sender === "assistant" || msg.sender === "ai") {
          openaiMessages.push({ role: "assistant", content: msg.content })
        }
      }
    }

    if (body.pdfContent) {
      openaiMessages.push({
        role: "user",
        content: `Here is the PDF content for reference: ${body.pdfContent}`,
      })
    }

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${openaiApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: openaiMessages,
        max_tokens: 1000,
        temperature: 0.7,
      }),
    })

    if (!response.ok) {
      return NextResponse.json({ error: "OpenAI API request failed" }, { status: response.status })
    }

    const data = await response.json()
    const aiResponse = data.choices[0]?.message?.content || "I couldn't generate a response. Please try again."

    // Check if this is a complete assignment breakdown
    const shouldAddToSchedule = isCompleteBreakdown(aiResponse, updatedInfo)

    return NextResponse.json({
      content: aiResponse,
      message: aiResponse,
      timestamp: new Date().toISOString(),
      shouldAddToSchedule,
      assignmentInfo: shouldAddToSchedule ? updatedInfo : null,
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to process chat message" }, { status: 500 })
  }
}
