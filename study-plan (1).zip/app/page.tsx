"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Clock,
  BookOpen,
  Target,
  Calendar,
  Star,
  ArrowRight,
  CheckCircle,
  TrendingUp,
  Award,
  Shield,
  Sparkles,
} from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"
import { motion, useScroll, useTransform } from "framer-motion"
import { ScrollReveal } from "@/components/scroll-reveal"

export default function HomePage() {
  const [mounted, setMounted] = useState(false)
  const { scrollYProgress } = useScroll()
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"])

  useEffect(() => {
    setMounted(true)
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  if (!mounted) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background">
      {/* Header */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
        className="fixed top-4 left-4 right-4 z-50"
      >
        <div className="mx-auto max-w-7xl rounded-2xl border border-border/50 bg-background/80 backdrop-blur-md shadow-lg">
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 shadow-lg">
                <Clock className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-emerald-500 bg-clip-text text-transparent">
                Kairos
              </span>
            </div>

            <nav className="hidden md:flex items-center gap-8">
              <button
                onClick={() => scrollToSection("features")}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                Features
              </button>
              <button
                onClick={() => scrollToSection("how-it-works")}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                How it Works
              </button>
              <button
                onClick={() => scrollToSection("testimonials")}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                Testimonials
              </button>
              <button
                onClick={() => scrollToSection("pricing")}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                Pricing
              </button>
            </nav>

            <div className="flex items-center gap-4">
              <ThemeToggle />
              <Button variant="ghost" size="sm" asChild className="rounded-xl">
                <Link href="/login">Sign In</Link>
              </Button>
              <Button
                size="sm"
                asChild
                className="bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 text-white rounded-xl shadow-lg"
              >
                <Link href="/signup">Get Started</Link>
              </Button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-6 overflow-hidden">
        <motion.div style={{ y }} className="absolute inset-0 opacity-30">
          <div className="absolute top-20 left-10 w-72 h-72 bg-emerald-500/20 rounded-full blur-3xl" />
          <div className="absolute top-40 right-10 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl" />
          <div className="absolute bottom-20 left-1/2 w-80 h-80 bg-purple-500/20 rounded-full blur-3xl" />
        </motion.div>

        <div className="relative mx-auto max-w-7xl">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="space-y-8"
            >
              <div className="space-y-6">
                <Badge
                  variant="secondary"
                  className="px-4 py-2 text-sm font-medium bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  AI-Powered Study Management
                </Badge>

                <h1 className="text-5xl lg:text-7xl font-bold leading-tight">
                  Master Your
                  <span className="block bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-500 bg-clip-text text-transparent">
                    Study Schedule
                  </span>
                </h1>

                <p className="text-xl text-muted-foreground leading-relaxed max-w-2xl">
                  Transform your academic life with intelligent assignment tracking, automated scheduling, and
                  personalized study plans. Join thousands of students achieving their goals.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  asChild
                  className="bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 text-white rounded-xl shadow-lg text-lg px-8 py-6 h-auto"
                >
                  <Link href="/signup" className="flex items-center gap-2">
                    Start Free Today
                    <ArrowRight className="w-5 h-5" />
                  </Link>
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  asChild
                  className="rounded-xl text-lg px-8 py-6 h-auto border-2 bg-transparent"
                >
                  <Link href="#demo" className="flex items-center gap-2">
                    Watch Demo
                    <Clock className="w-5 h-5" />
                  </Link>
                </Button>
              </div>

              <div className="flex items-center gap-8 pt-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-emerald-600">50K+</div>
                  <div className="text-sm text-muted-foreground">Active Students</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-emerald-600">98%</div>
                  <div className="text-sm text-muted-foreground">Success Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-emerald-600">4.9★</div>
                  <div className="text-sm text-muted-foreground">User Rating</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ x: 50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-gradient-to-br from-card to-card/50 backdrop-blur-sm border border-border/50">
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 to-transparent" />
                <img
                  src="/student-dashboard.png"
                  alt="Kairos Dashboard Preview"
                  className="w-full h-auto relative z-10"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/20 to-transparent" />
              </div>

              {/* Floating elements */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                className="absolute -top-4 -right-4 bg-emerald-500 text-white p-3 rounded-xl shadow-lg"
              >
                <CheckCircle className="w-6 h-6" />
              </motion.div>

              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY }}
                className="absolute -bottom-4 -left-4 bg-blue-500 text-white p-3 rounded-xl shadow-lg"
              >
                <TrendingUp className="w-6 h-6" />
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <ScrollReveal>
        <section className="py-16 px-6 bg-muted/30">
          <div className="mx-auto max-w-7xl">
            <div className="text-center mb-12">
              <p className="text-muted-foreground mb-8">Trusted by students at top universities worldwide</p>
              <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
                <div className="text-2xl font-bold">Harvard</div>
                <div className="text-2xl font-bold">MIT</div>
                <div className="text-2xl font-bold">Stanford</div>
                <div className="text-2xl font-bold">Oxford</div>
                <div className="text-2xl font-bold">Cambridge</div>
                <div className="text-2xl font-bold">Yale</div>
              </div>
            </div>
          </div>
        </section>
      </ScrollReveal>

      {/* Features Section */}
      <ScrollReveal>
        <section id="features" className="py-20 px-6">
          <div className="mx-auto max-w-7xl">
            <div className="text-center mb-16">
              <Badge
                variant="secondary"
                className="mb-4 px-4 py-2 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300"
              >
                Features
              </Badge>
              <h2 className="text-4xl lg:text-5xl font-bold mb-6">
                Everything you need to
                <span className="block bg-gradient-to-r from-emerald-600 to-emerald-500 bg-clip-text text-transparent">
                  excel academically
                </span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Our comprehensive suite of tools helps you stay organized, motivated, and on track to achieve your
                academic goals.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  icon: Calendar,
                  title: "Smart Scheduling",
                  description:
                    "AI-powered calendar that automatically organizes your assignments and study sessions for optimal productivity.",
                  gradient: "from-emerald-500 to-teal-500",
                },
                {
                  icon: BookOpen,
                  title: "Assignment Tracking",
                  description:
                    "Never miss a deadline again with intelligent assignment management and progress tracking.",
                  gradient: "from-blue-500 to-cyan-500",
                },
                {
                  icon: Target,
                  title: "Goal Setting",
                  description:
                    "Set and achieve academic goals with personalized milestones and progress visualization.",
                  gradient: "from-purple-500 to-pink-500",
                },
                {
                  icon: TrendingUp,
                  title: "Progress Analytics",
                  description: "Detailed insights into your study patterns and performance to optimize your learning.",
                  gradient: "from-orange-500 to-red-500",
                },
                {
                  icon: Award,
                  title: "Reward System",
                  description: "Stay motivated with gamified achievements and rewards for completing your tasks.",
                  gradient: "from-yellow-500 to-orange-500",
                },
                {
                  icon: Shield,
                  title: "Study Streaks",
                  description: "Build consistent study habits with streak tracking and motivation boosters.",
                  gradient: "from-green-500 to-emerald-500",
                },
              ].map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ y: 50, opacity: 0 }}
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="h-full border-0 shadow-lg bg-card/50 backdrop-blur-sm hover:shadow-xl transition-all duration-300 group">
                    <CardHeader className="pb-4">
                      <div
                        className={`w-12 h-12 rounded-xl bg-gradient-to-r ${feature.gradient} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}
                      >
                        <feature.icon className="w-6 h-6 text-white" />
                      </div>
                      <CardTitle className="text-xl">{feature.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-base leading-relaxed">{feature.description}</CardDescription>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </ScrollReveal>

      {/* How It Works */}
      <ScrollReveal>
        <section id="how-it-works" className="py-20 px-6 bg-muted/30">
          <div className="mx-auto max-w-7xl">
            <div className="text-center mb-16">
              <Badge
                variant="secondary"
                className="mb-4 px-4 py-2 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300"
              >
                How It Works
              </Badge>
              <h2 className="text-4xl lg:text-5xl font-bold mb-6">
                Get started in
                <span className="block bg-gradient-to-r from-emerald-600 to-emerald-500 bg-clip-text text-transparent">
                  three simple steps
                </span>
              </h2>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  step: "01",
                  title: "Add Your Assignments",
                  description:
                    "Upload PDFs or manually input your assignments. Our AI extracts all the important details automatically.",
                  icon: BookOpen,
                },
                {
                  step: "02",
                  title: "Get Your Schedule",
                  description:
                    "Our intelligent algorithm creates a personalized study schedule based on your deadlines and preferences.",
                  icon: Calendar,
                },
                {
                  step: "03",
                  title: "Track Progress",
                  description:
                    "Monitor your progress, earn rewards, and stay motivated as you complete your academic goals.",
                  icon: Target,
                },
              ].map((step, index) => (
                <motion.div
                  key={step.step}
                  initial={{ y: 50, opacity: 0 }}
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className="text-center"
                >
                  <div className="relative mb-8">
                    <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-r from-emerald-500 to-emerald-600 flex items-center justify-center shadow-lg">
                      <step.icon className="w-8 h-8 text-white" />
                    </div>
                    <div className="absolute -top-2 -right-2 w-8 h-8 bg-emerald-100 dark:bg-emerald-900 rounded-full flex items-center justify-center text-sm font-bold text-emerald-600 dark:text-emerald-400">
                      {step.step}
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold mb-4">{step.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{step.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </ScrollReveal>

      {/* Testimonials */}
      <ScrollReveal>
        <section id="testimonials" className="py-20 px-6">
          <div className="mx-auto max-w-7xl">
            <div className="text-center mb-16">
              <Badge
                variant="secondary"
                className="mb-4 px-4 py-2 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300"
              >
                Testimonials
              </Badge>
              <h2 className="text-4xl lg:text-5xl font-bold mb-6">
                What students are
                <span className="block bg-gradient-to-r from-emerald-600 to-emerald-500 bg-clip-text text-transparent">
                  saying about us
                </span>
              </h2>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  name: "Sarah Chen",
                  role: "Computer Science Student",
                  university: "MIT",
                  content:
                    "Kairos completely transformed how I manage my coursework. My GPA improved by 0.8 points in just one semester!",
                  avatar: "/placeholder.svg?height=60&width=60",
                  improvement: "+0.8 GPA",
                  rating: 5,
                },
                {
                  name: "Marcus Johnson",
                  role: "Pre-Med Student",
                  university: "Harvard",
                  content:
                    "The AI scheduling is incredible. It knows exactly when I'm most productive and schedules my study sessions accordingly.",
                  avatar: "/placeholder.svg?height=60&width=60",
                  improvement: "95% on MCAT",
                  rating: 5,
                },
                {
                  name: "Emma Rodriguez",
                  role: "Business Major",
                  university: "Stanford",
                  content:
                    "I went from constantly stressed about deadlines to feeling completely in control of my academic life. Game changer!",
                  avatar: "/placeholder.svg?height=60&width=60",
                  improvement: "Zero missed deadlines",
                  rating: 5,
                },
              ].map((testimonial, index) => (
                <motion.div
                  key={testimonial.name}
                  initial={{ y: 50, opacity: 0 }}
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="h-full border-0 shadow-lg bg-card/50 backdrop-blur-sm">
                    <CardHeader className="pb-4">
                      <div className="flex items-center gap-4 mb-4">
                        <img
                          src={testimonial.avatar || "/placeholder.svg"}
                          alt={testimonial.name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <div>
                          <div className="font-semibold">{testimonial.name}</div>
                          <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                          <div className="text-xs text-emerald-600 font-medium">{testimonial.university}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 mb-2">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground leading-relaxed mb-4">"{testimonial.content}"</p>
                      <Badge
                        variant="secondary"
                        className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300"
                      >
                        <TrendingUp className="w-3 h-3 mr-1" />
                        {testimonial.improvement}
                      </Badge>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </ScrollReveal>

      {/* Pricing */}
      <ScrollReveal>
        <section id="pricing" className="py-20 px-6 bg-muted/30">
          <div className="mx-auto max-w-7xl">
            <div className="text-center mb-16">
              <Badge
                variant="secondary"
                className="mb-4 px-4 py-2 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300"
              >
                Pricing
              </Badge>
              <h2 className="text-4xl lg:text-5xl font-bold mb-6">
                Choose your
                <span className="block bg-gradient-to-r from-emerald-600 to-emerald-500 bg-clip-text text-transparent">
                  perfect plan
                </span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Start free and upgrade as you grow. All plans include our core features with no hidden fees.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              {[
                {
                  name: "Free",
                  price: "$0",
                  period: "forever",
                  description: "Perfect for getting started",
                  features: ["Up to 10 assignments", "Basic scheduling", "Progress tracking", "Mobile app access"],
                  cta: "Get Started",
                  popular: false,
                },
                {
                  name: "Student",
                  price: "$9",
                  period: "per month",
                  description: "Everything you need to excel",
                  features: [
                    "Unlimited assignments",
                    "AI-powered scheduling",
                    "Advanced analytics",
                    "PDF assignment reader",
                    "Priority support",
                    "Study streak rewards",
                  ],
                  cta: "Start Free Trial",
                  popular: true,
                },
                {
                  name: "Premium",
                  price: "$19",
                  period: "per month",
                  description: "For serious academic achievers",
                  features: [
                    "Everything in Student",
                    "Custom study plans",
                    "1-on-1 coaching sessions",
                    "Advanced integrations",
                    "Team collaboration",
                    "Priority feature requests",
                  ],
                  cta: "Start Free Trial",
                  popular: false,
                },
              ].map((plan, index) => (
                <motion.div
                  key={plan.name}
                  initial={{ y: 50, opacity: 0 }}
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="relative"
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-gradient-to-r from-emerald-600 to-emerald-500 text-white px-4 py-1">
                        Most Popular
                      </Badge>
                    </div>
                  )}
                  <Card
                    className={`h-full border-0 shadow-lg bg-card/50 backdrop-blur-sm ${plan.popular ? "ring-2 ring-emerald-500 scale-105" : ""}`}
                  >
                    <CardHeader className="text-center pb-8">
                      <CardTitle className="text-2xl mb-2">{plan.name}</CardTitle>
                      <div className="mb-4">
                        <span className="text-4xl font-bold">{plan.price}</span>
                        <span className="text-muted-foreground">/{plan.period}</span>
                      </div>
                      <CardDescription className="text-base">{plan.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <ul className="space-y-3">
                        {plan.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-center gap-3">
                            <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                            <span className="text-sm">{feature}</span>
                          </li>
                        ))}
                      </ul>
                      <Button
                        className={`w-full ${
                          plan.popular
                            ? "bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 text-white"
                            : "variant-outline"
                        } rounded-xl`}
                        asChild
                      >
                        <Link href="/signup">{plan.cta}</Link>
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </ScrollReveal>

      {/* CTA Section */}
      <ScrollReveal>
        <section className="py-20 px-6">
          <div className="mx-auto max-w-4xl text-center">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="bg-gradient-to-r from-emerald-600 to-emerald-500 rounded-3xl p-12 text-white relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-600/90 to-emerald-500/90" />
              <div className="relative z-10">
                <h2 className="text-4xl lg:text-5xl font-bold mb-6">Ready to transform your academic life?</h2>
                <p className="text-xl mb-8 text-emerald-100">
                  Join thousands of students who have already improved their grades and reduced their stress.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button
                    size="lg"
                    variant="secondary"
                    asChild
                    className="bg-white text-emerald-600 hover:bg-gray-100 rounded-xl text-lg px-8 py-6 h-auto"
                  >
                    <Link href="/signup" className="flex items-center gap-2">
                      Start Your Free Trial
                      <ArrowRight className="w-5 h-5" />
                    </Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    asChild
                    className="border-white text-white hover:bg-white/10 rounded-xl text-lg px-8 py-6 h-auto bg-transparent"
                  >
                    <Link href="#demo">Watch Demo</Link>
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      </ScrollReveal>

      {/* Footer */}
      <footer className="bg-muted/50 py-12 px-6">
        <div className="mx-auto max-w-7xl">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-600">
                  <Clock className="h-5 w-5 text-white" />
                </div>
                <span className="text-xl font-bold">Kairos</span>
              </div>
              <p className="text-muted-foreground">
                Empowering students to achieve academic excellence through intelligent study management.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="#features" className="hover:text-foreground transition-colors">
                    Features
                  </Link>
                </li>
                <li>
                  <Link href="#pricing" className="hover:text-foreground transition-colors">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="/login" className="hover:text-foreground transition-colors">
                    Sign In
                  </Link>
                </li>
                <li>
                  <Link href="/signup" className="hover:text-foreground transition-colors">
                    Sign Up
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Connect</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Twitter
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    LinkedIn
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Instagram
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-foreground transition-colors">
                    Discord
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-muted-foreground text-sm">© {new Date().getFullYear()} Kairos. All rights reserved.</p>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>Made with ❤️ for students worldwide</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
