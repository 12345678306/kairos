"use server"

import { createServerActionClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { revalidatePath } from "next/cache"
import { z } from "zod"

const assignmentSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  due_date: z.string().min(1, "Due date is required"),
  course_id: z.string().uuid("Invalid course ID"),
  priority: z.enum(["low", "medium", "high"]).default("medium"),
})

export async function createAssignment(formData: FormData) {
  const supabase = createServerActionClient({ cookies })

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    return { error: "Not authenticated" }
  }

  const rawData = {
    title: formData.get("title") as string,
    description: formData.get("description") as string,
    due_date: formData.get("due_date") as string,
    course_id: formData.get("course_id") as string,
    priority: (formData.get("priority") as string) || "medium",
  }

  const validatedData = assignmentSchema.safeParse(rawData)

  if (!validatedData.success) {
    return { error: validatedData.error.errors[0].message }
  }

  const { title, description, due_date, course_id, priority } = validatedData.data

  // Fix date handling - ensure we're using the correct format and timezone
  // Parse the date string and create a Date object with time set to end of day
  const dueDate = new Date(due_date)
  dueDate.setHours(23, 59, 59, 999) // Set to end of day
  // Format as ISO string for database storage
  const formattedDueDate = dueDate.toISOString()

  const { data, error } = await supabase
    .from("assignments")
    .insert({
      title,
      description,
      due_date: formattedDueDate, // Use the formatted date
      course_id,
      user_id: user.id,
      priority,
      completed: false,
    })
    .select()

  if (error) {
    return { error: error.message }
  }

  revalidatePath("/dashboard/assignments")
  return { success: true, data }
}

// Other existing functions...
