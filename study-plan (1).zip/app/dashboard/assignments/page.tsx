"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { getBrowserClient } from "@/lib/supabase"
import { useAuth } from "@/context/auth-context"
import { useToast } from "@/components/ui/use-toast"
import type { Database } from "@/types/supabase"
import {
  Plus,
  Search,
  Filter,
  BookOpen,
  Calendar,
  Clock,
  CheckCircle,
  AlertCircle,
  Trash2,
  Edit,
  MoreHorizontal,
} from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Assignment = Database["public"]["Tables"]["assignments"]["Row"]

// Animation variants
const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4, ease: "easeOut" },
}

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.05,
    },
  },
}

export default function AssignmentsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [assignments, setAssignments] = useState<Assignment[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const supabase = getBrowserClient()

  // Form state
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [deadline, setDeadline] = useState("")
  const [size, setSize] = useState("Medium")
  const [subjectId, setSubjectId] = useState("")

  useEffect(() => {
    fetchAssignments()
  }, [user])

  const fetchAssignments = async () => {
    if (!user) return

    setIsLoading(true)
    const { data, error } = await supabase
      .from("assignments")
      .select("*")
      .eq("user_id", user.id)
      .order("deadline", { ascending: true })

    if (error) {
      console.error("Error fetching assignments:", error)
      toast({
        title: "Error",
        description: "Failed to load assignments. Please try again.",
        variant: "destructive",
      })
    } else {
      setAssignments(data || [])
    }
    setIsLoading(false)
  }

  const handleAddAssignment = async () => {
    if (!user || !title || !deadline) return

    try {
      const { data, error } = await supabase
        .from("assignments")
        .insert({
          user_id: user.id,
          title,
          description,
          deadline,
          size,
          subject_id: subjectId || null,
          completed: false,
        })
        .select()
        .single()

      if (error) throw error

      setAssignments((prev) => [...prev, data])
      setIsAddDialogOpen(false)
      resetForm()

      toast({
        title: "Assignment Added",
        description: "Your assignment has been added successfully.",
      })
    } catch (error) {
      console.error("Error adding assignment:", error)
      toast({
        title: "Error",
        description: "Failed to add assignment. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleToggleComplete = async (assignment: Assignment) => {
    try {
      const { error } = await supabase
        .from("assignments")
        .update({ completed: !assignment.completed })
        .eq("id", assignment.id)

      if (error) throw error

      setAssignments((prev) => prev.map((a) => (a.id === assignment.id ? { ...a, completed: !a.completed } : a)))

      toast({
        title: assignment.completed ? "Assignment Reopened" : "Assignment Completed",
        description: assignment.completed
          ? "Assignment marked as incomplete."
          : "Great job! Assignment marked as complete.",
      })
    } catch (error) {
      console.error("Error updating assignment:", error)
      toast({
        title: "Error",
        description: "Failed to update assignment. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteAssignment = async (id: string) => {
    try {
      const { error } = await supabase.from("assignments").delete().eq("id", id)

      if (error) throw error

      setAssignments((prev) => prev.filter((a) => a.id !== id))

      toast({
        title: "Assignment Deleted",
        description: "Assignment has been deleted successfully.",
      })
    } catch (error) {
      console.error("Error deleting assignment:", error)
      toast({
        title: "Error",
        description: "Failed to delete assignment. Please try again.",
        variant: "destructive",
      })
    }
  }

  const resetForm = () => {
    setTitle("")
    setDescription("")
    setDeadline("")
    setSize("Medium")
    setSubjectId("")
  }

  const filteredAssignments = assignments.filter((assignment) => {
    const matchesSearch = assignment.title.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter =
      filterStatus === "all" ||
      (filterStatus === "completed" && assignment.completed) ||
      (filterStatus === "pending" && !assignment.completed)

    return matchesSearch && matchesFilter
  })

  const getSizeColor = (size: string) => {
    switch (size) {
      case "Large":
        return "bg-red-500/20 text-red-400 border-red-500/50"
      case "Medium":
        return "bg-amber-500/20 text-amber-400 border-amber-500/50"
      case "Small":
        return "bg-emerald-500/20 text-emerald-400 border-emerald-500/50"
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/50"
    }
  }

  const getUrgencyLevel = (deadline: string) => {
    const now = new Date()
    const dueDate = new Date(deadline)
    const diffTime = dueDate.getTime() - now.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))

    if (diffDays < 0) return { level: "overdue", color: "text-red-400", icon: AlertCircle }
    if (diffDays <= 1) return { level: "urgent", color: "text-red-400", icon: AlertCircle }
    if (diffDays <= 3) return { level: "soon", color: "text-amber-400", icon: Clock }
    return { level: "normal", color: "text-gray-400", icon: Calendar }
  }

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <motion.div
        className="bg-gradient-to-r from-blue-600/10 via-blue-500/10 to-blue-400/10 rounded-3xl p-8 border border-blue-500/20"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
          <div>
            <motion.h1
              className="text-4xl font-bold text-white mb-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              Assignments
            </motion.h1>
            <motion.p
              className="text-gray-400 text-lg"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              Manage your academic workload and track your progress
            </motion.p>
          </div>
          <motion.div
            className="mt-4 md:mt-0"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg hover:shadow-emerald-500/25 transition-all duration-300">
                  <Plus className="mr-2 h-4 w-4" />
                  New Assignment
                </Button>
              </DialogTrigger>
              <DialogContent className="border-gray-700 bg-gray-800 text-white max-w-md">
                <DialogHeader>
                  <DialogTitle>Add New Assignment</DialogTitle>
                  <DialogDescription className="text-gray-400">
                    Create a new assignment to track your progress.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="title" className="text-gray-300">
                      Title
                    </Label>
                    <Input
                      id="title"
                      placeholder="Enter assignment title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="border-gray-700 bg-gray-900 text-white"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="description" className="text-gray-300">
                      Description (Optional)
                    </Label>
                    <Textarea
                      id="description"
                      placeholder="Enter assignment description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="border-gray-700 bg-gray-900 text-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="deadline" className="text-gray-300">
                        Deadline
                      </Label>
                      <Input
                        id="deadline"
                        type="datetime-local"
                        value={deadline}
                        onChange={(e) => setDeadline(e.target.value)}
                        className="border-gray-700 bg-gray-900 text-white"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="size" className="text-gray-300">
                        Size
                      </Label>
                      <Select value={size} onValueChange={setSize}>
                        <SelectTrigger className="border-gray-700 bg-gray-900 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="border-gray-700 bg-gray-800">
                          <SelectItem value="Small">Small</SelectItem>
                          <SelectItem value="Medium">Medium</SelectItem>
                          <SelectItem value="Large">Large</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="subject" className="text-gray-300">
                      Subject (Optional)
                    </Label>
                    <Input
                      id="subject"
                      placeholder="Enter subject"
                      value={subjectId}
                      onChange={(e) => setSubjectId(e.target.value)}
                      className="border-gray-700 bg-gray-900 text-white"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsAddDialogOpen(false)
                      resetForm()
                    }}
                    className="border-gray-700 bg-gray-900 text-white hover:bg-gray-800"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    onClick={handleAddAssignment}
                    disabled={!title || !deadline}
                    className="bg-emerald-600 text-white hover:bg-emerald-700"
                  >
                    Add Assignment
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </motion.div>
        </div>
      </motion.div>

      {/* Search and Filter Section */}
      <motion.div
        className="flex flex-col md:flex-row gap-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search assignments..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 border-gray-700 bg-gray-800 text-white"
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full md:w-48 border-gray-700 bg-gray-800 text-white">
            <Filter className="mr-2 h-4 w-4" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="border-gray-700 bg-gray-800">
            <SelectItem value="all">All Assignments</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
          </SelectContent>
        </Select>
      </motion.div>

      {/* Assignments Grid */}
      {isLoading ? (
        <div className="flex h-64 items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-t-emerald-500"></div>
        </div>
      ) : filteredAssignments.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm">
            <CardContent className="flex h-64 flex-col items-center justify-center p-6 text-center">
              <BookOpen className="mb-4 h-12 w-12 text-gray-500" />
              <h3 className="mb-2 text-xl font-semibold text-white">No Assignments Found</h3>
              <p className="mb-4 text-gray-400">
                {searchTerm || filterStatus !== "all"
                  ? "Try adjusting your search or filter criteria."
                  : "Create your first assignment to get started."}
              </p>
              {!searchTerm && filterStatus === "all" && (
                <Button
                  className="bg-emerald-600 text-white hover:bg-emerald-700"
                  onClick={() => setIsAddDialogOpen(true)}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Create Assignment
                </Button>
              )}
            </CardContent>
          </Card>
        </motion.div>
      ) : (
        <motion.div
          className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          variants={staggerContainer}
          initial="initial"
          animate="animate"
        >
          {filteredAssignments.map((assignment, index) => {
            const urgency = getUrgencyLevel(assignment.deadline)
            const UrgencyIcon = urgency.icon

            return (
              <motion.div
                key={assignment.id}
                variants={fadeInUp}
                whileHover={{ y: -4, scale: 1.02 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
              >
                <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm hover:border-emerald-600/50 transition-all duration-300 group">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle
                          className={`text-white group-hover:text-emerald-400 transition-colors ${assignment.completed ? "line-through opacity-60" : ""}`}
                        >
                          {assignment.title}
                        </CardTitle>
                        <div className="flex items-center gap-2 mt-2">
                          <UrgencyIcon className={`h-4 w-4 ${urgency.color}`} />
                          <span className={`text-sm ${urgency.color}`}>
                            {new Date(assignment.deadline).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-white">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="border-gray-700 bg-gray-800">
                          <DropdownMenuItem
                            onClick={() => handleToggleComplete(assignment)}
                            className="text-white hover:bg-gray-700"
                          >
                            {assignment.completed ? (
                              <>
                                <AlertCircle className="mr-2 h-4 w-4" />
                                Mark Incomplete
                              </>
                            ) : (
                              <>
                                <CheckCircle className="mr-2 h-4 w-4" />
                                Mark Complete
                              </>
                            )}
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-white hover:bg-gray-700">
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => handleDeleteAssignment(assignment.id)}
                            className="text-red-400 hover:bg-red-900/20"
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {assignment.description && (
                      <p className="text-sm text-gray-300 mb-4 line-clamp-2">{assignment.description}</p>
                    )}
                    <div className="flex items-center justify-between">
                      <Badge className={getSizeColor(assignment.size)}>{assignment.size}</Badge>
                      {assignment.completed && (
                        <div className="flex items-center text-emerald-400">
                          <CheckCircle className="h-4 w-4 mr-1" />
                          <span className="text-xs font-medium">Completed</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </motion.div>
      )}
    </div>
  )
}
