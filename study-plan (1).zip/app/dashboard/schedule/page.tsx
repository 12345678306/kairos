"use client"

import { useState, useEffect } from "react"
import { getBrowserClient } from "@/lib/supabase"
import { useAuth } from "@/context/auth-context"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  CheckCircle,
  Clock,
  Calendar,
  BookOpen,
  Target,
  Zap,
  Star,
  ChevronLeft,
  ChevronRight,
  Plus,
} from "lucide-react"
import { motion } from "framer-motion"

export default function SchedulePage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [assignments, setAssignments] = useState([])
  const [tasks, setTasks] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [currentDate, setCurrentDate] = useState(new Date())
  const [completedTasks, setCompletedTasks] = useState(new Set())
  const supabase = getBrowserClient()

  const fetchData = async () => {
    if (!user) return

    try {
      const { data: assignmentsData } = await supabase
        .from("assignments")
        .select(`
          *,
          subjects (name, color)
        `)
        .eq("user_id", user.id)
        .eq("completed", false)
        .order("deadline", { ascending: true })

      setAssignments(assignmentsData || [])

      const generatedTasks = []
      for (const assignment of assignmentsData || []) {
        const assignmentTasks = generateProgressiveTasks(assignment)
        generatedTasks.push(...assignmentTasks)
      }

      setTasks(generatedTasks)
    } catch (error) {
      console.error("Error fetching data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [user])

  const generateProgressiveTasks = (assignment) => {
    const now = new Date()
    const deadline = new Date(assignment.deadline)
    const daysLeft = Math.max(1, Math.ceil((deadline - now) / (1000 * 60 * 60 * 24)))

    let taskTypes = []

    if (daysLeft === 1) {
      taskTypes = [{ name: "Complete assignment", duration: 120, type: "final" }]
    } else if (daysLeft === 2) {
      taskTypes = [
        { name: "Review and start", duration: 90, type: "start" },
        { name: "Complete and finalize", duration: 60, type: "finish" },
      ]
    } else {
      if (assignment.description?.toLowerCase().includes("test")) {
        taskTypes = [
          { name: "Review notes", duration: 45, type: "review" },
          { name: "Create study guide", duration: 60, type: "study" },
          { name: "Practice problems", duration: 75, type: "practice" },
          { name: "Final review", duration: 30, type: "final" },
        ]
      } else if (assignment.description?.toLowerCase().includes("essay")) {
        taskTypes = [
          { name: "Research and outline", duration: 60, type: "research" },
          { name: "Write first draft", duration: 90, type: "draft" },
          { name: "Revise and edit", duration: 45, type: "revise" },
          { name: "Final proofread", duration: 30, type: "final" },
        ]
      } else {
        taskTypes = [
          { name: "Start assignment", duration: 60, type: "start" },
          { name: "Continue work", duration: 60, type: "continue" },
          { name: "Complete assignment", duration: 45, type: "complete" },
        ]
      }
    }

    const tasksWithDates = []
    const startDate = new Date(now)
    const daysBetween = Math.max(1, daysLeft - 1)

    taskTypes.forEach((taskType, index) => {
      const taskDate = new Date(startDate)
      const dayOffset = Math.floor((index / taskTypes.length) * daysBetween)
      taskDate.setDate(startDate.getDate() + dayOffset)

      tasksWithDates.push({
        id: `${assignment.id}-${index}`,
        assignmentId: assignment.id,
        assignmentTitle: assignment.title,
        subject: assignment.subjects?.name || "General",
        subjectColor: assignment.subjects?.color || "#60A5FA",
        name: taskType.name,
        duration: taskType.duration,
        type: taskType.type,
        order: index,
        completed: completedTasks.has(`${assignment.id}-${index}`),
        available: index === 0 || completedTasks.has(`${assignment.id}-${index - 1}`),
        deadline: assignment.deadline,
        scheduledDate: taskDate.toISOString().split("T")[0],
      })
    })

    return tasksWithDates
  }

  const completeTask = async (taskId) => {
    try {
      const newCompletedTasks = new Set(completedTasks)
      newCompletedTasks.add(taskId)
      setCompletedTasks(newCompletedTasks)

      setTasks((prev) =>
        prev.map((task) => {
          if (task.id === taskId) {
            return { ...task, completed: true }
          }
          const currentTask = prev.find((t) => t.id === taskId)
          if (task.assignmentId === currentTask?.assignmentId && task.order === currentTask?.order + 1) {
            return { ...task, available: true }
          }
          return task
        }),
      )

      toast({
        title: "Task Completed! 🎉",
        description: "Great job! Keep up the momentum.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to complete task",
        variant: "destructive",
      })
    }
  }

  const completeAssignment = async (assignmentId) => {
    try {
      await supabase.from("assignments").update({ completed: true }).eq("id", assignmentId)

      setAssignments((prev) => prev.filter((a) => a.id !== assignmentId))
      setTasks((prev) => prev.filter((t) => t.assignmentId !== assignmentId))

      toast({
        title: "Assignment Completed! 🎉",
        description: "Assignment marked as complete and removed from schedule.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to complete assignment",
        variant: "destructive",
      })
    }
  }

  const formatDuration = (minutes) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    if (hours > 0) {
      return `${hours}h ${mins > 0 ? `${mins}m` : ""}`
    }
    return `${mins}m`
  }

  const formatDate = (date) => {
    const today = new Date()
    const tomorrow = new Date(today)
    tomorrow.setDate(today.getDate() + 1)

    if (date.toDateString() === today.toDateString()) {
      return "Today"
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return "Tomorrow"
    } else {
      return date.toLocaleDateString("en-US", {
        weekday: "long",
        month: "short",
        day: "numeric",
      })
    }
  }

  const navigateDate = (direction) => {
    const newDate = new Date(currentDate)
    newDate.setDate(currentDate.getDate() + direction)
    setCurrentDate(newDate)
  }

  const currentDateString = currentDate.toISOString().split("T")[0]
  const todaysTasks = tasks.filter((task) => task.scheduledDate === currentDateString)

  const tasksByAssignment = todaysTasks.reduce((acc, task) => {
    if (!acc[task.assignmentId]) {
      const assignment = assignments.find((a) => a.id === task.assignmentId)
      acc[task.assignmentId] = {
        assignment,
        tasks: [],
      }
    }
    acc[task.assignmentId].tasks.push(task)
    return acc
  }, {})

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-48">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-4 border-primary/30 border-t-primary mx-auto"></div>
          <p className="mt-3 text-muted-foreground text-sm">Loading your schedule...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto p-4 space-y-6">
      {/* Header with Date Navigation */}
      <div className="text-center space-y-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold flex items-center justify-center gap-3">
            <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center">
              <Calendar className="h-5 w-5 text-white" />
            </div>
            Daily Schedule
          </h1>
          <p className="text-muted-foreground">Your personalized study plan</p>
        </div>

        {/* Date Navigation */}
        <div className="flex items-center justify-center gap-4">
          <Button variant="outline" size="sm" onClick={() => navigateDate(-1)} className="h-8 w-8 p-0">
            <ChevronLeft className="h-4 w-4" />
          </Button>

          <div className="text-center min-w-[200px]">
            <h2 className="text-xl font-bold">{formatDate(currentDate)}</h2>
            <p className="text-xs text-muted-foreground">
              {currentDate.toLocaleDateString("en-US", {
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </p>
          </div>

          <Button variant="outline" size="sm" onClick={() => navigateDate(1)} className="h-8 w-8 p-0">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        {/* Stats */}
        <div className="flex justify-center gap-4">
          <Badge variant="outline" className="text-xs px-3 py-1">
            <Target className="h-3 w-3 mr-1" />
            {todaysTasks.length} tasks today
          </Badge>
          <Badge variant="outline" className="text-xs px-3 py-1">
            <Zap className="h-3 w-3 mr-1" />
            {todaysTasks.filter((t) => t.available && !t.completed).length} ready
          </Badge>
        </div>
      </div>

      {/* Quick Navigation */}
      <div className="flex justify-center">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {[-1, 0, 1, 2, 3, 4, 5].map((offset) => {
            const date = new Date(currentDate)
            date.setDate(currentDate.getDate() + offset - 1)
            const isSelected = offset === 1
            const tasksForDate = tasks.filter((task) => task.scheduledDate === date.toISOString().split("T")[0])

            return (
              <Button
                key={offset}
                variant={isSelected ? "default" : "outline"}
                size="sm"
                onClick={() => setCurrentDate(date)}
                className={`min-w-[80px] flex-col h-14 ${isSelected ? "bg-gradient-to-r from-primary to-primary/80" : ""}`}
              >
                <div className="text-xs opacity-70">{date.toLocaleDateString("en-US", { weekday: "short" })}</div>
                <div className="font-bold">{date.getDate()}</div>
                {tasksForDate.length > 0 && <div className="text-xs opacity-70">{tasksForDate.length}</div>}
              </Button>
            )
          })}
        </div>
      </div>

      {/* Today's Tasks */}
      {Object.keys(tasksByAssignment).length === 0 ? (
        <Card className="border-0 shadow-xl">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="h-16 w-16 rounded-full bg-gradient-to-br from-emerald-500/20 to-emerald-600/20 flex items-center justify-center mb-4">
              <CheckCircle className="h-8 w-8 text-emerald-500" />
            </div>
            <h3 className="text-xl font-bold mb-2">No tasks scheduled!</h3>
            <p className="text-muted-foreground text-center max-w-md mb-4">
              {formatDate(currentDate) === "Today"
                ? "You're all caught up for today. Great job!"
                : `No tasks scheduled for ${formatDate(currentDate)}.`}
            </p>
            <Button className="bg-gradient-to-r from-primary to-primary/80" asChild>
              <a href="/dashboard/assignments">
                <Plus className="h-4 w-4 mr-2" />
                Create New Assignment
              </a>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {Object.values(tasksByAssignment).map(({ assignment, tasks: assignmentTasks }, index) => {
            const completedTasksCount = assignmentTasks.filter((t) => t.completed).length
            const totalTasksCount = assignmentTasks.length
            const progress = totalTasksCount > 0 ? Math.round((completedTasksCount / totalTasksCount) * 100) : 0

            return (
              <motion.div
                key={assignment.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center"
                          style={{ backgroundColor: `${assignment.subjects?.color || "#60A5FA"}20` }}
                        >
                          <BookOpen className="h-5 w-5" style={{ color: assignment.subjects?.color || "#60A5FA" }} />
                        </div>
                        <div className="space-y-1">
                          <CardTitle className="text-lg">{assignment.title}</CardTitle>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <div
                                className="w-2 h-2 rounded-full"
                                style={{ backgroundColor: assignment.subjects?.color || "#60A5FA" }}
                              />
                              <span>{assignment.subjects?.name || "General"}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              <span>Due {new Date(assignment.deadline).toLocaleDateString()}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Star className="h-3 w-3" />
                              <span>
                                {completedTasksCount}/{totalTasksCount} tasks
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className="text-xl font-bold">{progress}%</div>
                          <div className="text-xs text-muted-foreground">Complete</div>
                        </div>
                        {progress === 100 && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => completeAssignment(assignment.id)}
                            className="hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-700 dark:hover:bg-emerald-900/20"
                          >
                            Mark Complete
                          </Button>
                        )}
                      </div>
                    </div>

                    {/* Progress bar */}
                    <div className="w-full bg-muted rounded-full h-2 mt-3">
                      <div
                        className="bg-gradient-to-r from-primary to-primary/80 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </CardHeader>

                  <CardContent className="p-4">
                    <div className="space-y-3">
                      {assignmentTasks.map((task, taskIndex) => (
                        <motion.div
                          key={task.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1 + taskIndex * 0.05 }}
                          className={`flex items-center justify-between p-4 rounded-xl border transition-all duration-300 ${
                            task.completed
                              ? "bg-emerald-50 border-emerald-200 dark:bg-emerald-900/20 dark:border-emerald-800"
                              : task.available
                                ? "bg-background border-primary/20 hover:border-primary/40 hover:shadow-md"
                                : "bg-muted/50 border-muted"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div className="relative">
                              <div
                                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                                  task.completed
                                    ? "bg-emerald-500 shadow-lg shadow-emerald-500/30"
                                    : task.available
                                      ? "bg-primary shadow-lg shadow-primary/30"
                                      : "bg-muted-foreground/30"
                                }`}
                              />
                              {task.completed && (
                                <CheckCircle className="absolute -top-1 -left-1 h-5 w-5 text-emerald-500" />
                              )}
                            </div>
                            <div className="space-y-1">
                              <p
                                className={`font-semibold text-sm ${task.completed ? "line-through text-muted-foreground" : ""}`}
                              >
                                {task.name}
                              </p>
                              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                                <div className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  <span>{formatDuration(task.duration)}</span>
                                </div>
                                {!task.available && !task.completed && (
                                  <span className="text-xs bg-amber-100 text-amber-700 px-2 py-1 rounded-full dark:bg-amber-900/20 dark:text-amber-400">
                                    Complete previous task to unlock
                                  </span>
                                )}
                                {task.available && !task.completed && (
                                  <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">
                                    Ready to start
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            {task.available && !task.completed && (
                              <Button
                                size="sm"
                                onClick={() => completeTask(task.id)}
                                className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
                              >
                                Complete
                              </Button>
                            )}
                            {task.completed && (
                              <Badge
                                variant="secondary"
                                className="text-xs bg-emerald-100 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400"
                              >
                                ✓ Done
                              </Badge>
                            )}
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </div>
      )}
    </div>
  )
}
