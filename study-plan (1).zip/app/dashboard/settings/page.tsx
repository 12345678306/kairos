"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { CustomizationPanel } from "@/components/customization-panel"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Bell, Clock, User } from "lucide-react"
import { motion } from "framer-motion"
import { useToast } from "@/components/ui/use-toast"

// Define settings interface
interface UserSettings {
  studyHours: number
  notifications: boolean
  deadlineReminders: boolean
  studyReminders: boolean
}

// Default settings
const defaultSettings: UserSettings = {
  studyHours: 4,
  notifications: true,
  deadlineReminders: true,
  studyReminders: true,
}

export default function SettingsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [settings, setSettings] = useState<UserSettings>(defaultSettings)
  const [isSaving, setIsSaving] = useState(false)

  // Load settings from localStorage on component mount
  useEffect(() => {
    if (!user) return

    try {
      const savedSettings = localStorage.getItem(`settings_${user.id}`)
      if (savedSettings) {
        setSettings(JSON.parse(savedSettings))
      }
    } catch (error) {
      console.error("Error loading settings:", error)
    }
  }, [user])

  // Save settings to localStorage whenever they change
  const saveSettings = (newSettings: UserSettings) => {
    if (!user) return

    setIsSaving(true)

    try {
      localStorage.setItem(`settings_${user.id}`, JSON.stringify(newSettings))

      // Show success toast
      toast({
        title: "Settings saved",
        description: "Your preferences have been updated.",
      })
    } catch (error) {
      console.error("Error saving settings:", error)

      // Show error toast
      toast({
        title: "Error saving settings",
        description: "There was a problem saving your preferences.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  // Update a specific setting and save all settings
  const updateSetting = <K extends keyof UserSettings>(key: K, value: UserSettings[K]) => {
    const newSettings = { ...settings, [key]: value }
    setSettings(newSettings)
    saveSettings(newSettings)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white">Settings</h1>
        <p className="text-gray-400">Customize your study experience</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="md:col-span-2 lg:col-span-1"
        >
          <CustomizationPanel />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
        >
          <Card className="border-gray-700 bg-gray-800 shadow-xl">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-emerald-500" />
                <CardTitle className="text-white">Study Time</CardTitle>
              </div>
              <CardDescription>Set your daily study hour target</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="study-hours" className="text-white">
                      Daily Study Hours
                    </Label>
                    <span className="text-sm font-medium text-emerald-500">{settings.studyHours} hours</span>
                  </div>
                  <Slider
                    id="study-hours"
                    min={1}
                    max={12}
                    step={0.5}
                    value={[settings.studyHours]}
                    onValueChange={(value) => updateSetting("studyHours", value[0])}
                    className="py-4"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
        >
          <Card className="border-gray-700 bg-gray-800 shadow-xl">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-blue-500" />
                <CardTitle className="text-white">Notifications</CardTitle>
              </div>
              <CardDescription>Manage your notification preferences</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="notifications" className="text-white">
                    Enable Notifications
                  </Label>
                  <Switch
                    id="notifications"
                    checked={settings.notifications}
                    onCheckedChange={(checked) => updateSetting("notifications", checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="deadline-reminders" className="text-white">
                    Deadline Reminders
                  </Label>
                  <Switch
                    id="deadline-reminders"
                    checked={settings.deadlineReminders}
                    onCheckedChange={(checked) => updateSetting("deadlineReminders", checked)}
                    disabled={!settings.notifications}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="study-reminders" className="text-white">
                    Study Time Reminders
                  </Label>
                  <Switch
                    id="study-reminders"
                    checked={settings.studyReminders}
                    onCheckedChange={(checked) => updateSetting("studyReminders", checked)}
                    disabled={!settings.notifications}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.4 }}
          className="md:col-span-2"
        >
          <Card className="border-gray-700 bg-gray-800 shadow-xl">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2">
                <User className="h-5 w-5 text-amber-500" />
                <CardTitle className="text-white">Account</CardTitle>
              </div>
              <CardDescription>Manage your account settings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-lg bg-gray-700/50 border border-gray-600">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-full flex items-center justify-center">
                      <User className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="text-white font-medium">{user?.email?.split("@")[0] || "Student"}</p>
                      <p className="text-gray-400 text-sm">{user?.email || "No email"}</p>
                    </div>
                  </div>
                  <div className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-full">Active</div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 rounded-lg bg-gray-700/30">
                    <p className="text-2xl font-bold text-white">23</p>
                    <p className="text-xs text-gray-400">Days Active</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-gray-700/30">
                    <p className="text-2xl font-bold text-white">47</p>
                    <p className="text-xs text-gray-400">Assignments</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}
