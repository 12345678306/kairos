"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getBrowserClient } from "@/lib/supabase"
import { useAuth } from "@/context/auth-context"
import type { Database } from "@/types/supabase"
import { motion } from "framer-motion"
import { ChartContainer } from "@/components/ui/chart"
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"
import { TrendingUp, BarChart3, PieChart, Activity } from "lucide-react"

type Assignment = Database["public"]["Tables"]["assignments"]["Row"]

export default function AnalyticsPage() {
  const { user } = useAuth()
  const [assignments, setAssignments] = useState<Assignment[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const supabase = getBrowserClient()

  useEffect(() => {
    const fetchAssignments = async () => {
      if (!user) return

      setIsLoading(true)
      const { data, error } = await supabase.from("assignments").select("*").eq("user_id", user.id)

      if (error) {
        console.error("Error fetching assignments:", error)
      } else {
        setAssignments(data || [])
      }
      setIsLoading(false)
    }

    fetchAssignments()
  }, [user, supabase])

  // Prepare data for charts
  const getSubjectData = () => {
    const subjectCounts: Record<string, { total: number; completed: number }> = {}

    assignments.forEach((assignment) => {
      const subject = assignment.subject_id || "Uncategorized"
      if (!subjectCounts[subject]) {
        subjectCounts[subject] = { total: 0, completed: 0 }
      }

      subjectCounts[subject].total += 1
      if (assignment.completed) {
        subjectCounts[subject].completed += 1
      }
    })

    return Object.entries(subjectCounts).map(([subject, counts]) => ({
      subject: subject === "Uncategorized" ? "Uncategorized" : subject,
      total: counts.total,
      completed: counts.completed,
      pending: counts.total - counts.completed,
    }))
  }

  const getSizeData = () => {
    const sizeCounts: Record<string, number> = { small: 0, medium: 0, large: 0 }

    assignments.forEach((assignment) => {
      const size = assignment.size.toLowerCase()
      if (sizeCounts[size] !== undefined) {
        sizeCounts[size] += 1
      }
    })

    return Object.entries(sizeCounts).map(([size, count]) => ({
      size: size.charAt(0).toUpperCase() + size.slice(1),
      count,
    }))
  }

  const getStats = () => {
    const total = assignments.length
    const completed = assignments.filter((a) => a.completed).length
    const pending = total - completed
    const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0

    return { total, completed, pending, completionRate }
  }

  const stats = getStats()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white">Analytics</h1>
        <p className="text-gray-400">Track your assignment progress and workload</p>
      </div>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-4">
        {[
          { label: "Total Assignments", value: stats.total, icon: BarChart3, color: "blue" },
          { label: "Completed", value: stats.completed, icon: TrendingUp, color: "emerald" },
          { label: "Pending", value: stats.pending, icon: Activity, color: "amber" },
          { label: "Completion Rate", value: `${stats.completionRate}%`, icon: PieChart, color: "emerald" },
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="border-gray-700 bg-gray-800 shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-400">{stat.label}</p>
                    <p className="text-2xl font-bold text-white">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-lg bg-${stat.color}-500/10`}>
                    <stat.icon className={`h-6 w-6 text-${stat.color}-500`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <Card className="border-gray-700 bg-gray-800 shadow-xl">
            <CardHeader>
              <CardTitle className="text-white">Assignments by Subject</CardTitle>
              <CardDescription>Distribution of assignments across subjects</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex h-64 items-center justify-center">
                  <div className="h-6 w-6 animate-spin rounded-full border-2 border-t-emerald-500"></div>
                </div>
              ) : (
                <ChartContainer
                  config={{
                    pending: {
                      label: "Pending",
                      color: "hsl(var(--chart-1))",
                    },
                    completed: {
                      label: "Completed",
                      color: "hsl(var(--chart-2))",
                    },
                  }}
                  className="h-64"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={getSubjectData()} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="subject" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="pending" stackId="a" fill="var(--color-pending)" />
                      <Bar dataKey="completed" stackId="a" fill="var(--color-completed)" />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
        >
          <Card className="border-gray-700 bg-gray-800 shadow-xl">
            <CardHeader>
              <CardTitle className="text-white">Assignments by Size</CardTitle>
              <CardDescription>Distribution of assignments by workload size</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex h-64 items-center justify-center">
                  <div className="h-6 w-6 animate-spin rounded-full border-2 border-t-emerald-500"></div>
                </div>
              ) : (
                <ChartContainer
                  config={{
                    count: {
                      label: "Count",
                      color: "hsl(var(--chart-3))",
                    },
                  }}
                  className="h-64"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={getSizeData()} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="size" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="count" fill="var(--color-count)" />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}
