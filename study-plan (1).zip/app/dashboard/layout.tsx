import type { ReactNode } from "react"
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { AuthCheck } from "@/components/auth-check"
import { NotificationSystem } from "@/components/notification-system"
import { RewardEnforcer } from "@/components/reward-enforcer"

interface DashboardLayoutProps {
  children: ReactNode
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <AuthCheck>
      <div className="min-h-screen bg-[#0A0118]">
        <Header />
        <div className="flex pt-16">
          <Sidebar />
          <main className="flex-1 min-h-[calc(100vh-4rem)] md:ml-64">
            <div className="p-6 md:p-8 max-w-7xl mx-auto">{children}</div>
            <Footer />
          </main>
        </div>
        <NotificationSystem />
        <RewardEnforcer />
      </div>
    </AuthCheck>
  )
}
