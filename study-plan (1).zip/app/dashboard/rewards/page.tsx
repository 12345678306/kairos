"use client"

import { useEffect, useState, useRef, useCallback } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getBrowserClient } from "@/lib/supabase"
import { useAuth } from "@/context/auth-context"
import { motion } from "framer-motion"
import {
  Coins,
  Gift,
  Clock,
  Check,
  Pencil,
  Music,
  BookOpen,
  Utensils,
  Library,
  Wind,
  Film,
  IceCream,
  Moon,
  Calendar,
  Users,
  Unlock,
  Sparkles,
  Dices,
  Award,
  Crown,
  Zap,
  Trophy,
  Laptop,
} from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { useNotifications } from "@/context/notification-context"

interface UserPoints {
  user_id: string
  points: number
}

interface Reward {
  id: string
  name: string
  description: string
  cost: number
  created_at?: string
}

interface UserReward {
  id: string
  user_id: string
  reward_id: string
  redeemed_at: string
  active_until?: string | null
  is_used: boolean
}

// Set DEBUG_MODE to false for proper durations
const DEBUG_MODE = false

// Special rewards that can be won from the wheel
const SPECIAL_REWARDS = [
  {
    name: "Double Points Booster",
    description: "Earn double points for completed tasks for 30 minutes (Duration: 30 minutes)",
  },
  {
    name: "Triple Points Booster",
    description: "Earn triple points for completed tasks for 15 minutes (Duration: 15 minutes)",
  },
  {
    name: "Extended Break",
    description: "Take an extended break for 45 minutes (Duration: 45 minutes)",
  },
  {
    name: "Instant 50 Points",
    description: "Instantly receive 50 points",
  },
  {
    name: "Special Theme",
    description: "Unlock a special theme for 24 hours (Duration: 24 hours)",
  },
]

export default function RewardsPage() {
  const { user, session } = useAuth()
  const [userPoints, setUserPoints] = useState<number>(0)
  const [rewards, setRewards] = useState<Reward[]>([])
  const [userRewards, setUserRewards] = useState<UserReward[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedReward, setSelectedReward] = useState<Reward | null>(null)
  const [isRedeemDialogOpen, setIsRedeemDialogOpen] = useState(false)
  const [activeReward, setActiveReward] = useState<{ reward: Reward; userReward: UserReward } | null>(null)
  const [rewardTimeLeft, setRewardTimeLeft] = useState<number | null>(null)
  const [rewardCategories, setRewardCategories] = useState<string[]>([])
  const [selectedCategory, setSelectedCategory] = useState<string>("All")
  const [error, setError] = useState<string | null>(null)

  // Wheel spinning state
  const [isSpinning, setIsSpinning] = useState(false)
  const [showWheelDialog, setShowWheelDialog] = useState(false)
  const [wheelReward, setWheelReward] = useState<any>(null)

  const { toast } = useToast()
  const { notifyRewardRedeemed, notifyRewardActivated, notifyPointsEarned } = useNotifications()

  const animationFrameRef = useRef<number | null>(null)
  const endTimeRef = useRef<number | null>(null)
  const supabase = getBrowserClient()

  // Function to extract duration from reward name or description
  const getRewardDuration = useCallback((reward: Reward): number => {
    const name = reward.name.toLowerCase()
    const description = reward.description.toLowerCase()

    // Default duration in minutes
    let durationMinutes = 60

    // Check for "Spin the Wheel" which has no duration
    if (name.includes("spin") || description.includes("wheel")) {
      return 0
    }

    // Try to extract duration from description first (more reliable)
    // Look for pattern like "Duration: X minutes" or "Duration: X hours"
    const durationPattern = /duration:\s*(\d+)\s*(minute|minutes|hour|hours)/i
    const durationMatch = description.match(durationPattern)

    if (durationMatch) {
      const value = Number.parseInt(durationMatch[1])
      const unit = durationMatch[2].toLowerCase()

      if (unit.includes("hour")) {
        durationMinutes = value * 60 // Convert hours to minutes
      } else {
        durationMinutes = value
      }
    } else {
      // Fallback to checking for numbers in the name or description
      const minutePattern = /(\d+)[\s-]*(minute|min)/i
      const hourPattern = /(\d+)[\s-]*(hour|hr)/i

      const minuteMatch = (name + " " + description).match(minutePattern)
      const hourMatch = (name + " " + description).match(hourPattern)

      if (minuteMatch) {
        durationMinutes = Number.parseInt(minuteMatch[1])
      } else if (hourMatch) {
        durationMinutes = Number.parseInt(hourMatch[1]) * 60
      }
    }

    // Apply shorter durations in debug mode for testing
    if (DEBUG_MODE) {
      // In debug mode, 1 minute = 1 second (for faster testing)
      return durationMinutes * 1000 // milliseconds
    }

    // Convert minutes to milliseconds for production
    return durationMinutes * 60 * 1000 // milliseconds
  }, [])

  // Helper function to get reward category for UI purposes only
  const getRewardCategory = useCallback((reward: Reward): string => {
    const name = reward.name.toLowerCase()
    const description = reward.description.toLowerCase()

    if (name.includes("break") || description.includes("break")) {
      return "Breaks"
    } else if (name.includes("art") || description.includes("draw") || description.includes("doodle")) {
      return "Creative"
    } else if (name.includes("read") || description.includes("book") || name.includes("library")) {
      return "Reading"
    } else if (name.includes("music") || description.includes("music")) {
      return "Music"
    } else if (name.includes("outdoor") || description.includes("outside") || description.includes("fresh air")) {
      return "Outdoor"
    } else if (name.includes("computer") || description.includes("lab")) {
      return "Technology"
    } else if (name.includes("friend") || description.includes("group")) {
      return "Social"
    } else if (name.includes("spin") || description.includes("wheel")) {
      return "Special"
    }

    return "Other"
  }, [])

  // Format time left for display with smooth transitions
  const formatTimeLeft = (ms: number) => {
    if (DEBUG_MODE) {
      // In debug mode, display seconds as if they were minutes
      const totalSeconds = Math.floor(ms / 1000)
      const displayMinutes = Math.floor(totalSeconds / 60)
      const displaySeconds = totalSeconds % 60
      const displayMilliseconds = Math.floor((ms % 1000) / 10)

      if (displayMinutes > 0) {
        return `${displayMinutes}m ${displaySeconds}.${displayMilliseconds.toString().padStart(2, "0")}s`
      } else {
        return `${displaySeconds}.${displayMilliseconds.toString().padStart(2, "0")}s`
      }
    } else {
      // Normal mode - display actual time
      const totalSeconds = Math.floor(ms / 1000)
      const hours = Math.floor(totalSeconds / 3600)
      const minutes = Math.floor((totalSeconds % 3600) / 60)
      const seconds = totalSeconds % 60
      const milliseconds = Math.floor((ms % 1000) / 10)

      if (hours > 0) {
        return `${hours}h ${minutes}m ${seconds}.${milliseconds.toString().padStart(2, "0")}s`
      } else if (minutes > 0) {
        return `${minutes}m ${seconds}.${milliseconds.toString().padStart(2, "0")}s`
      } else {
        return `${seconds}.${milliseconds.toString().padStart(2, "0")}s`
      }
    }
  }

  // Format duration for display
  const formatDuration = (minutes: number) => {
    if (DEBUG_MODE) {
      // In debug mode, we're treating minutes as seconds for display
      return minutes >= 60 ? `${Math.floor(minutes / 60)}m ${minutes % 60}s` : `${minutes}s`
    } else {
      // Normal mode - display actual duration
      return minutes >= 60 ? `${Math.floor(minutes / 60)}h ${minutes % 60}m` : `${minutes}m`
    }
  }

  // Create a ref to store the fetchData function
  const fetchDataRef = useRef<() => Promise<void>>(async () => {})

  // Function to start the timer for a reward using requestAnimationFrame for smoother updates
  const startTimer = useCallback(
    (reward: Reward, userReward: UserReward) => {
      // Clear any existing animation frame
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
        animationFrameRef.current = null
      }

      // Make sure we have an active_until date
      if (!userReward.active_until) {
        console.error("Cannot start timer: active_until is not set")
        return
      }

      // Set the end time reference
      const endTime = new Date(userReward.active_until).getTime()
      endTimeRef.current = endTime

      // Debug logs
      console.log(`Starting timer for reward: ${reward.name}`)
      console.log(`End time: ${new Date(endTime).toLocaleString()}`)

      // Animation function for smooth updates
      const updateTimer = () => {
        if (!endTimeRef.current) return

        const now = Date.now()
        const timeRemaining = Math.max(0, endTimeRef.current - now)

        setRewardTimeLeft(timeRemaining)

        if (timeRemaining <= 0) {
          // Timer has expired
          if (user && userReward.id && supabase) {
            supabase
              .from("user_rewards")
              .update({ is_used: true })
              .eq("id", userReward.id)
              .then(() => {
                setActiveReward(null)
                // Use the ref to call fetchData
                fetchDataRef.current()
                toast({
                  title: "Reward Expired",
                  description: `Your ${reward.name} has expired.`,
                })
              })
          } else {
            setActiveReward(null)
          }
          return // Stop the animation loop
        }

        // Continue the animation loop
        animationFrameRef.current = requestAnimationFrame(updateTimer)
      }

      // Start the animation loop
      animationFrameRef.current = requestAnimationFrame(updateTimer)
    },
    [user, supabase, toast],
  )

  // Fetch data from the database
  const fetchData = useCallback(async () => {
    if (!user || !session || !supabase) {
      setIsLoading(false)
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      // Fetch user points
      const { data: pointsData, error: pointsError } = await supabase
        .from("user_points")
        .select("*")
        .eq("user_id", user.id)
        .single()

      if (pointsError && pointsError.code !== "PGRST116") {
        console.error("Error fetching user points:", pointsError)
        setError("Failed to load user points")
      } else if (pointsData) {
        setUserPoints(pointsData.points)
      } else {
        // Create user points record if it doesn't exist
        try {
          await supabase.from("user_points").insert({
            user_id: user.id,
            points: 200, // Start with 200 points for testing
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          })
          setUserPoints(200)
        } catch (insertError) {
          console.error("Error creating user points:", insertError)
          setError("Failed to create user points record")
        }
      }

      // Fetch rewards
      const { data: existingRewards, error: rewardsError } = await supabase
        .from("rewards")
        .select("*")
        .order("cost", { ascending: true })

      if (rewardsError) {
        console.error("Error fetching rewards:", rewardsError)
        setError("Failed to load rewards")
      } else {
        setRewards(existingRewards || [])

        // Extract categories from rewards for UI filtering
        if (existingRewards && existingRewards.length > 0) {
          const categories = new Set<string>()
          existingRewards.forEach((reward) => {
            categories.add(getRewardCategory(reward))
          })
          setRewardCategories(["All", ...Array.from(categories)])
        }

        // Fetch user's redeemed rewards
        const { data: redeemedRewards, error: userRewardsError } = await supabase
          .from("user_rewards")
          .select("*")
          .eq("user_id", user.id)
          .order("redeemed_at", { ascending: false })

        if (userRewardsError) {
          console.error("Error fetching user rewards:", userRewardsError)
          setError("Failed to load user rewards")
        } else {
          setUserRewards(redeemedRewards || [])

          // Check if there's an active reward
          const now = new Date().getTime()
          const activeUserReward = redeemedRewards?.find(
            (ur) => !ur.is_used && ur.active_until && new Date(ur.active_until).getTime() > now,
          )

          if (activeUserReward) {
            const matchingReward = existingRewards?.find((r) => r.id === activeUserReward.reward_id)
            if (matchingReward) {
              const newActiveReward = {
                reward: matchingReward,
                userReward: activeUserReward,
              }
              setActiveReward(newActiveReward)

              // Start the timer for this active reward
              startTimer(matchingReward, activeUserReward)
            }
          }
        }
      }
    } catch (err) {
      console.error("Unexpected error in fetchData:", err)
      setError("An unexpected error occurred. Please try refreshing the page.")
    } finally {
      setIsLoading(false)
    }
  }, [user, session, supabase, startTimer, getRewardCategory])

  // Update the ref with the fetchData function
  useEffect(() => {
    fetchDataRef.current = fetchData
  }, [fetchData])

  // Initial data fetch
  useEffect(() => {
    fetchData()

    // Cleanup function
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
        animationFrameRef.current = null
      }
    }
  }, [fetchData])

  // Handle spinning the wheel
  const handleSpinWheel = async (reward: Reward) => {
    if (!user || !supabase) {
      toast({
        title: "Error",
        description: "Unable to spin the wheel. Please try again later.",
        variant: "destructive",
      })
      return
    }

    try {
      // Check if user has enough points
      if (userPoints < reward.cost) {
        toast({
          title: "Not Enough Points",
          description: `You need ${reward.cost - userPoints} more points to spin the wheel.`,
          variant: "destructive",
        })
        return
      }

      // Deduct points from user
      const { error: pointsError } = await supabase
        .from("user_points")
        .update({
          points: userPoints - reward.cost,
          updated_at: new Date().toISOString(),
        })
        .eq("user_id", user.id)

      if (pointsError) {
        console.error("Error updating user points:", pointsError)
        toast({
          title: "Error",
          description: "Failed to spin the wheel. Please try again.",
          variant: "destructive",
        })
        return
      }

      // Update local state
      setUserPoints((prev) => prev - reward.cost)

      // Notify about points spent
      notifyRewardRedeemed(reward.name, reward.cost)

      // Show spinning animation
      setIsSpinning(true)
      setShowWheelDialog(true)

      // Simulate wheel spinning (3 seconds)
      setTimeout(() => {
        // Select a random reward from the special rewards
        const randomIndex = Math.floor(Math.random() * SPECIAL_REWARDS.length)
        const randomReward = SPECIAL_REWARDS[randomIndex]

        setWheelReward(randomReward)
        setIsSpinning(false)
      }, 3000)
    } catch (error) {
      console.error("Error in handleSpinWheel:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    }
  }

  // Claim the reward won from spinning the wheel
  const claimWheelReward = async () => {
    if (!wheelReward || !user || !supabase) {
      toast({
        title: "Error",
        description: "Unable to claim reward. Please try again later.",
        variant: "destructive",
      })
      return
    }

    try {
      // Special case for instant points
      if (wheelReward.name === "Instant 50 Points") {
        // Add points to user
        const { error: pointsError } = await supabase
          .from("user_points")
          .update({
            points: userPoints + 50,
            updated_at: new Date().toISOString(),
          })
          .eq("user_id", user.id)

        if (pointsError) {
          console.error("Error updating user points:", pointsError)
          toast({
            title: "Error",
            description: "Failed to add points. Please try again.",
            variant: "destructive",
          })
          return
        }

        // Update local state
        setUserPoints((prev) => prev + 50)

        // Notify about points earned
        notifyPointsEarned(50, "spinning the wheel")

        toast({
          title: "Points Added!",
          description: "You've received 50 points!",
        })
      } else {
        // For other rewards, create a user_rewards record
        const now = new Date()

        // Extract duration from the description
        const durationPattern = /duration:\s*(\d+)\s*(minute|minutes|hour|hours)/i
        const durationMatch = wheelReward.description.match(durationPattern)

        let durationMs = 60 * 60 * 1000 // Default 1 hour

        if (durationMatch) {
          const value = Number.parseInt(durationMatch[1])
          const unit = durationMatch[2].toLowerCase()

          if (unit.includes("hour")) {
            durationMs = value * 60 * 60 * 1000 // Convert hours to milliseconds
          } else {
            durationMs = value * 60 * 1000 // Convert minutes to milliseconds
          }
        }

        // Apply shorter durations in debug mode
        if (DEBUG_MODE) {
          durationMs = durationMs / 60 // Make it much shorter for testing
        }

        const expirationTime = new Date(now.getTime() + durationMs)
        const activeUntil = expirationTime.toISOString()

        // Instead of creating a new reward, use the "Spin the Wheel" reward ID
        // Find the "Spin the Wheel" reward
        const spinTheWheelReward = rewards.find(
          (r) => r.name.toLowerCase().includes("spin") || r.description.toLowerCase().includes("wheel"),
        )

        if (!spinTheWheelReward) {
          toast({
            title: "Error",
            description: "Spin the Wheel reward not found. Please try again later.",
            variant: "destructive",
          })
          return
        }

        // Create user reward record using the Spin the Wheel reward ID
        const { data: userReward, error: rewardError } = await supabase
          .from("user_rewards")
          .insert({
            user_id: user.id,
            reward_id: spinTheWheelReward.id, // Use existing reward ID
            redeemed_at: now.toISOString(),
            active_until: activeUntil,
            is_used: false,
          })
          .select()
          .single()

        if (rewardError) {
          console.error("Error recording reward redemption:", rewardError)
          toast({
            title: "Error",
            description: "Failed to claim reward. Please try again.",
            variant: "destructive",
          })
          return
        }

        // If the reward has no duration (one-time use), mark it as used immediately
        if (!durationMatch && wheelReward.name !== "Instant 50 Points") {
          await supabase.from("user_rewards").update({ is_used: true }).eq("id", userReward.id)
        }

        // Notify about reward claimed
        notifyRewardActivated(wheelReward.name, formatDuration(Math.round(durationMs / (DEBUG_MODE ? 1000 : 60000))))

        toast({
          title: "Reward Claimed!",
          description: `You've successfully claimed "${wheelReward.name}"!`,
        })

        // Refresh user rewards
        fetchData()
      }
    } catch (error) {
      console.error("Error in claimWheelReward:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setShowWheelDialog(false)
      setWheelReward(null)
    }
  }

  // Handle redeeming a reward
  const handleRedeemReward = async () => {
    if (!selectedReward || !user || !supabase) {
      toast({
        title: "Error",
        description: "Unable to redeem reward. Please try again later.",
        variant: "destructive",
      })
      return
    }

    try {
      // Check if user has enough points
      if (userPoints < selectedReward.cost) {
        toast({
          title: "Not Enough Points",
          description: `You need ${selectedReward.cost - userPoints} more points to redeem this reward.`,
          variant: "destructive",
        })
        return
      }

      // Handle special case for spin the wheel
      if (selectedReward.name.toLowerCase().includes("spin")) {
        handleSpinWheel(selectedReward)
        setSelectedReward(null)
        setIsRedeemDialogOpen(false)
        return
      }

      // Calculate active_until based on reward duration
      const durationMs = getRewardDuration(selectedReward)

      // Add the duration to the current time to get the expiration time
      const now = new Date()
      const expirationTime = new Date(now.getTime() + durationMs)
      const activeUntil = expirationTime.toISOString()

      // Debug logs
      console.log("=== REDEEMING REWARD ===")
      console.log(`Reward: ${selectedReward.name}`)
      console.log(`Current time: ${now.toISOString()}`)
      console.log(`Duration: ${durationMs / (60 * 1000)} minutes`)
      console.log(`Expiration time: ${expirationTime.toISOString()}`)

      // Check if user already has an active reward of this type
      const existingActiveReward = userRewards.find(
        (ur) => ur.reward_id === selectedReward.id && !ur.is_used && ur.active_until && new Date(ur.active_until) > now,
      )

      if (existingActiveReward) {
        toast({
          title: "Reward Already Available",
          description: "You already have this reward in your inventory. Please use it before redeeming another.",
          variant: "warning",
        })
        setSelectedReward(null)
        setIsRedeemDialogOpen(false)
        return
      }

      // Deduct points from user
      const { error: pointsError } = await supabase
        .from("user_points")
        .update({
          points: userPoints - selectedReward.cost,
          updated_at: now.toISOString(),
        })
        .eq("user_id", user.id)

      if (pointsError) {
        console.error("Error updating user points:", pointsError)
        toast({
          title: "Error",
          description: "Failed to redeem reward. Please try again.",
          variant: "destructive",
        })
        return
      }

      // Check if the user already has this reward (used or unused)
      const existingReward = userRewards.find((ur) => ur.reward_id === selectedReward.id)
      let newRewardData: UserReward | null = null

      if (existingReward) {
        // Update the existing reward instead of creating a new one
        console.log("Updating existing reward record:", existingReward.id)
        const { data, error: updateError } = await supabase
          .from("user_rewards")
          .update({
            redeemed_at: now.toISOString(),
            active_until: activeUntil,
            is_used: false,
          })
          .eq("id", existingReward.id)
          .select()

        if (updateError) {
          console.error("Error updating reward:", updateError)
          // Refund points if updating fails
          await supabase
            .from("user_points")
            .update({
              points: userPoints,
              updated_at: now.toISOString(),
            })
            .eq("user_id", user.id)

          toast({
            title: "Error",
            description: "Failed to redeem reward. Please try again.",
            variant: "destructive",
          })
          return
        }

        if (data && data.length > 0) {
          newRewardData = data[0]
        } else {
          // If no data returned, use the existing reward with updated fields
          newRewardData = {
            ...existingReward,
            redeemed_at: now.toISOString(),
            active_until: activeUntil,
            is_used: false,
          }
        }
      } else {
        // Create a new reward record
        console.log("Creating new reward record")
        const { data, error: insertError } = await supabase
          .from("user_rewards")
          .insert({
            user_id: user.id,
            reward_id: selectedReward.id,
            redeemed_at: now.toISOString(),
            active_until: activeUntil,
            is_used: false,
          })
          .select()

        if (insertError) {
          console.error("Error recording reward redemption:", insertError)
          // Refund points if recording fails
          await supabase
            .from("user_points")
            .update({
              points: userPoints,
              updated_at: now.toISOString(),
            })
            .eq("user_id", user.id)

          toast({
            title: "Error",
            description: "Failed to redeem reward. Please try again.",
            variant: "destructive",
          })
          return
        }

        if (data && data.length > 0) {
          newRewardData = data[0]
        }
      }

      // Update local state
      setUserPoints((prev) => prev - selectedReward.cost)

      // Notify about reward redeemed
      notifyRewardRedeemed(selectedReward.name, selectedReward.cost)

      if (newRewardData) {
        // Update the userRewards state
        setUserRewards((prev) => {
          // Remove the old version of this reward if it exists
          const filteredRewards = prev.filter((r) => r.id !== newRewardData?.id)
          // Add the new/updated reward
          return [newRewardData, ...filteredRewards]
        })

        // Set as active reward
        const newActiveReward = {
          reward: selectedReward,
          userReward: newRewardData,
        }

        setActiveReward(newActiveReward)

        // Start the timer for this reward
        startTimer(selectedReward, newRewardData)

        console.log("=== REWARD ACTIVATED ===")
        console.log(`Reward ID: ${newRewardData.id}`)
        console.log(`Active until: ${newRewardData.active_until}`)
      }

      // Extract duration in minutes for display
      const durationMinutes = Math.round(durationMs / (DEBUG_MODE ? 1000 : 60000))

      toast({
        title: "Reward Redeemed!",
        description: `You've successfully redeemed "${selectedReward.name}" for ${formatDuration(durationMinutes)}!`,
      })
    } catch (error) {
      console.error("Error in handleRedeemReward:", error)
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSelectedReward(null)
      setIsRedeemDialogOpen(false)
    }
  }

  // Activate a reward from inventory
  const activateReward = async (reward: Reward, userReward: UserReward) => {
    try {
      // Calculate duration based on reward type
      const durationMs = getRewardDuration(reward)
      const now = new Date()
      const expirationTime = new Date(now.getTime() + durationMs)
      const newActiveUntil = expirationTime.toISOString()

      console.log("=== ACTIVATING REWARD ===")
      console.log(`Reward: ${reward.name}`)
      console.log(`Current time: ${now.toISOString()}`)
      console.log(`Duration: ${durationMs / (60 * 1000)} minutes`)
      console.log(`New expiration time: ${expirationTime.toISOString()}`)

      // Update the database with the new active_until time
      if (supabase && user) {
        const { error } = await supabase
          .from("user_rewards")
          .update({
            active_until: newActiveUntil,
            is_used: false,
          })
          .eq("id", userReward.id)

        if (error) {
          console.error("Error updating reward active_until:", error)
          toast({
            title: "Error",
            description: "Failed to activate reward. Please try again.",
            variant: "destructive",
          })
          return
        }
      }

      // Update the local userReward object
      userReward.active_until = newActiveUntil
      userReward.is_used = false

      // Set the active reward
      const newActiveReward = { reward, userReward }
      setActiveReward(newActiveReward)

      // Start the timer
      startTimer(reward, userReward)

      // Extract duration in minutes for display
      const durationMinutes = Math.round(durationMs / (DEBUG_MODE ? 1000 : 60000))
      const durationFormatted = formatDuration(durationMinutes)

      // Notify about reward activated
      notifyRewardActivated(reward.name, durationFormatted)

      toast({
        title: "Reward Activated",
        description: `You're now using your ${reward.name} for ${durationFormatted}!`,
      })
    } catch (error) {
      console.error("Error activating reward:", error)
      toast({
        title: "Error",
        description: "Failed to activate reward. Please try again.",
        variant: "destructive",
      })
    }
  }

  // Get icon for a reward
  const getRewardIcon = (rewardName: string) => {
    const name = rewardName.toLowerCase()

    // School-appropriate reward icons
    if (name.includes("art")) return Pencil
    if (name.includes("music")) return Music
    if (name.includes("reading")) return BookOpen
    if (name.includes("library")) return Library
    if (name.includes("outdoor")) return Wind
    if (name.includes("computer")) return Laptop
    if (name.includes("study with friends")) return Users

    // Original reward icons
    if (name.includes("lunch")) return Utensils
    if (name.includes("netflix") || name.includes("movie")) return Film
    if (name.includes("dessert") || name.includes("snack")) return IceCream
    if (name.includes("sleep")) return Moon
    if (name.includes("weekend") || name.includes("day off")) return Calendar
    if (name.includes("break")) return Clock
    if (name.includes("spin") || name.includes("wheel")) return Dices
    if (name.includes("double") || name.includes("triple")) return Zap
    if (name.includes("premium") || name.includes("theme")) return Crown
    if (name.includes("deadline") || name.includes("extension")) return Calendar
    if (name.includes("skip") || name.includes("task")) return Check
    if (name.includes("instant") && name.includes("points")) return Award

    // Default icons
    return Gift
  }

  // Get redeemed rewards
  const getRedeemedRewards = () => {
    return userRewards.filter((ur) => {
      // If it's used or expired, it's considered "redeemed"
      if (ur.is_used) return true
      if (ur.active_until && new Date(ur.active_until) < new Date()) return true
      return false
    })
  }

  // Get available rewards
  const getAvailableUserRewards = () => {
    return userRewards.filter((ur) => {
      // If it's not used and not expired, it's available
      if (ur.is_used) return false
      if (ur.active_until && new Date(ur.active_until) < new Date()) return false
      return true
    })
  }

  // Get filtered rewards based on category
  const getFilteredRewards = () => {
    if (selectedCategory === "All") {
      return rewards
    }

    return rewards.filter((reward) => getRewardCategory(reward) === selectedCategory)
  }

  // If not authenticated, show a message
  if (!user && !isLoading) {
    return (
      <div className="flex h-[40vh] flex-col items-center justify-center">
        <Gift className="mb-4 h-12 w-12 text-gray-500" />
        <h2 className="text-lg font-semibold text-white">Authentication Required</h2>
        <p className="mt-2 text-gray-400 text-sm">Please sign in to access the Rewards Center</p>
      </div>
    )
  }

  // If there's an error, show an error message
  if (error) {
    return (
      <div className="flex h-[40vh] flex-col items-center justify-center">
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-center">
          <h2 className="text-lg font-semibold text-white">Something went wrong</h2>
          <p className="mt-2 text-gray-400 text-sm">{error}</p>
          <Button className="mt-3 bg-red-600 hover:bg-red-700" onClick={() => window.location.reload()}>
            Refresh Page
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="p-3 space-y-4 max-w-6xl mx-auto">
      {/* Points display only */}
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-bold text-white">Rewards</h1>
        <div className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-purple-600/90 to-blue-600/90 px-3 py-1.5 shadow-lg">
          <Coins className="h-4 w-4 text-yellow-300" />
          <span className="text-sm font-bold text-white">{userPoints} Points</span>
        </div>
      </div>

      {/* Active Reward Display */}
      {activeReward && rewardTimeLeft !== null && rewardTimeLeft > 0 && (
        <div className="relative overflow-hidden rounded-lg border border-[#08efb5]/30 bg-gradient-to-br from-[#08efb5]/10 to-[#08efb5]/5 p-2 shadow-lg">
          <div className="flex flex-col justify-between gap-3 md:flex-row md:items-center">
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#08efb5]/20 shadow-lg">
                <Unlock className="h-4 w-4 text-[#08efb5]" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">{activeReward.reward.name} Active!</h3>
                <p className="mt-0.5 text-gray-300 text-xs line-clamp-1">{activeReward.reward.description}</p>
              </div>
            </div>
            <div className="rounded-lg bg-[#08efb5]/10 px-2 py-1 text-right shadow-inner">
              <p className="text-xs font-medium text-gray-300">Time Left</p>
              <p className="text-sm font-bold text-[#08efb5] h-5 tabular-nums">{formatTimeLeft(rewardTimeLeft)}</p>
            </div>
          </div>

          <div className="mt-2">
            <Progress
              value={
                (rewardTimeLeft /
                  (new Date(activeReward.userReward.active_until!).getTime() -
                    new Date(activeReward.userReward.redeemed_at).getTime())) *
                100
              }
              className="h-2 rounded-full bg-gray-800/50"
              indicatorClassName="bg-gradient-to-r from-[#08efb5]/80 to-[#08efb5] rounded-full transition-all duration-300 ease-in-out"
            />
          </div>
        </div>
      )}

      <Tabs defaultValue="shop" className="w-full">
        <TabsList className="grid w-full grid-cols-3 rounded-lg bg-gray-900/70 p-1">
          <TabsTrigger
            value="shop"
            className="rounded-md data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#08efb5] data-[state=active]:to-[#08efb5]/80 data-[state=active]:text-black text-xs"
          >
            Shop
          </TabsTrigger>
          <TabsTrigger
            value="inventory"
            className="rounded-md data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#08efb5] data-[state=active]:to-[#08efb5]/80 data-[state=active]:text-black text-xs"
          >
            Inventory
          </TabsTrigger>
          <TabsTrigger
            value="redeemed"
            className="rounded-md data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#08efb5] data-[state=active]:to-[#08efb5]/80 data-[state=active]:text-black text-xs"
          >
            History
          </TabsTrigger>
        </TabsList>

        {/* Reward Shop Tab */}
        <TabsContent value="shop" className="mt-4">
          {isLoading ? (
            <div className="flex h-48 items-center justify-center">
              <div className="h-6 w-6 animate-spin rounded-full border-4 border-gray-600 border-t-purple-500"></div>
            </div>
          ) : (
            <>
              <div className="mb-4 flex flex-wrap gap-2">
                {rewardCategories.map((category) => (
                  <Badge
                    key={category}
                    variant={selectedCategory === category ? "default" : "outline"}
                    className={`cursor-pointer transition-all text-xs ${
                      selectedCategory === category
                        ? "bg-gradient-to-r from-[#08efb5] to-[#08efb5]/80 text-black hover:from-[#08efb5]/90 hover:to-[#08efb5]/70"
                        : "border-gray-700 bg-gray-900/50 text-gray-300 hover:bg-gray-800 hover:text-white"
                    }`}
                    onClick={() => setSelectedCategory(category)}
                  >
                    {category}
                  </Badge>
                ))}
              </div>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {getFilteredRewards().map((reward, index) => {
                  const RewardIcon = getRewardIcon(reward.name)
                  const canAfford = userPoints >= reward.cost
                  const isSpinWheel = reward.name.toLowerCase().includes("spin")
                  const category = getRewardCategory(reward)

                  // Extract duration for display
                  const durationMs = getRewardDuration(reward)
                  const durationMinutes = Math.round(durationMs / (DEBUG_MODE ? 1000 : 60000))

                  return (
                    <motion.div
                      key={reward.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                    >
                      <Card
                        className={`h-full overflow-hidden border-gray-700/50 ${
                          isSpinWheel
                            ? "bg-gradient-to-br from-purple-900/40 to-indigo-900/40 border-purple-500/30"
                            : "bg-gradient-to-br from-gray-800 to-gray-900"
                        } shadow-lg transition-all hover:border-purple-500/30 hover:shadow-purple-900/5`}
                      >
                        <CardHeader className="pb-1 p-2">
                          <div className="flex items-center justify-between">
                            <CardTitle className="flex items-center gap-2 text-white text-sm">
                              {reward.name}
                              {isSpinWheel && (
                                <span className="ml-1 inline-flex items-center rounded-full bg-purple-900/30 px-2 py-0.5 text-xs text-purple-300">
                                  <Sparkles className="mr-1 h-2 w-2" />
                                  Special
                                </span>
                              )}
                            </CardTitle>
                            <div
                              className={`flex h-8 w-8 items-center justify-center rounded-full ${
                                isSpinWheel ? "bg-purple-600/30" : "bg-purple-900/30"
                              }`}
                            >
                              <RewardIcon
                                className={`h-4 w-4 ${isSpinWheel ? "text-purple-400" : "text-purple-300"}`}
                              />
                            </div>
                          </div>
                          <CardDescription className="text-gray-400 text-xs">{reward.description}</CardDescription>
                        </CardHeader>
                        <CardContent className="p-2">
                          <div className="flex flex-col gap-2">
                            <div className="flex items-center gap-2 rounded-lg bg-gray-800/70 px-2 py-1 shadow-inner">
                              <Coins className="h-3 w-3 text-yellow-300" />
                              <span className="font-medium text-white text-xs">{reward.cost} Points</span>
                            </div>
                            {!isSpinWheel && (
                              <div className="flex items-center gap-2 rounded-lg bg-gray-800/70 px-2 py-1 shadow-inner">
                                <Clock className="h-3 w-3 text-gray-400" />
                                <span className="font-medium text-white text-xs">
                                  Duration: {formatDuration(durationMinutes)}
                                </span>
                              </div>
                            )}
                            {category !== "Other" && (
                              <div className="flex items-center gap-2 rounded-lg bg-purple-900/20 px-2 py-1 shadow-inner">
                                <Badge
                                  variant="outline"
                                  className="border-purple-500/30 bg-purple-900/30 text-purple-300 text-xs"
                                >
                                  {category}
                                </Badge>
                              </div>
                            )}
                          </div>
                        </CardContent>
                        <CardFooter className="pt-1 p-2">
                          <AlertDialog
                            open={isRedeemDialogOpen && selectedReward?.id === reward.id}
                            onOpenChange={setIsRedeemDialogOpen}
                          >
                            <AlertDialogTrigger asChild>
                              <Button
                                size="sm"
                                className={`w-full text-xs ${
                                  canAfford
                                    ? isSpinWheel
                                      ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:from-purple-700 hover:to-indigo-700"
                                      : "bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:from-purple-700 hover:to-blue-700"
                                    : "bg-gray-700 text-gray-400 cursor-not-allowed"
                                }`}
                                disabled={!canAfford}
                                onClick={() => {
                                  setSelectedReward(reward)
                                  setIsRedeemDialogOpen(true)
                                }}
                              >
                                {canAfford ? (
                                  <>
                                    {isSpinWheel ? (
                                      <>
                                        <Dices className="mr-1 h-3 w-3" /> Spin
                                      </>
                                    ) : (
                                      <>
                                        <Sparkles className="mr-1 h-3 w-3" /> Redeem
                                      </>
                                    )}
                                  </>
                                ) : (
                                  "Not Enough Points"
                                )}
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="border-gray-700 bg-gray-800 text-white">
                              <AlertDialogHeader>
                                <AlertDialogTitle className="text-lg">
                                  {isSpinWheel ? "Spin the Wheel" : "Redeem Reward"}
                                </AlertDialogTitle>
                                <AlertDialogDescription className="text-gray-300 text-sm">
                                  {isSpinWheel ? (
                                    <>
                                      Are you sure you want to spend {reward.cost} points to spin the wheel?
                                      <br />
                                      <span className="mt-2 inline-block">
                                        You might win special rewards that can't be purchased directly!
                                      </span>
                                    </>
                                  ) : (
                                    <>
                                      Are you sure you want to redeem "{reward.name}" for {reward.cost} points?
                                      <br />
                                      <span className="mt-2 inline-block">
                                        This reward will be active for {formatDuration(durationMinutes)}.
                                      </span>
                                    </>
                                  )}
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel className="border-gray-700 bg-gray-900 text-white hover:bg-gray-800">
                                  Cancel
                                </AlertDialogCancel>
                                <AlertDialogAction
                                  className={`${
                                    isSpinWheel
                                      ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:from-purple-700 hover:to-indigo-700"
                                      : "bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:from-purple-700 hover:to-blue-700"
                                  }`}
                                  onClick={handleRedeemReward}
                                >
                                  {isSpinWheel ? "Spin" : "Redeem"}
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </CardFooter>
                      </Card>
                    </motion.div>
                  )
                })}
              </div>
            </>
          )}
        </TabsContent>

        {/* My Rewards Tab (Inventory) */}
        <TabsContent value="inventory" className="mt-4">
          {isLoading ? (
            <div className="flex h-48 items-center justify-center">
              <div className="h-6 w-6 animate-spin rounded-full border-4 border-gray-600 border-t-purple-500"></div>
            </div>
          ) : getAvailableUserRewards().length === 0 ? (
            <div className="flex h-32 flex-col items-center justify-center rounded-lg border border-dashed border-gray-700 bg-gray-900/20 p-3 text-center">
              <Gift className="mb-3 h-12 w-12 text-gray-600" />
              <p className="text-gray-300">No rewards in your inventory</p>
              <p className="mt-1 text-xs text-gray-500">Redeem points in the shop to get rewards</p>
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {getAvailableUserRewards().map((userReward, index) => {
                const reward = rewards.find((r) => r.id === userReward.reward_id)
                if (!reward) return null

                const RewardIcon = getRewardIcon(reward.name)
                const isActive = activeReward?.userReward.id === userReward.id

                // Extract duration for display
                const durationMs = getRewardDuration(reward)
                const durationMinutes = Math.round(durationMs / (DEBUG_MODE ? 1000 : 60000))

                return (
                  <motion.div
                    key={userReward.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card
                      className={`h-full overflow-hidden border-gray-700/50 bg-gradient-to-br from-gray-800 to-gray-900 shadow-lg transition-all ${isActive ? "border-[#08efb5]/30 shadow-[#08efb5]/5" : "hover:border-purple-500/30 hover:shadow-purple-900/5"}`}
                    >
                      <CardHeader className="pb-1 p-2">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-white text-sm">{reward.name}</CardTitle>
                          <div
                            className={`flex h-8 w-8 items-center justify-center rounded-full ${isActive ? "bg-[#08efb5]/20" : "bg-purple-900/30"}`}
                          >
                            <RewardIcon className={`h-4 w-4 ${isActive ? "text-[#08efb5]" : "text-purple-300"}`} />
                          </div>
                        </div>
                        <CardDescription className="text-gray-400 text-xs">{reward.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="p-2">
                        <div className="flex flex-col gap-2">
                          <div className="flex items-center gap-2 rounded-lg bg-gray-800/70 px-2 py-1 shadow-inner">
                            <Clock className="h-3 w-3 text-gray-400" />
                            <span className="font-medium text-white text-xs">
                              Redeemed {new Date(userReward.redeemed_at).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 rounded-lg bg-gray-800/70 px-2 py-1 shadow-inner">
                            <Clock className="h-3 w-3 text-gray-400" />
                            <span className="font-medium text-white text-xs">
                              Duration: {formatDuration(durationMinutes)}
                            </span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="pt-1 p-2">
                        <Button
                          size="sm"
                          className={`w-full text-xs ${
                            isActive
                              ? "bg-gray-700 text-gray-400 cursor-not-allowed"
                              : "bg-gradient-to-r from-[#08efb5]/90 to-[#08efb5]/70 text-black hover:from-[#08efb5] hover:to-[#08efb5]/80"
                          }`}
                          disabled={isActive}
                          onClick={() => activateReward(reward, userReward)}
                        >
                          {isActive ? (
                            <>
                              <Check className="mr-1 h-3 w-3" />
                              Active
                            </>
                          ) : (
                            "Use Reward"
                          )}
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </TabsContent>

        {/* Redeemed Tab */}
        <TabsContent value="redeemed" className="mt-4">
          {isLoading ? (
            <div className="flex h-48 items-center justify-center">
              <div className="h-6 w-6 animate-spin rounded-full border-4 border-gray-600 border-t-purple-500"></div>
            </div>
          ) : getRedeemedRewards().length === 0 ? (
            <div className="flex h-32 flex-col items-center justify-center rounded-lg border border-dashed border-gray-700 bg-gray-900/20 p-3 text-center">
              <Trophy className="mb-3 h-12 w-12 text-gray-600" />
              <p className="text-gray-300">No rewards redeemed yet</p>
              <p className="mt-1 text-xs text-gray-500">Complete assignments to earn points and redeem rewards</p>
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {getRedeemedRewards().map((userReward, index) => {
                const reward = rewards.find((r) => r.id === userReward.reward_id)
                if (!reward) return null

                const RewardIcon = getRewardIcon(reward.name)

                return (
                  <motion.div
                    key={userReward.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full overflow-hidden border-gray-700/50 bg-gradient-to-br from-gray-800 to-gray-900 shadow-lg">
                      <CardHeader className="pb-1 p-2">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-white text-sm">{reward.name}</CardTitle>
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-900/30">
                            <RewardIcon className="h-4 w-4 text-green-300" />
                          </div>
                        </div>
                        <CardDescription className="text-gray-400 text-xs">{reward.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="p-2">
                        <div className="flex items-center gap-2 rounded-lg bg-green-900/20 px-2 py-1 shadow-inner">
                          <Check className="h-3 w-3 text-green-300" />
                          <span className="font-medium text-green-200 text-xs">
                            Used on {new Date(userReward.redeemed_at).toLocaleDateString()}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Wheel Spinning Dialog */}
      <AlertDialog open={showWheelDialog} onOpenChange={setShowWheelDialog}>
        <AlertDialogContent className="border-gray-700 bg-gray-800 text-white max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-lg text-center">
              {isSpinning ? "Spinning the Wheel..." : "You Won!"}
            </AlertDialogTitle>
          </AlertDialogHeader>

          <div className="py-4 flex flex-col items-center justify-center">
            {isSpinning ? (
              <div className="relative">
                <div className="h-16 w-16 animate-spin rounded-full border-4 border-t-purple-500 border-r-blue-500 border-b-green-500 border-l-yellow-500"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Dices className="h-6 w-6 text-white" />
                </div>
              </div>
            ) : wheelReward ? (
              <div className="text-center space-y-3">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r from-purple-600 to-indigo-600">
                  {wheelReward.name.includes("Double") || wheelReward.name.includes("Triple") ? (
                    <Zap className="h-8 w-8 text-yellow-300" />
                  ) : wheelReward.name.includes("Points") ? (
                    <Award className="h-8 w-8 text-yellow-300" />
                  ) : wheelReward.name.includes("Break") ? (
                    <Clock className="h-8 w-8 text-teal-300" />
                  ) : wheelReward.name.includes("Theme") ? (
                    <Crown className="h-8 w-8 text-purple-300" />
                  ) : (
                    <Gift className="h-8 w-8 text-blue-300" />
                  )}
                </div>
                <h3 className="text-lg font-bold text-white">{wheelReward.name}</h3>
                <p className="text-gray-300 text-sm">{wheelReward.description}</p>
              </div>
            ) : null}
          </div>

          <AlertDialogFooter>
            {!isSpinning && wheelReward && (
              <Button
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:from-purple-700 hover:to-indigo-700"
                onClick={claimWheelReward}
              >
                Claim Reward
              </Button>
            )}
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
