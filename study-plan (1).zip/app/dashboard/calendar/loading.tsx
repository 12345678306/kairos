import { Skeleton } from "@/components/ui/skeleton"
import { Card, CardContent } from "@/components/ui/card"

export default function CalendarLoading() {
  return (
    <div className="space-y-6">
      <div>
        <Skeleton className="h-8 w-48 bg-gray-800" />
        <Skeleton className="h-4 w-64 mt-2 bg-gray-800" />
      </div>

      <div className="flex flex-col md:flex-row justify-between gap-4 items-center">
        <div className="flex items-center gap-2">
          <Skeleton className="h-9 w-9 rounded-full bg-gray-800" />
          <Skeleton className="h-8 w-32 bg-gray-800" />
          <Skeleton className="h-9 w-9 rounded-full bg-gray-800" />
          <Skeleton className="h-9 w-20 ml-2 bg-gray-800" />
        </div>

        <Skeleton className="h-10 w-full md:w-64 bg-gray-800" />
      </div>

      <Card className="border-gray-700 bg-gray-900">
        <CardContent className="p-0">
          <div className="grid grid-cols-7 bg-gray-800">
            {Array(7)
              .fill(0)
              .map((_, i) => (
                <div key={i} className="text-center py-3">
                  <Skeleton className="h-4 w-8 mx-auto bg-gray-700" />
                </div>
              ))}
          </div>

          <div className="grid grid-cols-7 auto-rows-fr border-t border-gray-700">
            {Array(35)
              .fill(0)
              .map((_, i) => (
                <div key={i} className="border-b border-r border-gray-700 bg-gray-900/50 p-1 min-h-[100px]">
                  <div className="flex justify-between items-center mb-1">
                    <Skeleton className="h-7 w-7 rounded-full bg-gray-800" />
                  </div>
                  <Skeleton className="h-4 w-full mt-2 bg-gray-800" />
                  <Skeleton className="h-4 w-3/4 mt-2 bg-gray-800" />
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
