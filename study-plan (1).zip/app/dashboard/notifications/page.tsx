"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { format } from "date-fns"
import { motion } from "framer-motion"
import { Eye, Trash2, Bell, Clock, Calendar, CheckCircle, AlertTriangle } from "lucide-react"
import { useNotifications } from "@/context/notification-context"

export default function NotificationsPage() {
  const [activeTab, setActiveTab] = useState("all")
  const { notifications, markAsRead, dismissNotification, clearAllNotifications } = useNotifications()

  // Filter notifications based on active tab
  const filteredNotifications = notifications.filter((notification) => {
    if (activeTab === "all") return !notification.dismissed
    if (activeTab === "unread") return !notification.read && !notification.dismissed
    return notification.type === activeTab && !notification.dismissed
  })

  // Get icon based on notification type
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "deadline":
        return <Calendar className="h-5 w-5" />
      case "reminder":
        return <Clock className="h-5 w-5" />
      case "achievement":
        return <CheckCircle className="h-5 w-5" />
      case "warning":
        return <AlertTriangle className="h-5 w-5" />
      default:
        return <Bell className="h-5 w-5" />
    }
  }

  // Get color based on notification type
  const getNotificationColor = (type: string) => {
    switch (type) {
      case "deadline":
        return "bg-blue-500/20 text-blue-400 border-blue-500/50"
      case "reminder":
        return "bg-amber-500/20 text-amber-400 border-amber-500/50"
      case "achievement":
        return "bg-emerald-500/20 text-emerald-400 border-emerald-500/50"
      case "warning":
        return "bg-red-500/20 text-red-400 border-red-500/50"
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/50"
    }
  }

  const handleMarkAsRead = (id: string) => {
    markAsRead(id)
  }

  const handleDismiss = (id: string) => {
    dismissNotification(id)
  }

  const handleClearAll = () => {
    clearAllNotifications()
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold text-white">Notifications</h1>
          <p className="text-gray-400">View and manage your notifications</p>
        </div>
        <Button variant="destructive" className="bg-red-600 hover:bg-red-700" onClick={handleClearAll}>
          <Trash2 className="mr-2 h-4 w-4" />
          Clear All
        </Button>
      </div>

      <Card className="border-gray-700 bg-gray-800 shadow-xl">
        <CardHeader className="pb-2">
          <CardTitle className="text-white">All Notifications</CardTitle>
          <CardDescription>View and manage your notifications</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mb-4 grid w-full grid-cols-5 bg-gray-900">
              <TabsTrigger value="all" className="data-[state=active]:bg-gray-700">
                All
              </TabsTrigger>
              <TabsTrigger value="unread" className="data-[state=active]:bg-gray-700">
                Unread
              </TabsTrigger>
              <TabsTrigger value="deadline" className="data-[state=active]:bg-gray-700">
                Deadlines
              </TabsTrigger>
              <TabsTrigger value="reminder" className="data-[state=active]:bg-gray-700">
                Reminders
              </TabsTrigger>
              <TabsTrigger value="achievement" className="data-[state=active]:bg-gray-700">
                Achievements
              </TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-0">
              {filteredNotifications.length === 0 ? (
                <div className="flex h-64 flex-col items-center justify-center rounded-md border border-dashed border-gray-700 p-4 text-center">
                  <Bell className="mb-4 h-12 w-12 text-gray-500" />
                  <p className="text-sm text-gray-400">No notifications found</p>
                  <p className="text-xs text-gray-500">You're all caught up!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredNotifications.map((notification, index) => (
                    <motion.div
                      key={notification.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      className={`relative overflow-hidden rounded-lg border p-4 transition-all hover:shadow-md ${
                        notification.read ? "border-gray-700 bg-gray-800" : "border-gray-600 bg-gray-700"
                      }`}
                    >
                      <div className="flex items-start gap-4">
                        <div className={`flex-shrink-0 rounded-full p-2.5 ${getNotificationColor(notification.type)}`}>
                          {getNotificationIcon(notification.type)}
                        </div>

                        <div className="flex-1 min-w-0">
                          <h3 className="text-lg font-semibold text-white mb-1">{notification.title}</h3>
                          <p className="text-gray-300 text-sm leading-relaxed">{notification.message}</p>

                          <div className="mt-2 flex items-center justify-between">
                            <span className="text-xs text-gray-400">
                              {format(new Date(notification.timestamp), "MMM d, h:mm a")}
                            </span>

                            <div className="flex gap-2">
                              {!notification.read && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 rounded-full p-0 text-blue-400 hover:bg-blue-900/20 hover:text-blue-300"
                                  onClick={() => handleMarkAsRead(notification.id)}
                                >
                                  <Eye className="h-4 w-4" />
                                  <span className="sr-only">Mark as read</span>
                                </Button>
                              )}
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 rounded-full p-0 text-red-400 hover:bg-red-900/20 hover:text-red-300"
                                onClick={() => handleDismiss(notification.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                                <span className="sr-only">Dismiss</span>
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>

                      {notification.actionUrl && (
                        <div className="mt-3 flex justify-end">
                          <Button
                            size="sm"
                            className={`rounded-lg ${
                              notification.type === "deadline"
                                ? "bg-blue-600 hover:bg-blue-700"
                                : notification.type === "reminder"
                                  ? "bg-amber-600 hover:bg-amber-700"
                                  : notification.type === "achievement"
                                    ? "bg-emerald-600 hover:bg-emerald-700"
                                    : "bg-red-600 hover:bg-red-700"
                            } text-white`}
                            onClick={() => {
                              window.location.href = notification.actionUrl || "#"
                            }}
                          >
                            {notification.actionText || "View"}
                          </Button>
                        </div>
                      )}
                    </motion.div>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
