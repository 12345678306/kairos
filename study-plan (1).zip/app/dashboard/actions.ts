"use server"

import { createServerClient } from "@/lib/supabase"
import { cookies } from "next/headers"

export async function getUserPoints(userId: string) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)

  try {
    const { data, error } = await supabase
      .from("user_points")
      .select("points")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(1)

    if (error) throw error

    if (data && data.length > 0) {
      return { points: data[0].points || 0 }
    } else {
      // No points record found, create one with server privileges
      const { error: insertError } = await supabase.from("user_points").insert({
        user_id: userId,
        points: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })

      if (insertError) throw insertError

      return { points: 0 }
    }
  } catch (error) {
    console.error("Server action error:", error)
    return { points: 0, error: String(error) }
  }
}

export async function updateUserPoints(userId: string, points: number) {
  const cookieStore = cookies()
  const supabase = createServerClient(cookieStore)

  try {
    // First check if a record exists
    const { data, error } = await supabase.from("user_points").select("id").eq("user_id", userId).limit(1)

    if (error) throw error

    if (data && data.length > 0) {
      // Update existing record
      const { error: updateError } = await supabase
        .from("user_points")
        .update({
          points: points,
          updated_at: new Date().toISOString(),
        })
        .eq("id", data[0].id)

      if (updateError) throw updateError
    } else {
      // Create new record
      const { error: insertError } = await supabase.from("user_points").insert({
        user_id: userId,
        points: points,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })

      if (insertError) throw insertError
    }

    return { success: true, points }
  } catch (error) {
    console.error("Server action error:", error)
    return { success: false, error: String(error) }
  }
}
