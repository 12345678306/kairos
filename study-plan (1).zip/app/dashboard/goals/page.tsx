"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { useAuth } from "@/context/auth-context"
import { useToast } from "@/components/ui/use-toast"
import { format } from "date-fns"
import { Plus, Target, Check, Trash2, Calendar, Edit3, TrendingUp, Award, Zap } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { getGoals, addGoal, updateGoal, deleteGoal, type Goal } from "@/lib/local-storage"

// Animation variants
const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4, ease: "easeOut" },
}

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const scaleIn = {
  initial: { opacity: 0, scale: 0.9 },
  animate: { opacity: 1, scale: 1 },
  transition: { duration: 0.4, ease: "easeOut" },
}

export default function GoalsPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [goals, setGoals] = useState<Goal[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [goalToEdit, setGoalToEdit] = useState<Goal | null>(null)
  const [goalToDelete, setGoalToDelete] = useState<Goal | null>(null)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)

  // Form state
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [targetValue, setTargetValue] = useState(1)
  const [currentValue, setCurrentValue] = useState(0)
  const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd"))

  useEffect(() => {
    const loadGoals = async () => {
      if (!user) return

      setIsLoading(true)
      try {
        const userGoals = getGoals(user.id)
        setGoals(userGoals)
      } catch (error) {
        console.error("Error loading goals:", error)
        toast({
          title: "Error",
          description: "Failed to load goals. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadGoals()
  }, [user, toast])

  const resetForm = () => {
    setTitle("")
    setDescription("")
    setTargetValue(1)
    setCurrentValue(0)
    setDate(format(new Date(), "yyyy-MM-dd"))
  }

  const handleAddGoal = async () => {
    if (!user) return

    try {
      const newGoal = addGoal(user.id, {
        title,
        description,
        targetValue,
        currentValue,
        date,
        completed: false,
      })

      setGoals((prev) => [...prev, newGoal])
      setIsAddDialogOpen(false)
      resetForm()

      toast({
        title: "Goal Added",
        description: "Your goal has been added successfully.",
      })
    } catch (error) {
      console.error("Error adding goal:", error)
      toast({
        title: "Error",
        description: "Failed to add goal. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleEditGoal = async () => {
    if (!user || !goalToEdit) return

    try {
      const updatedGoal = updateGoal(user.id, goalToEdit.id, {
        title,
        description,
        targetValue,
        currentValue,
        date,
      })

      if (updatedGoal) {
        setGoals((prev) => prev.map((g) => (g.id === goalToEdit.id ? updatedGoal : g)))
      }

      setIsEditDialogOpen(false)
      setGoalToEdit(null)
      resetForm()

      toast({
        title: "Goal Updated",
        description: "Your goal has been updated successfully.",
      })
    } catch (error) {
      console.error("Error updating goal:", error)
      toast({
        title: "Error",
        description: "Failed to update goal. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteGoal = async () => {
    if (!user || !goalToDelete) return

    try {
      const success = deleteGoal(user.id, goalToDelete.id)

      if (success) {
        setGoals((prev) => prev.filter((g) => g.id !== goalToDelete.id))
      }

      setIsDeleteDialogOpen(false)
      setGoalToDelete(null)

      toast({
        title: "Goal Deleted",
        description: "Your goal has been deleted successfully.",
      })
    } catch (error) {
      console.error("Error deleting goal:", error)
      toast({
        title: "Error",
        description: "Failed to delete goal. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleIncrementProgress = async (goal: Goal) => {
    if (!user) return

    try {
      const newValue = Math.min(goal.currentValue + 1, goal.targetValue)
      const isCompleted = newValue === goal.targetValue

      const updatedGoal = updateGoal(user.id, goal.id, {
        currentValue: newValue,
        completed: isCompleted,
      })

      if (updatedGoal) {
        setGoals((prev) => prev.map((g) => (g.id === goal.id ? updatedGoal : g)))
      }

      if (isCompleted) {
        toast({
          title: "Goal Completed! 🎉",
          description: "Congratulations on completing your goal!",
        })
      } else {
        toast({
          title: "Progress Updated",
          description: "Your goal progress has been updated.",
        })
      }
    } catch (error) {
      console.error("Error updating goal progress:", error)
      toast({
        title: "Error",
        description: "Failed to update goal progress. Please try again.",
        variant: "destructive",
      })
    }
  }

  const openEditDialog = (goal: Goal) => {
    setGoalToEdit(goal)
    setTitle(goal.title)
    setDescription(goal.description || "")
    setTargetValue(goal.targetValue)
    setCurrentValue(goal.currentValue)
    setDate(goal.date)
    setIsEditDialogOpen(true)
  }

  const getGoalStats = () => {
    const total = goals.length
    const completed = goals.filter((g) => g.completed).length
    const inProgress = goals.filter((g) => !g.completed && g.currentValue > 0).length
    const avgProgress =
      total > 0 ? Math.round(goals.reduce((sum, g) => sum + (g.currentValue / g.targetValue) * 100, 0) / total) : 0

    return { total, completed, inProgress, avgProgress }
  }

  const stats = getGoalStats()

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <motion.div
        className="bg-gradient-to-r from-amber-600/10 via-amber-500/10 to-amber-400/10 rounded-3xl p-8 border border-amber-500/20"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
          <div>
            <motion.h1
              className="text-4xl font-bold text-white mb-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              Goals & Achievements
            </motion.h1>
            <motion.p
              className="text-gray-400 text-lg"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              Set targets, track progress, and celebrate your victories
            </motion.p>
          </div>
          <motion.div
            className="mt-4 md:mt-0"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg hover:shadow-emerald-500/25 transition-all duration-300">
                  <Plus className="mr-2 h-4 w-4" />
                  New Goal
                </Button>
              </DialogTrigger>
              <DialogContent className="border-gray-700 bg-gray-800 text-white max-w-md">
                <DialogHeader>
                  <DialogTitle>Add New Goal</DialogTitle>
                  <DialogDescription className="text-gray-400">
                    Create a new goal to track your progress.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <label htmlFor="title" className="text-sm font-medium text-gray-300">
                      Title
                    </label>
                    <Input
                      id="title"
                      placeholder="Enter goal title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="border-gray-700 bg-gray-900 text-white"
                    />
                  </div>
                  <div className="grid gap-2">
                    <label htmlFor="description" className="text-sm font-medium text-gray-300">
                      Description (Optional)
                    </label>
                    <Textarea
                      id="description"
                      placeholder="Enter goal description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="border-gray-700 bg-gray-900 text-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <label htmlFor="targetValue" className="text-sm font-medium text-gray-300">
                        Target Value
                      </label>
                      <Input
                        id="targetValue"
                        type="number"
                        min="1"
                        value={targetValue}
                        onChange={(e) => setTargetValue(Number.parseInt(e.target.value) || 1)}
                        className="border-gray-700 bg-gray-900 text-white"
                      />
                    </div>
                    <div className="grid gap-2">
                      <label htmlFor="date" className="text-sm font-medium text-gray-300">
                        Target Date
                      </label>
                      <Input
                        id="date"
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="border-gray-700 bg-gray-900 text-white"
                      />
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsAddDialogOpen(false)
                      resetForm()
                    }}
                    className="border-gray-700 bg-gray-900 text-white hover:bg-gray-800"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    onClick={handleAddGoal}
                    disabled={!title || targetValue < 1}
                    className="bg-emerald-600 text-white hover:bg-emerald-700"
                  >
                    Add Goal
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </motion.div>
        </div>
      </motion.div>

      {/* Stats Overview */}
      <motion.div className="grid gap-6 md:grid-cols-4" variants={staggerContainer} initial="initial" animate="animate">
        {[
          {
            title: "Total Goals",
            value: stats.total,
            icon: Target,
            color: "blue",
            change: "+2 this month",
          },
          {
            title: "Completed",
            value: stats.completed,
            icon: Check,
            color: "emerald",
            change: `${stats.completed}/${stats.total}`,
          },
          {
            title: "In Progress",
            value: stats.inProgress,
            icon: TrendingUp,
            color: "amber",
            change: "Active goals",
          },
          {
            title: "Avg Progress",
            value: `${stats.avgProgress}%`,
            icon: Award,
            color: "purple",
            change: "Overall completion",
          },
        ].map((stat, index) => (
          <motion.div key={stat.title} variants={fadeInUp}>
            <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm hover:bg-gray-800/70 transition-all duration-300 group">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-400 mb-1">{stat.title}</p>
                    <p className="text-3xl font-bold text-white">{stat.value}</p>
                    <p className="text-xs text-gray-500 mt-1">{stat.change}</p>
                  </div>
                  <div
                    className={`p-3 rounded-xl bg-${stat.color}-500/10 group-hover:bg-${stat.color}-500/20 transition-all duration-300`}
                  >
                    <stat.icon className={`h-6 w-6 text-${stat.color}-500`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* Goals Grid */}
      {isLoading ? (
        <div className="flex h-64 items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-t-emerald-500"></div>
        </div>
      ) : goals.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm">
            <CardContent className="flex h-64 flex-col items-center justify-center p-6 text-center">
              <Target className="mb-4 h-12 w-12 text-amber-500" />
              <h3 className="mb-2 text-xl font-semibold text-white">No Goals Yet</h3>
              <p className="mb-4 text-gray-400">Create your first goal to start tracking your progress.</p>
              <Button
                className="bg-emerald-600 text-white hover:bg-emerald-700"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="mr-2 h-4 w-4" />
                Create Goal
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      ) : (
        <motion.div
          className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          variants={staggerContainer}
          initial="initial"
          animate="animate"
        >
          {goals.map((goal, index) => (
            <motion.div
              key={goal.id}
              variants={fadeInUp}
              whileHover={{ y: -4, scale: 1.02 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              <Card className="border-gray-700 bg-gray-800/50 backdrop-blur-sm hover:border-amber-600/50 transition-all duration-300 group">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-white group-hover:text-amber-400 transition-colors">
                        {goal.title}
                      </CardTitle>
                      <CardDescription className="flex items-center text-gray-400 mt-1">
                        <Calendar className="mr-1 h-3 w-3" />
                        {format(new Date(goal.date), "MMM d, yyyy")}
                      </CardDescription>
                    </div>
                    <div className="flex space-x-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 rounded-full p-0 text-gray-400 hover:bg-gray-700 hover:text-white"
                        onClick={() => openEditDialog(goal)}
                      >
                        <Edit3 className="h-4 w-4" />
                        <span className="sr-only">Edit</span>
                      </Button>
                      <AlertDialog
                        open={isDeleteDialogOpen && goalToDelete?.id === goal.id}
                        onOpenChange={setIsDeleteDialogOpen}
                      >
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 rounded-full p-0 text-red-500 hover:bg-red-900/20 hover:text-red-400"
                            onClick={() => {
                              setGoalToDelete(goal)
                              setIsDeleteDialogOpen(true)
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="border-gray-700 bg-gray-800 text-white">
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Goal</AlertDialogTitle>
                            <AlertDialogDescription className="text-gray-400">
                              Are you sure you want to delete this goal? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel className="border-gray-700 bg-gray-900 text-white hover:bg-gray-800">
                              Cancel
                            </AlertDialogCancel>
                            <AlertDialogAction
                              className="bg-red-600 text-white hover:bg-red-700"
                              onClick={handleDeleteGoal}
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {goal.description && <p className="text-sm text-gray-300 mb-4 line-clamp-2">{goal.description}</p>}
                  <div className="mb-3 flex items-center justify-between">
                    <span className="text-sm text-gray-400">
                      Progress: {goal.currentValue} / {goal.targetValue}
                    </span>
                    <span className="text-sm font-medium text-amber-400">
                      {Math.round((goal.currentValue / goal.targetValue) * 100)}%
                    </span>
                  </div>
                  <Progress
                    value={(goal.currentValue / goal.targetValue) * 100}
                    className="h-2 bg-gray-700 mb-4"
                    indicatorClassName="bg-gradient-to-r from-amber-500 to-amber-600"
                  />
                  <div className="flex justify-between">
                    {goal.completed ? (
                      <Button
                        variant="outline"
                        className="w-full border-emerald-500 bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20"
                        disabled
                      >
                        <Check className="mr-2 h-4 w-4" />
                        Completed
                      </Button>
                    ) : (
                      <Button
                        variant="outline"
                        className="w-full border-amber-500 bg-amber-500/10 text-amber-500 hover:bg-amber-500/20"
                        onClick={() => handleIncrementProgress(goal)}
                      >
                        <Zap className="mr-2 h-4 w-4" />
                        Update Progress
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      )}

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="border-gray-700 bg-gray-800 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Goal</DialogTitle>
            <DialogDescription className="text-gray-400">Update your goal details.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label htmlFor="edit-title" className="text-sm font-medium text-gray-300">
                Title
              </label>
              <Input
                id="edit-title"
                placeholder="Enter goal title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="border-gray-700 bg-gray-900 text-white"
              />
            </div>
            <div className="grid gap-2">
              <label htmlFor="edit-description" className="text-sm font-medium text-gray-300">
                Description (Optional)
              </label>
              <Textarea
                id="edit-description"
                placeholder="Enter goal description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="border-gray-700 bg-gray-900 text-white"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <label htmlFor="edit-targetValue" className="text-sm font-medium text-gray-300">
                  Target Value
                </label>
                <Input
                  id="edit-targetValue"
                  type="number"
                  min="1"
                  value={targetValue}
                  onChange={(e) => setTargetValue(Number.parseInt(e.target.value) || 1)}
                  className="border-gray-700 bg-gray-900 text-white"
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="edit-currentValue" className="text-sm font-medium text-gray-300">
                  Current Value
                </label>
                <Input
                  id="edit-currentValue"
                  type="number"
                  min="0"
                  max={targetValue}
                  value={currentValue}
                  onChange={(e) => setCurrentValue(Number.parseInt(e.target.value) || 0)}
                  className="border-gray-700 bg-gray-900 text-white"
                />
              </div>
            </div>
            <div className="grid gap-2">
              <label htmlFor="edit-date" className="text-sm font-medium text-gray-300">
                Target Date
              </label>
              <Input
                id="edit-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="border-gray-700 bg-gray-900 text-white"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIsEditDialogOpen(false)
                setGoalToEdit(null)
                resetForm()
              }}
              className="border-gray-700 bg-gray-900 text-white hover:bg-gray-800"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              onClick={handleEditGoal}
              disabled={!title || targetValue < 1}
              className="bg-emerald-600 text-white hover:bg-emerald-700"
            >
              Update Goal
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
