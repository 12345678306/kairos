"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  BookOpen,
  Calendar,
  Target,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertCircle,
  Plus,
  ChevronRight,
  Award,
  Zap,
  BarChart3,
} from "lucide-react"
import Link from "next/link"
import { SimpleCalendar } from "@/components/simple-calendar"
import { motion } from "framer-motion"

// Mock data for assignments
const mockAssignments = [
  {
    id: 1,
    title: "Data Structures Final Project",
    subject: "Computer Science",
    dueDate: new Date(2024, 11, 15),
    priority: "high",
    status: "in-progress",
    progress: 65,
  },
  {
    id: 2,
    title: "Calculus Problem Set 8",
    subject: "Mathematics",
    dueDate: new Date(2024, 11, 12),
    priority: "medium",
    status: "not-started",
    progress: 0,
  },
  {
    id: 3,
    title: "History Essay: Industrial Revolution",
    subject: "History",
    dueDate: new Date(2024, 11, 18),
    priority: "medium",
    status: "completed",
    progress: 100,
  },
  {
    id: 4,
    title: "Chemistry Lab Report",
    subject: "Chemistry",
    dueDate: new Date(2024, 11, 10),
    priority: "high",
    status: "overdue",
    progress: 30,
  },
]

export default function DashboardPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  const completedAssignments = mockAssignments.filter((a) => a.status === "completed").length
  const totalAssignments = mockAssignments.length
  const completionRate = Math.round((completedAssignments / totalAssignments) * 100)

  const upcomingAssignments = mockAssignments
    .filter((a) => a.status !== "completed" && a.status !== "overdue")
    .sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime())
    .slice(0, 3)

  const overdueAssignments = mockAssignments.filter((a) => a.status === "overdue")

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back! Here's an overview of your academic progress.</p>
        </div>
        <div className="flex items-center gap-3">
          <Button asChild className="bg-emerald-600 hover:bg-emerald-700">
            <Link href="/dashboard/assignments" className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Assignment
            </Link>
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.5 }}>
          <Card className="border-0 shadow-md bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-950 dark:to-emerald-900">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-emerald-700 dark:text-emerald-300">
                Total Assignments
              </CardTitle>
              <BookOpen className="h-4 w-4 text-emerald-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-emerald-900 dark:text-emerald-100">{totalAssignments}</div>
              <p className="text-xs text-emerald-600 dark:text-emerald-400">+2 from last week</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card className="border-0 shadow-md bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-blue-700 dark:text-blue-300">Completed</CardTitle>
              <CheckCircle className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-900 dark:text-blue-100">{completedAssignments}</div>
              <p className="text-xs text-blue-600 dark:text-blue-400">{completionRate}% completion rate</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card className="border-0 shadow-md bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-950 dark:to-orange-900">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-orange-700 dark:text-orange-300">Overdue</CardTitle>
              <AlertCircle className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-900 dark:text-orange-100">{overdueAssignments.length}</div>
              <p className="text-xs text-orange-600 dark:text-orange-400">Needs immediate attention</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Card className="border-0 shadow-md bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950 dark:to-purple-900">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-purple-700 dark:text-purple-300">Study Streak</CardTitle>
              <Zap className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-900 dark:text-purple-100">7 days</div>
              <p className="text-xs text-purple-600 dark:text-purple-400">Keep it up! 🔥</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Calendar - Takes up 2/3 of the space */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="lg:col-span-2"
        >
          <Card className="border-0 shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-emerald-600" />
                  Calendar Overview
                </CardTitle>
                <CardDescription>Your assignments and deadlines at a glance</CardDescription>
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link href="/dashboard/calendar" className="flex items-center gap-2">
                  View Full Calendar
                  <ChevronRight className="h-4 w-4" />
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              <SimpleCalendar assignments={mockAssignments} />
            </CardContent>
          </Card>
        </motion.div>

        {/* Sidebar Content */}
        <div className="space-y-6">
          {/* Upcoming Assignments */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <Card className="border-0 shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Clock className="h-5 w-5 text-blue-600" />
                  Upcoming
                </CardTitle>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/dashboard/assignments">View All</Link>
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                {upcomingAssignments.map((assignment) => (
                  <div key={assignment.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div className="space-y-1">
                      <p className="text-sm font-medium leading-none">{assignment.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {assignment.subject} • Due {assignment.dueDate.toLocaleDateString()}
                      </p>
                    </div>
                    <Badge variant={assignment.priority === "high" ? "destructive" : "secondary"} className="text-xs">
                      {assignment.priority}
                    </Badge>
                  </div>
                ))}
                {upcomingAssignments.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">No upcoming assignments</p>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Quick Actions */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Target className="h-5 w-5 text-emerald-600" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                  <Link href="/dashboard/assignments" className="flex items-center gap-2">
                    <Plus className="h-4 w-4" />
                    Add New Assignment
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                  <Link href="/dashboard/schedule" className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    View Schedule
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                  <Link href="/dashboard/goals" className="flex items-center gap-2">
                    <Target className="h-4 w-4" />
                    Set New Goal
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
                  <Link href="/dashboard/analytics" className="flex items-center gap-2">
                    <BarChart3 className="h-4 w-4" />
                    View Analytics
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          {/* Progress Overview */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.7 }}
          >
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-purple-600" />
                  This Week's Progress
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Overall Completion</span>
                    <span className="font-medium">{completionRate}%</span>
                  </div>
                  <Progress value={completionRate} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Study Time Goal</span>
                    <span className="font-medium">18/25 hrs</span>
                  </div>
                  <Progress value={72} className="h-2" />
                </div>

                <div className="pt-2 border-t">
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2">
                      <Award className="h-4 w-4 text-yellow-500" />
                      Points Earned
                    </span>
                    <span className="font-medium text-emerald-600">1,250</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      {/* Recent Activity */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.8 }}
      >
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-emerald-600" />
              Recent Activity
            </CardTitle>
            <CardDescription>Your latest academic achievements and updates</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  action: "Completed assignment",
                  item: "History Essay: Industrial Revolution",
                  time: "2 hours ago",
                  icon: CheckCircle,
                  color: "text-emerald-600",
                },
                {
                  action: "Started working on",
                  item: "Data Structures Final Project",
                  time: "5 hours ago",
                  icon: BookOpen,
                  color: "text-blue-600",
                },
                {
                  action: "Achieved study streak",
                  item: "7 days in a row",
                  time: "1 day ago",
                  icon: Zap,
                  color: "text-purple-600",
                },
                {
                  action: "Set new goal",
                  item: "Complete 5 assignments this week",
                  time: "2 days ago",
                  icon: Target,
                  color: "text-orange-600",
                },
              ].map((activity, index) => (
                <div key={index} className="flex items-center gap-4 p-3 rounded-lg bg-muted/30">
                  <activity.icon className={`h-5 w-5 ${activity.color}`} />
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium">
                      {activity.action} <span className="text-muted-foreground">{activity.item}</span>
                    </p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
