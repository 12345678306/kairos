"use server"

export async function extractTextFromPDF(formData: FormData): Promise<{ text: string; error?: string }> {
  try {
    const file = formData.get("pdf") as File

    if (!file) {
      return { text: "", error: "No file provided" }
    }

    // Check if the file is a PDF
    if (!file.name.toLowerCase().endsWith(".pdf")) {
      return { text: "", error: "File must be a PDF" }
    }

    // Instead of parsing the PDF content, we'll just return the file name
    // and let the client handle the content manually
    return {
      text: `PDF File: ${file.name} (${Math.round(file.size / 1024)} KB)
      
Note: PDF content extraction is not available in this environment. 
Please enter the assignment details manually after uploading.`,
    }
  } catch (error) {
    console.error("Error handling PDF:", error)
    return { text: "", error: "Failed to process PDF file" }
  }
}

export async function analyzeAssignmentFromPDF(formData: FormData): Promise<{
  title?: string
  subject?: string
  type?: string
  deadline?: string
  components?: string[]
  error?: string
}> {
  try {
    const { text, error } = await extractTextFromPDF(formData)

    if (error) {
      return { error }
    }

    const file = formData.get("pdf") as File
    if (!file) {
      return { error: "No file provided" }
    }

    // Extract basic information from the file name
    const fileName = file.name.replace(".pdf", "").replace(/_/g, " ").replace(/-/g, " ")

    // Try to extract a title from the filename
    const title = fileName.charAt(0).toUpperCase() + fileName.slice(1)

    return {
      title,
      // We won't try to extract other details automatically
      // The user will need to provide these manually
      error: "PDF content extraction is not available. Please enter the assignment details manually.",
    }
  } catch (error) {
    console.error("Error analyzing assignment from PDF:", error)
    return { error: "Failed to analyze the assignment" }
  }
}
