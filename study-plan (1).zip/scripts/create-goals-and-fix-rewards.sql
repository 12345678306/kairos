-- Create goals table if it doesn't exist
CREATE TABLE IF NOT EXISTS goals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  target_value INTEGER NOT NULL DEFAULT 1,
  current_value INTEGER NOT NULL DEFAULT 0,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  completed BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS goals_user_id_idx ON goals(user_id);
CREATE INDEX IF NOT EXISTS goals_date_idx ON goals(date);

-- Update user_rewards table to add active_until and is_used columns if they don't exist
ALTER TABLE public.user_rewards 
ADD COLUMN IF NOT EXISTS active_until TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS is_used BOOLEAN DEFAULT FALSE;

-- Delete all existing rewards to avoid conflicts
DELETE FROM public.rewards;

-- Add rewards with direct insert (not using ON CONFLICT)
INSERT INTO public.rewards (id, name, description, cost) VALUES 
(gen_random_uuid(), '15-Minute Break', 'Take a 15-minute break from studying', 50),
(gen_random_uuid(), '30-Minute Break', 'Take a 30-minute break from studying', 100),
(gen_random_uuid(), 'Social Media Time', '15 minutes of social media time', 75),
(gen_random_uuid(), 'Snack Break', 'Enjoy a quick snack', 40),
(gen_random_uuid(), 'Music Session', '20 minutes of your favorite music', 60),
(gen_random_uuid(), 'Gaming Time', '30 minutes of gaming', 150),
(gen_random_uuid(), 'YouTube Time', '20 minutes of YouTube videos', 80),
(gen_random_uuid(), 'Meditation Break', '10 minutes of guided meditation', 45),
(gen_random_uuid(), 'Coffee Break', 'Enjoy a 20-minute coffee break', 25),
(gen_random_uuid(), 'Extended Lunch', 'Take an extra 30 minutes for lunch', 50),
(gen_random_uuid(), 'Phone Time', 'Spend 20 minutes on your phone', 30),
(gen_random_uuid(), 'Outdoor Walk', 'Take a refreshing 30-minute walk outside', 45),
(gen_random_uuid(), 'Netflix Episode', 'Watch one episode of your favorite show', 60),
(gen_random_uuid(), 'Dessert Treat', 'Enjoy your favorite dessert', 70),
(gen_random_uuid(), 'Sleep In', 'Sleep in an extra hour tomorrow morning', 150),
(gen_random_uuid(), 'Weekend Pass', 'Take the entire weekend off from studying', 500);
