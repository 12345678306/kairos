-- Check if any rewards exist
SELECT COUNT(*) FROM rewards;

-- Add the "Spin the Wheel" reward if it doesn't exist
INSERT INTO rewards (name, description, cost, created_at)
SELECT 'Spin the Wheel', 'Try your luck and win special rewards!', 50, NOW()
WHERE NOT EXISTS (
    SELECT 1 FROM rewards 
    WHERE name ILIKE '%spin%' OR description ILIKE '%wheel%'
);

-- Make sure all rewards have reasonable costs
UPDATE rewards
SET cost = 50
WHERE cost > 200;

-- Make sure all rewards have descriptions
UPDATE rewards
SET description = name || ' (Duration: 30 minutes)'
WHERE description IS NULL OR description = '';
