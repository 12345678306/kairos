-- Update existing rewards with more enjoyable durations
UPDATE public.rewards
SET description = 'Take a 15-minute break from studying (Duration: 15 minutes)'
WHERE name = 'Study Break';

UPDATE public.rewards
SET description = 'Spend 30 minutes on social media (Duration: 30 minutes)'
WHERE name = 'Social Media Time';

UPDATE public.rewards
SET description = 'Enjoy your favorite snack (Duration: 15 minutes)'
WHERE name = 'Snack Time';

UPDATE public.rewards
SET description = 'Watch a movie of your choice (Duration: 2 hours)'
WHERE name = 'Movie Night';

UPDATE public.rewards
SET description = 'Enjoy 1 hour of gaming (Duration: 60 minutes)'
WHERE name = 'Gaming Session';

UPDATE public.rewards
SET description = 'Take a day off from studying (Duration: 24 hours)'
WHERE name = 'Day Off';

-- Make sure Spin the Wheel reward exists with proper description
INSERT INTO public.rewards (name, description, cost)
SELECT 'Spin the Wheel', 'Try your luck and win special rewards!', 50
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Spin the Wheel');

-- Add some additional fun rewards
INSERT INTO public.rewards (name, description, cost)
SELECT 'Music Break', 'Listen to your favorite music for 20 minutes (Duration: 20 minutes)', 25
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Music Break');

INSERT INTO public.rewards (name, description, cost)
SELECT 'YouTube Time', 'Watch YouTube videos for 25 minutes (Duration: 25 minutes)', 35
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'YouTube Time');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Phone Time', 'Use your phone freely for 20 minutes (Duration: 20 minutes)', 30
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Phone Time');

-- Add some points to the user for testing
UPDATE public.user_points
SET points = 500
WHERE points < 500;
