-- Add more rewards directly
INSERT INTO public.rewards (name, description, cost)
VALUES 
('Coffee Break', 'Enjoy a 20-minute coffee break', 25),
('Music Session', 'Listen to music for 45 minutes', 40),
('YouTube Time', 'Watch YouTube videos for 30 minutes', 35),
('Extended Lunch', 'Take an extra 30 minutes for lunch', 50),
('Phone Time', 'Spend 20 minutes on your phone', 30),
('Outdoor Walk', 'Take a refreshing 30-minute walk outside', 45),
('Netflix Episode', 'Watch one episode of your favorite show', 60),
('Dessert Treat', 'Enjoy your favorite dessert', 70),
('Sleep In', 'Sleep in an extra hour tomorrow morning', 150),
('Weekend Pass', 'Take the entire weekend off from studying', 500)
ON CONFLICT (name) DO NOTHING;
