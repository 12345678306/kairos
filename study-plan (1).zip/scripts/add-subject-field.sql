-- Check if subject column exists, if not add it
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_name = 'assignments'
    AND column_name = 'subject'
  ) THEN
    ALTER TABLE assignments ADD COLUMN subject VARCHAR(255);
  END IF;
END $$;

-- Update existing assignments to have a default subject if null
UPDATE assignments
SET subject = 'General'
WHERE subject IS NULL;
