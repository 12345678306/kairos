-- Add default subjects if none exist for the user
DO $$
DECLARE
  user_record RECORD;
BEGIN
  FOR user_record IN SELECT DISTINCT user_id FROM assignments LOOP
    -- Check if user has any subjects
    IF NOT EXISTS (SELECT 1 FROM subjects WHERE user_id = user_record.user_id LIMIT 1) THEN
      -- Add default subjects
      INSERT INTO subjects (id, name, color, created_at, user_id) VALUES
        (gen_random_uuid(), 'Math', '#3B82F6', NOW(), user_record.user_id),
        (gen_random_uuid(), 'Science', '#10B981', NOW(), user_record.user_id),
        (gen_random_uuid(), 'English', '#EC4899', NOW(), user_record.user_id),
        (gen_random_uuid(), 'History', '#F59E0B', NOW(), user_record.user_id),
        (gen_random_uuid(), 'Computer Science', '#6366F1', NOW(), user_record.user_id),
        (gen_random_uuid(), 'Art', '#8B5CF6', NOW(), user_record.user_id),
        (gen_random_uuid(), 'Music', '#EF4444', NOW(), user_record.user_id),
        (gen_random_uuid(), 'Physical Education', '#14B8A6', NOW(), user_record.user_id),
        (gen_random_uuid(), 'Foreign Language', '#F97316', NOW(), user_record.user_id),
        (gen_random_uuid(), 'General', '#6B7280', NOW(), user_record.user_id);
    END IF;
  END LOOP;
END $$;
