-- First, let's clear existing rewards to start fresh
DELETE FROM public.rewards;

-- Now add rewards with correct durations explicitly stated in the description
INSERT INTO public.rewards (name, description, cost) VALUES
('Spin the Wheel', 'Spin the wheel for a chance to win special rewards', 30),
('5-Minute Break', 'Take a quick 5-minute break', 10),
('10-Minute Break', 'Take a short 10-minute break', 15),
('15-Minute Break', 'Take a 15-minute break from studying', 20),
('Meditation Break', 'Take a 10-minute meditation break', 25),
('Coffee Break', 'Enjoy a 20-minute coffee break', 30),
('Social Media Time', 'Access social media for 30 minutes', 40),
('YouTube Time', 'Watch YouTube videos for 30 minutes', 40),
('Music Break', 'Listen to music for 45 minutes', 30),
('Phone Time', 'Use your phone for 20 minutes', 25),
('Lunch Break', 'Take a 30-minute lunch break', 50),
('Outdoor Walk', 'Take a refreshing 30-minute walk outside', 40),
('Gaming Session', 'Play games for 60 minutes', 80);

-- Add some points to the user for testing
UPDATE public.user_points
SET points = 200
WHERE points < 100;
