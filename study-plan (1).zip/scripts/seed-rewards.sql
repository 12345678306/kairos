-- Insert default rewards if they don't exist
INSERT INTO public.rewards (name, description, cost)
SELECT 'Study Break', 'Take a 15-minute break from studying', 20
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Study Break');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Social Media Time', 'Spend 30 minutes on social media', 30
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Social Media Time');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Snack Time', 'Enjoy your favorite snack', 40
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Snack Time');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Movie Night', 'Watch a movie of your choice', 100
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Movie Night');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Gaming Session', 'Enjoy 1 hour of gaming', 120
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Gaming Session');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Day Off', 'Take a day off from studying', 300
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Day Off');
