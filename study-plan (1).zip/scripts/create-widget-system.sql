-- Create widgets table
CREATE TABLE IF NOT EXISTS widgets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  widget_type TEXT NOT NULL,
  icon TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create user_widgets table
CREATE TABLE IF NOT EXISTS user_widgets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  widget_id UUID NOT NULL REFERENCES widgets(id) ON DELETE CASCADE,
  position INTEGER NOT NULL,
  width TEXT NOT NULL DEFAULT 'medium',
  visible BOOLEAN NOT NULL DEFAULT true,
  settings JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add RLS policies
ALTER TABLE widgets ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_widgets ENABLE ROW LEVEL SECURITY;

-- Allow all users to read widgets
CREATE POLICY widgets_select_policy ON widgets
  FOR SELECT USING (true);

-- Allow users to manage their own widgets
CREATE POLICY user_widgets_select_policy ON user_widgets
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY user_widgets_insert_policy ON user_widgets
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY user_widgets_update_policy ON user_widgets
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY user_widgets_delete_policy ON user_widgets
  FOR DELETE USING (auth.uid() = user_id);

-- Insert some default widgets
INSERT INTO widgets (name, description, widget_type, icon)
VALUES
  ('Calendar', 'Shows your upcoming assignments and events', 'calendar', 'calendar'),
  ('Focus Timer', 'Pomodoro timer to help you stay focused', 'focus-timer', 'clock'),
  ('Weather', 'Current weather and forecast', 'weather', 'cloud'),
  ('Notes', 'Quick access to your study notes', 'notes', 'file-text'),
  ('Quote of the Day', 'Inspirational quotes to keep you motivated', 'quote', 'quote'),
  ('Study Streak', 'Track your daily study streak', 'streak', 'zap'),
  ('Progress Tracker', 'Visual representation of your progress', 'progress', 'bar-chart'),
  ('Upcoming Assignments', 'List of your upcoming assignments', 'assignments', 'list-checks')
ON CONFLICT DO NOTHING;
