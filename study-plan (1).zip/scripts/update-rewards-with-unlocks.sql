-- Add is_used column to user_rewards if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                WHERE table_name = 'user_rewards' AND column_name = 'is_used') THEN
    ALTER TABLE user_rewards ADD COLUMN is_used BOOLEAN DEFAULT false;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                WHERE table_name = 'user_rewards' AND column_name = 'active_until') THEN
    ALTER TABLE user_rewards ADD COLUMN active_until TIMESTAMP WITH TIME ZONE;
  END IF;
END $$;

-- Update existing rewards with better descriptions and categories
UPDATE rewards
SET description = 'Take a 15-minute break from studying'
WHERE name LIKE '%Break%' AND description IS NULL;

UPDATE rewards
SET description = 'Enjoy 30 minutes of social media browsing'
WHERE name LIKE '%Social Media%' AND description IS NULL;

UPDATE rewards
SET description = 'Play games for 1 hour'
WHERE name LIKE '%Gaming%' AND description IS NULL;

UPDATE rewards
SET description = 'Watch a movie or show on Netflix'
WHERE name LIKE '%Netflix%' AND description IS NULL;

UPDATE rewards
SET description = 'Browse YouTube videos for 30 minutes'
WHERE name LIKE '%YouTube%' AND description IS NULL;

UPDATE rewards
SET description = 'Listen to music while studying for 45 minutes'
WHERE name LIKE '%Music%' AND description IS NULL;

-- Add new rewards that unlock specific activities
INSERT INTO rewards (id, name, description, cost, created_at)
VALUES 
  (uuid_generate_v4(), '30-Min Gaming Break', 'Unlock gaming websites and apps for 30 minutes', 50, NOW()),
  (uuid_generate_v4(), '1-Hour Social Media Pass', 'Unlock social media access for 1 hour', 75, NOW()),
  (uuid_generate_v4(), '2-Hour Entertainment Pass', 'Unlock streaming services for 2 hours', 100, NOW()),
  (uuid_generate_v4(), '45-Min Music Session', 'Unlock music streaming services for 45 minutes', 40, NOW()),
  (uuid_generate_v4(), '20-Min Phone Break', 'Unlock phone usage for 20 minutes', 35, NOW())
ON CONFLICT DO NOTHING;
