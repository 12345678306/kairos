-- First, add the new columns to user_rewards if they don't exist
ALTER TABLE public.user_rewards 
ADD COLUMN IF NOT EXISTS active_until TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS is_used BOOLEAN DEFAULT FALSE;

-- Then add more diverse rewards
INSERT INTO public.rewards (name, description, cost)
SELECT 'Coffee Break', 'Enjoy a 20-minute coffee break', 25
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Coffee Break');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Music Session', 'Listen to music for 45 minutes', 40
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Music Session');

INSERT INTO public.rewards (name, description, cost)
SELECT 'YouTube Time', 'Watch YouTube videos for 30 minutes', 35
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'YouTube Time');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Extended Lunch', 'Take an extra 30 minutes for lunch', 50
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Extended Lunch');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Phone Time', 'Spend 20 minutes on your phone', 30
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Phone Time');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Outdoor Walk', 'Take a refreshing 30-minute walk outside', 45
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Outdoor Walk');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Netflix Episode', 'Watch one episode of your favorite show', 60
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Netflix Episode');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Dessert Treat', 'Enjoy your favorite dessert', 70
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Dessert Treat');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Sleep In', 'Sleep in an extra hour tomorrow morning', 150
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Sleep In');

INSERT INTO public.rewards (name, description, cost)
SELECT 'Weekend Pass', 'Take the entire weekend off from studying', 500
WHERE NOT EXISTS (SELECT 1 FROM public.rewards WHERE name = 'Weekend Pass');
