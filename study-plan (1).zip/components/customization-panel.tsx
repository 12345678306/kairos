"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useAuth } from "@/context/auth-context"
import { getBrowserClient } from "@/lib/supabase"
import { useToast } from "@/components/ui/use-toast"
import { Palette, Check } from "lucide-react"
import { useTheme } from "next-themes"

const colorThemes = [
  { name: "light", label: "Light", primary: "#08efb5", accent: "#6d28d9" },
  { name: "dark", label: "Dark", primary: "#0ea5e9", accent: "#2563eb" },
  { name: "system", label: "System", primary: "#a855f7", accent: "#7e22ce" },
]

export function CustomizationPanel() {
  const { user } = useAuth()
  const { toast } = useToast()
  const { theme, setTheme } = useTheme()
  const [selectedTheme, setSelectedTheme] = useState("dark")
  const [isLoading, setIsLoading] = useState(true)
  const [mounted, setMounted] = useState(false)
  const supabase = getBrowserClient()

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (!mounted) return

    setSelectedTheme(theme || "dark")

    const loadPreferences = async () => {
      if (!user) return

      setIsLoading(true)

      try {
        const { data } = await supabase.from("user_preferences").select("theme").eq("user_id", user.id).single()

        if (data?.theme) {
          setSelectedTheme(data.theme)
          setTheme(data.theme)
        }
      } catch (error) {
        console.error("Error loading preferences:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadPreferences()
  }, [user, supabase, setTheme, theme, mounted])

  const saveTheme = async (themeName: string) => {
    if (!user) return

    try {
      const { data } = await supabase.from("user_preferences").select("*").eq("user_id", user.id).single()

      if (data) {
        await supabase
          .from("user_preferences")
          .update({ theme: themeName, updated_at: new Date().toISOString() })
          .eq("user_id", user.id)
      } else {
        await supabase.from("user_preferences").insert({
          user_id: user.id,
          theme: themeName,
          study_hours_per_day: 4,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })
      }

      toast({
        title: "Theme Updated",
        description: `Your theme has been changed to ${themeName}.`,
      })
    } catch (error) {
      console.error("Error saving theme:", error)
      toast({
        title: "Error",
        description: "Failed to save theme preference.",
        variant: "destructive",
      })
    }
  }

  const handleThemeChange = (themeName: string) => {
    setSelectedTheme(themeName)
    setTheme(themeName)
    saveTheme(themeName)
  }

  if (!mounted) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Palette className="h-5 w-5" />
            <CardTitle>Customize Theme</CardTitle>
          </div>
          <CardDescription>Choose a theme for your dashboard</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex h-20 items-center justify-center">
            <div className="h-5 w-5 animate-spin rounded-full border-2 border-t-primary"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <Palette className="h-5 w-5" />
          <CardTitle>Customize Theme</CardTitle>
        </div>
        <CardDescription>Choose a theme for your dashboard</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex h-20 items-center justify-center">
            <div className="h-5 w-5 animate-spin rounded-full border-2 border-t-primary"></div>
          </div>
        ) : (
          <RadioGroup value={selectedTheme} onValueChange={handleThemeChange} className="grid grid-cols-3 gap-4">
            {colorThemes.map((themeOption) => (
              <div key={themeOption.name} className="relative">
                <RadioGroupItem value={themeOption.name} id={`theme-${themeOption.name}`} className="peer sr-only" />
                <Label
                  htmlFor={`theme-${themeOption.name}`}
                  className="flex cursor-pointer flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary"
                >
                  <div className="flex w-full items-center justify-between">
                    <span className="text-sm font-medium">{themeOption.label}</span>
                    {selectedTheme === themeOption.name && <Check className="h-4 w-4 text-primary" />}
                  </div>
                </Label>
              </div>
            ))}
          </RadioGroup>
        )}
      </CardContent>
    </Card>
  )
}
