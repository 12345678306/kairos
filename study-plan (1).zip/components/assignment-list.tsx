"use client"

import type { Database } from "@/types/supabase"
import { formatDistanceToNow } from "date-fns"
import { motion } from "framer-motion"
import { CheckCircle2, Clock } from "lucide-react"

type Assignment = Database["public"]["Tables"]["assignments"]["Row"]

interface AssignmentListProps {
  assignments: Assignment[]
}

export function AssignmentList({ assignments }: AssignmentListProps) {
  if (assignments.length === 0) {
    return (
      <div className="flex h-40 flex-col items-center justify-center rounded-md border border-dashed border-gray-800 p-4 text-center">
        <p className="text-sm text-gray-400">No assignments yet</p>
        <p className="text-xs text-gray-500">Use the AI chat to add assignments</p>
      </div>
    )
  }

  return (
    <div className="space-y-2">
      {assignments.map((assignment, index) => (
        <motion.div
          key={assignment.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
          className="group flex items-center justify-between rounded-md border border-gray-800 bg-gray-900 p-3 hover:border-[#08efb5]/50"
        >
          <div className="flex items-center gap-3">
            <div className={`h-2 w-2 rounded-full ${getAssignmentSizeColor(assignment.size)}`} />
            <div>
              <h3 className="font-medium text-white">{assignment.title}</h3>
              <p className="text-xs text-gray-500">
                {formatDistanceToNow(new Date(assignment.deadline), { addSuffix: true })}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {assignment.completed ? (
              <CheckCircle2 className="h-5 w-5 text-green-500" />
            ) : (
              <Clock className="h-5 w-5 text-amber-500" />
            )}
          </div>
        </motion.div>
      ))}
    </div>
  )
}

function getAssignmentSizeColor(size: string) {
  switch (size.toLowerCase()) {
    case "small":
      return "bg-green-500"
    case "medium":
      return "bg-amber-500"
    case "large":
      return "bg-red-500"
    default:
      return "bg-blue-500"
  }
}
