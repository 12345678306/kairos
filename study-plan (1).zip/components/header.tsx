"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/context/auth-context"
import { NotificationBell } from "@/components/notification-bell"
import { PointsDisplay } from "@/components/points-display"
import { ThemeToggle } from "@/components/theme-toggle"
import { Menu, X, LogOut, Sparkles, Search, User } from "lucide-react"
import { motion } from "framer-motion"

export function Header() {
  const { user, signOut } = useAuth()
  const pathname = usePathname()
  const [scrolled, setScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const handleToggleSidebar = () => {
    document.dispatchEvent(new Event("toggle-sidebar"))
  }

  const isLoggedIn = !!user
  const isDashboard = pathname?.includes("/dashboard")

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled || isDashboard
          ? "bg-[#0A0118]/90 backdrop-blur-xl border-b border-emerald-900/20 py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-emerald-600 to-emerald-700 flex items-center justify-center shadow-lg group-hover:shadow-emerald-500/25 transition-all duration-300">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-white to-emerald-200 bg-clip-text text-transparent">
              Kairos
            </h1>
            <p className="text-xs text-emerald-300/80">Study Assistant</p>
          </div>
        </Link>

        {/* Desktop Navigation */}
        {!isDashboard && (
          <nav className="hidden md:flex items-center gap-1">
            <Link href="/#features">
              <Button variant="ghost" className="text-emerald-100 hover:text-white hover:bg-emerald-900/20">
                Features
              </Button>
            </Link>
            <Link href="/#how-it-works">
              <Button variant="ghost" className="text-emerald-100 hover:text-white hover:bg-emerald-900/20">
                How It Works
              </Button>
            </Link>
            <Link href="/#testimonials">
              <Button variant="ghost" className="text-emerald-100 hover:text-white hover:bg-emerald-900/20">
                Testimonials
              </Button>
            </Link>
            <Link href="/#pricing">
              <Button variant="ghost" className="text-emerald-100 hover:text-white hover:bg-emerald-900/20">
                Pricing
              </Button>
            </Link>
          </nav>
        )}

        {/* Right Side Actions */}
        <div className="flex items-center gap-2">
          {isDashboard && (
            <>
              <div className="hidden md:flex items-center mr-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-emerald-400" />
                  <input
                    type="text"
                    placeholder="Search..."
                    className="h-9 w-48 rounded-full bg-emerald-900/20 border border-emerald-800/30 pl-10 pr-4 text-sm text-emerald-100 placeholder:text-emerald-400/70 focus:outline-none focus:ring-2 focus:ring-emerald-600/50"
                  />
                </div>
              </div>
              <PointsDisplay />
              <NotificationBell />
            </>
          )}

          {isLoggedIn ? (
            <>
              <div className="hidden md:flex items-center gap-2">
                <ThemeToggle />
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full h-9 w-9 bg-emerald-900/20 text-emerald-100 hover:bg-emerald-800/30"
                  onClick={signOut}
                >
                  <LogOut className="h-4 w-4" />
                  <span className="sr-only">Sign Out</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full h-9 w-9 bg-gradient-to-br from-emerald-600 to-emerald-700 text-white"
                >
                  <User className="h-4 w-4" />
                  <span className="sr-only">Profile</span>
                </Button>
              </div>
              {isDashboard && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="md:hidden h-9 w-9 rounded-full bg-emerald-900/20 text-emerald-100"
                  onClick={handleToggleSidebar}
                >
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Menu</span>
                </Button>
              )}
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Link href="/login" className="hidden md:block">
                <Button variant="ghost" className="text-emerald-100 hover:text-white hover:bg-emerald-900/20">
                  Log In
                </Button>
              </Link>
              <Link href="/signup">
                <Button className="bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white shadow-lg hover:shadow-emerald-500/25">
                  Sign Up
                </Button>
              </Link>
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden h-9 w-9 text-emerald-100"
                onClick={() => setMobileMenuOpen(true)}
              >
                <Menu className="h-5 w-5" />
                <span className="sr-only">Menu</span>
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && !isDashboard && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="fixed inset-0 z-50 bg-[#0A0118]/95 backdrop-blur-xl p-6 flex flex-col"
        >
          <div className="flex justify-between items-center">
            <Link href="/" className="flex items-center gap-2" onClick={() => setMobileMenuOpen(false)}>
              <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-emerald-600 to-emerald-700 flex items-center justify-center shadow-lg">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-white to-emerald-200 bg-clip-text text-transparent">
                  Kairos
                </h1>
                <p className="text-xs text-emerald-300/80">Study Assistant</p>
              </div>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 text-emerald-100"
              onClick={() => setMobileMenuOpen(false)}
            >
              <X className="h-5 w-5" />
              <span className="sr-only">Close</span>
            </Button>
          </div>

          <nav className="flex flex-col gap-4 mt-12">
            <Link
              href="/#features"
              className="text-xl font-medium text-emerald-100 hover:text-white py-2 border-b border-emerald-900/20"
              onClick={() => setMobileMenuOpen(false)}
            >
              Features
            </Link>
            <Link
              href="/#how-it-works"
              className="text-xl font-medium text-emerald-100 hover:text-white py-2 border-b border-emerald-900/20"
              onClick={() => setMobileMenuOpen(false)}
            >
              How It Works
            </Link>
            <Link
              href="/#testimonials"
              className="text-xl font-medium text-emerald-100 hover:text-white py-2 border-b border-emerald-900/20"
              onClick={() => setMobileMenuOpen(false)}
            >
              Testimonials
            </Link>
            <Link
              href="/#pricing"
              className="text-xl font-medium text-emerald-100 hover:text-white py-2 border-b border-emerald-900/20"
              onClick={() => setMobileMenuOpen(false)}
            >
              Pricing
            </Link>
            <Link
              href="/login"
              className="text-xl font-medium text-emerald-100 hover:text-white py-2 border-b border-emerald-900/20"
              onClick={() => setMobileMenuOpen(false)}
            >
              Log In
            </Link>
          </nav>

          <div className="mt-auto">
            <Link href="/signup" onClick={() => setMobileMenuOpen(false)}>
              <Button className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white shadow-lg">
                Sign Up Free
              </Button>
            </Link>
          </div>
        </motion.div>
      )}
    </header>
  )
}
