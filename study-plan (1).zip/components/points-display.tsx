"use client"

import { useEffect, useState } from "react"
import { useAuth } from "@/context/auth-context"
import { Badge } from "@/components/ui/badge"
import { Coins } from "lucide-react"
import { getUserPoints } from "@/app/dashboard/actions"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

export function PointsDisplay() {
  const { user } = useAuth()
  const [points, setPoints] = useState(0)
  const [loading, setLoading] = useState(true)
  const supabase = createClientComponentClient()

  useEffect(() => {
    async function fetchPoints() {
      if (!user?.id) return

      try {
        setLoading(true)

        // Use the server action to get points (bypasses RLS)
        const result = await getUserPoints(user.id)

        if (result.error) {
          console.error("Error fetching points:", result.error)
          // Try to get points from localStorage as fallback
          const localPoints = localStorage.getItem(`points_${user.id}`)
          if (localPoints) {
            const parsedPoints = JSON.parse(localPoints)
            setPoints(parsedPoints.points || 0)
          }
        } else {
          setPoints(result.points)

          // Update localStorage for offline access
          localStorage.setItem(
            `points_${user.id}`,
            JSON.stringify({
              userId: user.id,
              points: result.points,
              updatedAt: new Date().toISOString(),
            }),
          )
        }
      } catch (error) {
        console.error("Failed to fetch points:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchPoints()

    // Set up real-time subscription for points updates
    const pointsSubscription = supabase
      .channel("user_points_changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "user_points",
          filter: `user_id=eq.${user?.id}`,
        },
        (payload) => {
          if (payload.new) {
            setPoints(payload.new.points || 0)

            // Update localStorage when points change
            localStorage.setItem(
              `points_${user?.id}`,
              JSON.stringify({
                userId: user?.id,
                points: payload.new.points,
                updatedAt: new Date().toISOString(),
              }),
            )
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(pointsSubscription)
    }
  }, [user, supabase])

  if (loading) {
    return (
      <Badge variant="outline" className="bg-gray-800 text-gray-300 border-gray-700 h-8 px-3">
        <Coins className="h-3 w-3 mr-1 text-[#08efb5]" />
        <span className="text-xs">Loading...</span>
      </Badge>
    )
  }

  return (
    <Badge variant="outline" className="bg-gray-800 text-gray-300 border-gray-700 h-8 px-3">
      <Coins className="h-3 w-3 mr-1 text-[#08efb5]" />
      <span className="text-xs">{points.toLocaleString()} points</span>
    </Badge>
  )
}
