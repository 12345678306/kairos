export function Footer() {
  return (
    <div className="w-full py-4 px-4 text-center text-xs text-muted-foreground mt-8 border-t border-border">
      <p>© {new Date().getFullYear()} Kairos. All rights reserved.</p>
    </div>
  )
}
