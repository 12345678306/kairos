"use client"

import { useState, useEffect } from "react"
import { X, CheckCircle, Bell, Award, Gift, AlertTriangle, Info } from "lucide-react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"

interface NotificationPopupProps {
  notification: {
    id: string
    title: string
    message: string
    type: string
    timestamp: number
  }
  onDismiss: () => void
}

export function NotificationPopup({ notification, onDismiss }: NotificationPopupProps) {
  const [progress, setProgress] = useState(100)
  const [isPaused, setIsPaused] = useState(false)
  const duration = 5000 // 5 seconds

  useEffect(() => {
    if (isPaused) return

    const startTime = Date.now()
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime
      const remaining = Math.max(0, 100 - (elapsed / duration) * 100)
      setProgress(remaining)

      if (remaining <= 0) {
        clearInterval(interval)
        onDismiss()
      }
    }, 10)

    return () => clearInterval(interval)
  }, [onDismiss, isPaused])

  const getIcon = () => {
    switch (notification.type) {
      case "success":
        return <CheckCircle className="h-5 w-5 text-green-400" />
      case "reward":
        return <Gift className="h-5 w-5 text-purple-400" />
      case "achievement":
      case "milestone":
        return <Award className="h-5 w-5 text-yellow-400" />
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-amber-400" />
      case "info":
        return <Info className="h-5 w-5 text-blue-400" />
      default:
        return <Bell className="h-5 w-5 text-gray-400" />
    }
  }

  const getGradient = () => {
    switch (notification.type) {
      case "success":
        return "from-green-500/20 to-green-600/10"
      case "reward":
        return "from-purple-500/20 to-purple-600/10"
      case "achievement":
      case "milestone":
        return "from-yellow-500/20 to-amber-600/10"
      case "warning":
        return "from-amber-500/20 to-red-600/10"
      case "info":
        return "from-blue-500/20 to-indigo-600/10"
      default:
        return "from-gray-700 to-gray-800"
    }
  }

  return (
    <motion.div
      className={`relative overflow-hidden rounded-lg border border-gray-700 bg-gradient-to-br ${getGradient()} p-4 shadow-lg backdrop-blur-md`}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      layout
    >
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-3">
          <div className="mt-0.5 rounded-full bg-gray-800/50 p-1.5">{getIcon()}</div>
          <div>
            <h4 className="font-medium text-white">{notification.title}</h4>
            <p className="mt-1 text-sm text-gray-300">{notification.message}</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6 rounded-full p-0 text-gray-400 hover:bg-gray-700 hover:text-white"
          onClick={onDismiss}
        >
          <X className="h-3 w-3" />
          <span className="sr-only">Close</span>
        </Button>
      </div>

      {/* Progress bar */}
      <div className="absolute bottom-0 left-0 h-1 w-full bg-gray-800/50">
        <div className="h-full bg-white/30" style={{ width: `${progress}%`, transition: "width 0.1s linear" }} />
      </div>
    </motion.div>
  )
}
