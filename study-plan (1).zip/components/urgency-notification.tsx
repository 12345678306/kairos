"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { AlertCircle, Clock, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { getBrowserClient } from "@/lib/supabase"
import { useAuth } from "@/context/auth-context"
import { differenceInDays, format, addDays } from "date-fns"

interface Assignment {
  id: string
  title: string
  deadline: string
  subject_id: string | null
  size: string
}

export function UrgencyNotification() {
  const [notification, setNotification] = useState<{
    assignment: Assignment
    message: string
    type: "warning" | "danger" | "info"
  } | null>(null)
  const [dismissed, setDismissed] = useState<string[]>([])
  const [isVisible, setIsVisible] = useState(false)
  const { user } = useAuth()
  const supabase = getBrowserClient()

  useEffect(() => {
    const fetchAssignments = async () => {
      if (!user) return

      // Get upcoming assignments that are not completed
      const { data: assignments, error } = await supabase
        .from("assignments")
        .select("*")
        .eq("user_id", user.id)
        .eq("completed", false)
        .order("deadline", { ascending: true })

      if (error) {
        console.error("Error fetching assignments:", error)
        return
      }

      if (!assignments || assignments.length === 0) return

      // Filter out dismissed notifications
      const eligibleAssignments = assignments.filter(
        (assignment) => !dismissed.includes(assignment.id) && new Date(assignment.deadline) > new Date(),
      )

      if (eligibleAssignments.length === 0) return

      // Find the most urgent assignment based on deadline and size
      const now = new Date()
      const urgentAssignments = eligibleAssignments
        .map((assignment) => {
          const deadline = new Date(assignment.deadline)
          const daysUntilDeadline = differenceInDays(deadline, now)

          // Calculate urgency score (lower is more urgent)
          // Consider both deadline proximity and assignment size
          const sizeMultiplier = assignment.size === "large" ? 1.5 : assignment.size === "medium" ? 1 : 0.7
          const urgencyScore = daysUntilDeadline / sizeMultiplier

          return { assignment, urgencyScore }
        })
        .sort((a, b) => a.urgencyScore - b.urgencyScore)

      const mostUrgent = urgentAssignments[0]
      if (!mostUrgent) return

      const { assignment } = mostUrgent
      const deadline = new Date(assignment.deadline)
      const daysUntilDeadline = differenceInDays(deadline, now)

      // Generate appropriate message based on urgency
      let message = ""
      let type: "warning" | "danger" | "info" = "info"

      if (daysUntilDeadline <= 1) {
        // Due tomorrow or today
        message = `Students who get an A on ${assignment.title} typically start at least 3 days before the deadline. Start now to avoid rushing!`
        type = "danger"
      } else if (daysUntilDeadline <= 3) {
        // Due within 3 days
        message = `Students who get an A on ${assignment.title} typically start a week before the deadline. Start today to stay ahead!`
        type = "warning"
      } else if (daysUntilDeadline <= 7) {
        // Due within a week
        message = `Students who excel at ${assignment.size} assignments like "${assignment.title}" start early. Begin now to ensure quality work!`
        type = "info"
      } else {
        // Due in more than a week
        message = `Planning ahead? Top students would start working on ${assignment.title} by ${format(addDays(deadline, -7), "MMM d")}. Get ahead of the curve!`
        type = "info"
      }

      setNotification({ assignment, message, type })
      setIsVisible(true)
    }

    fetchAssignments()

    // Set up interval to check for notifications every 2 hours
    const interval = setInterval(fetchAssignments, 2 * 60 * 60 * 1000)

    return () => clearInterval(interval)
  }, [user, supabase, dismissed])

  const handleDismiss = () => {
    if (notification) {
      setDismissed((prev) => [...prev, notification.assignment.id])
      setIsVisible(false)

      // After animation completes, clear the notification
      setTimeout(() => {
        setNotification(null)
      }, 300)
    }
  }

  if (!notification) return null

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className={`mb-6 rounded-lg border p-4 ${
            notification.type === "danger"
              ? "border-red-500 bg-red-500/10"
              : notification.type === "warning"
                ? "border-amber-500 bg-amber-500/10"
                : "border-blue-500 bg-blue-500/10"
          }`}
        >
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3">
              <div
                className={`mt-0.5 rounded-full p-1 ${
                  notification.type === "danger"
                    ? "bg-red-500/20 text-red-500"
                    : notification.type === "warning"
                      ? "bg-amber-500/20 text-amber-500"
                      : "bg-blue-500/20 text-blue-500"
                }`}
              >
                {notification.type === "danger" ? <AlertCircle className="h-5 w-5" /> : <Clock className="h-5 w-5" />}
              </div>
              <div>
                <h3
                  className={`font-medium ${
                    notification.type === "danger"
                      ? "text-red-500"
                      : notification.type === "warning"
                        ? "text-amber-500"
                        : "text-blue-500"
                  }`}
                >
                  Time to start: {notification.assignment.title}
                </h3>
                <p className="mt-1 text-sm text-gray-400">{notification.message}</p>
                <div className="mt-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className={`mr-2 ${
                      notification.type === "danger"
                        ? "border-red-500 text-red-500 hover:bg-red-500/10"
                        : notification.type === "warning"
                          ? "border-amber-500 text-amber-500 hover:bg-amber-500/10"
                          : "border-blue-500 text-blue-500 hover:bg-blue-500/10"
                    }`}
                    onClick={() => (window.location.href = "/dashboard/assignments")}
                  >
                    View Assignment
                  </Button>
                </div>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 rounded-full text-gray-400 hover:bg-gray-800 hover:text-white"
              onClick={handleDismiss}
            >
              <X className="h-4 w-4" />
              <span className="sr-only">Dismiss</span>
            </Button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
