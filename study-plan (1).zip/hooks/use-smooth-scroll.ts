"use client"

import { useRef, useEffect, useState } from "react"

interface SmoothScrollOptions {
  duration?: number
  easing?: (t: number) => number
}

// Easing functions
const easings = {
  // Linear
  linear: (t: number) => t,

  // Quadratic
  easeInQuad: (t: number) => t * t,
  easeOutQuad: (t: number) => t * (2 - t),
  easeInOutQuad: (t: number) => (t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t),

  // Cubic
  easeInCubic: (t: number) => t * t * t,
  easeOutCubic: (t: number) => --t * t * t + 1,
  easeInOutCubic: (t: number) => (t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1),

  // Exponential
  easeOutExpo: (t: number) => (t === 1 ? 1 : 1 - Math.pow(2, -10 * t)),
}

export function useSmoothScroll(options: SmoothScrollOptions = {}) {
  const { duration = 500, easing = easings.easeOutCubic } = options

  const [isScrolling, setIsScrolling] = useState(false)
  const requestRef = useRef<number | null>(null)
  const startTimeRef = useRef<number>(0)
  const startPositionRef = useRef<number>(0)
  const targetRef = useRef<number>(0)
  const elementRef = useRef<HTMLElement | null>(null)

  const scrollTo = (element: HTMLElement, target: number) => {
    // Save references
    elementRef.current = element
    startPositionRef.current = element.scrollTop
    targetRef.current = target
    startTimeRef.current = performance.now()
    setIsScrolling(true)

    // Cancel any existing animation
    if (requestRef.current) {
      cancelAnimationFrame(requestRef.current)
    }

    // Start animation
    requestRef.current = requestAnimationFrame(animateScroll)
  }

  const scrollBy = (element: HTMLElement, amount: number) => {
    scrollTo(element, element.scrollTop + amount)
  }

  const animateScroll = (timestamp: number) => {
    if (!elementRef.current) return

    const elapsed = timestamp - startTimeRef.current
    const progress = Math.min(elapsed / duration, 1)
    const easedProgress = easing(progress)

    const currentPosition = startPositionRef.current + (targetRef.current - startPositionRef.current) * easedProgress

    elementRef.current.scrollTop = currentPosition

    if (progress < 1) {
      requestRef.current = requestAnimationFrame(animateScroll)
    } else {
      setIsScrolling(false)
      requestRef.current = null
    }
  }

  const cancelScroll = () => {
    if (requestRef.current) {
      cancelAnimationFrame(requestRef.current)
      requestRef.current = null
      setIsScrolling(false)
    }
  }

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current)
      }
    }
  }, [])

  return { scrollTo, scrollBy, cancelScroll, isScrolling }
}
