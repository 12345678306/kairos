"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect, useCallback } from "react"
import { getBrowserClient } from "@/lib/supabase"
import { useAuth } from "@/context/auth-context"
import { differenceInDays, differenceInHours, format } from "date-fns"

export type Notification = {
  id: string
  title: string
  message: string
  type: "deadline" | "reminder" | "achievement" | "warning" | "success"
  actionUrl?: string
  actionText?: string
  timestamp: Date
  expiresAt?: Date
  priority: "low" | "medium" | "high"
  read: boolean
  dismissed: boolean
  sourceId?: string // ID of the source assignment/task
}

// Track notification history to prevent duplicates
export interface NotificationHistory {
  shownNotificationIds: string[]
  achievementMilestones: {
    assignmentsCompleted: number[]
    pointsEarned: number[]
    streakDays: number[]
    subjectsStudied: string[]
  }
}

type NotificationContextType = {
  notifications: Notification[]
  unreadCount: number
  addNotification: (notification: Omit<Notification, "id" | "timestamp" | "read" | "dismissed">) => void
  markAsRead: (id: string) => void
  dismissNotification: (id: string) => void
  markAllAsRead: () => void
  clearAllNotifications: () => void
  refreshNotifications: () => Promise<void>
  // New event-driven notification methods
  notifyAssignmentCompleted: (assignmentId: string, title: string, subjectName: string, pointsEarned: number) => void
  notifyPointsEarned: (points: number, reason: string) => void
  notifyRewardRedeemed: (rewardName: string, cost: number) => void
  notifyRewardActivated: (rewardName: string, duration: string) => void
  notifyTaskCompleted: (taskId: string, title: string) => void
  notifyGoalProgress: (goalId: string, title: string, progress: number, total: number) => void
  notifyGoalCompleted: (goalId: string, title: string) => void
  checkForMilestones: () => Promise<void>
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined)

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [notificationHistory, setNotificationHistory] = useState<NotificationHistory>({
    shownNotificationIds: [],
    achievementMilestones: {
      assignmentsCompleted: [],
      pointsEarned: [],
      streakDays: [],
      subjectsStudied: [],
    },
  })
  const { user } = useAuth()
  const supabase = getBrowserClient()

  // Load notification history from localStorage
  useEffect(() => {
    if (!user) return

    try {
      const historyJson = localStorage.getItem(`notification-history-${user.id}`)
      if (historyJson) {
        setNotificationHistory(JSON.parse(historyJson))
      }

      // Load saved notifications
      const savedNotificationsJson = localStorage.getItem(`notifications-${user.id}`)
      if (savedNotificationsJson) {
        const savedNotifications = JSON.parse(savedNotificationsJson).map((n: any) => ({
          ...n,
          timestamp: new Date(n.timestamp),
          expiresAt: n.expiresAt ? new Date(n.expiresAt) : undefined,
        }))
        setNotifications(savedNotifications)
      }
    } catch (error) {
      console.error("Error loading notification history:", error)
    }
  }, [user])

  // Save notification history whenever it changes
  useEffect(() => {
    if (!user) return

    try {
      localStorage.setItem(`notification-history-${user.id}`, JSON.stringify(notificationHistory))
    } catch (error) {
      console.error("Error saving notification history:", error)
    }
  }, [notificationHistory, user])

  // Save notifications to localStorage whenever they change
  useEffect(() => {
    if (!user || notifications.length === 0) return

    try {
      localStorage.setItem(`notifications-${user.id}`, JSON.stringify(notifications))
    } catch (error) {
      console.error("Error saving notifications:", error)
    }
  }, [notifications, user])

  // Update unread count whenever notifications change
  useEffect(() => {
    const count = notifications.filter((n) => !n.read && !n.dismissed).length
    setUnreadCount(count)
  }, [notifications])

  // Helper function to add a notification if it hasn't been shown before
  const addUniqueNotification = useCallback(
    (notification: Omit<Notification, "id" | "timestamp" | "read" | "dismissed">) => {
      const id = notification.id || `notification-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`

      // Check if this notification has already been shown
      if (notificationHistory.shownNotificationIds.includes(id)) {
        return false // Already shown
      }

      // Add to notification history
      setNotificationHistory((prev) => ({
        ...prev,
        shownNotificationIds: [...prev.shownNotificationIds, id],
      }))

      // Create and add the notification
      const newNotification: Notification = {
        ...notification,
        id,
        timestamp: new Date(),
        read: false,
        dismissed: false,
      }

      setNotifications((prev) => [newNotification, ...prev])
      return true
    },
    [notificationHistory],
  )

  // Add a new notification
  const addNotification = useCallback((notification: Omit<Notification, "id" | "timestamp" | "read" | "dismissed">) => {
    const newNotification: Notification = {
      ...notification,
      id: notification.id || `notification-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
      read: false,
      dismissed: false,
    }

    setNotifications((prev) => [newNotification, ...prev])
  }, [])

  // Mark a notification as read
  const markAsRead = useCallback((id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }, [])

  // Dismiss a notification
  const dismissNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, dismissed: true } : n)))
  }, [])

  // Mark all notifications as read
  const markAllAsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
  }, [])

  // Clear all notifications
  const clearAllNotifications = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, dismissed: true })))
  }, [])

  // Event-driven notification: Assignment completed
  const notifyAssignmentCompleted = useCallback(
    (assignmentId: string, title: string, subjectName: string, pointsEarned: number) => {
      const id = `assignment-completed-${assignmentId}`

      addUniqueNotification({
        id,
        title: "Assignment Completed!",
        message: `You've completed "${title}" for ${subjectName} and earned ${pointsEarned} points!`,
        type: "success",
        actionUrl: "/dashboard/assignments",
        actionText: "View Assignments",
        priority: "medium",
        sourceId: assignmentId,
      })
    },
    [addUniqueNotification],
  )

  // Event-driven notification: Points earned
  const notifyPointsEarned = useCallback(
    (points: number, reason: string) => {
      const id = `points-earned-${Date.now()}`

      addUniqueNotification({
        id,
        title: "Points Earned!",
        message: `You've earned ${points} points for ${reason}.`,
        type: "success",
        actionUrl: "/dashboard/rewards",
        actionText: "View Rewards",
        priority: "medium",
      })
    },
    [addUniqueNotification],
  )

  // Event-driven notification: Reward redeemed
  const notifyRewardRedeemed = useCallback(
    (rewardName: string, cost: number) => {
      const id = `reward-redeemed-${Date.now()}`

      addUniqueNotification({
        id,
        title: "Reward Redeemed!",
        message: `You've redeemed "${rewardName}" for ${cost} points.`,
        type: "success",
        actionUrl: "/dashboard/rewards",
        actionText: "View Rewards",
        priority: "medium",
      })
    },
    [addUniqueNotification],
  )

  // Event-driven notification: Reward activated
  const notifyRewardActivated = useCallback(
    (rewardName: string, duration: string) => {
      const id = `reward-activated-${Date.now()}`

      addUniqueNotification({
        id,
        title: "Reward Activated!",
        message: `You've activated "${rewardName}" for ${duration}.`,
        type: "success",
        actionUrl: "/dashboard/rewards",
        actionText: "View Rewards",
        priority: "medium",
      })
    },
    [addUniqueNotification],
  )

  // Event-driven notification: Task completed
  const notifyTaskCompleted = useCallback(
    (taskId: string, title: string) => {
      const id = `task-completed-${taskId}`

      addUniqueNotification({
        id,
        title: "Task Completed!",
        message: `You've completed the task "${title}".`,
        type: "success",
        actionUrl: "/dashboard/schedule",
        actionText: "View Schedule",
        priority: "low",
        sourceId: taskId,
      })
    },
    [addUniqueNotification],
  )

  // Event-driven notification: Goal progress
  const notifyGoalProgress = useCallback(
    (goalId: string, title: string, progress: number, total: number) => {
      // Only notify at 25%, 50%, 75% progress points
      const percentage = Math.floor((progress / total) * 100)

      if (percentage !== 25 && percentage !== 50 && percentage !== 75) {
        return
      }

      const id = `goal-progress-${goalId}-${percentage}`

      // Check if this milestone has already been notified
      if (notificationHistory.shownNotificationIds.includes(id)) {
        return
      }

      addUniqueNotification({
        id,
        title: "Goal Progress Update",
        message: `You're ${percentage}% of the way to completing your goal "${title}"!`,
        type: "achievement",
        actionUrl: "/dashboard/goals",
        actionText: "View Goals",
        priority: "medium",
        sourceId: goalId,
      })
    },
    [addUniqueNotification, notificationHistory.shownNotificationIds],
  )

  // Event-driven notification: Goal completed
  const notifyGoalCompleted = useCallback(
    (goalId: string, title: string) => {
      const id = `goal-completed-${goalId}`

      addUniqueNotification({
        id,
        title: "Goal Completed!",
        message: `Congratulations! You've completed your goal "${title}"!`,
        type: "achievement",
        actionUrl: "/dashboard/goals",
        actionText: "View Goals",
        priority: "high",
        sourceId: goalId,
      })
    },
    [addUniqueNotification],
  )

  // Check for milestone achievements
  const checkForMilestones = useCallback(async () => {
    if (!user || !supabase) return

    try {
      // Fetch completed assignments count
      const { count: assignmentsCount, error: assignmentsError } = await supabase
        .from("assignments")
        .select("*", { count: "exact", head: true })
        .eq("user_id", user.id)
        .eq("completed", true)

      if (assignmentsError) {
        console.error("Error fetching assignments count:", assignmentsError)
      } else if (assignmentsCount !== null) {
        // Define milestone levels
        const milestones = [5, 10, 15, 25, 50, 100]

        // Check each milestone
        milestones.forEach((milestone) => {
          if (
            assignmentsCount >= milestone &&
            !notificationHistory.achievementMilestones.assignmentsCompleted.includes(milestone)
          ) {
            // Add to history
            setNotificationHistory((prev) => ({
              ...prev,
              achievementMilestones: {
                ...prev.achievementMilestones,
                assignmentsCompleted: [...prev.achievementMilestones.assignmentsCompleted, milestone],
              },
            }))

            // Create notification with varied messages based on milestone
            let message = ""
            let title = "Achievement Unlocked!"

            switch (milestone) {
              case 5:
                message = "You've completed 5 assignments. Great start to your academic journey!"
                break
              case 10:
                message = "You've completed 10 assignments. You're building good study habits!"
                break
              case 15:
                message = "You've completed 15 assignments. Your dedication is impressive!"
                break
              case 25:
                message = "You've completed 25 assignments. You're a serious scholar now!"
                break
              case 50:
                message = "You've completed 50 assignments! That's an incredible achievement!"
                break
              case 100:
                title = "MAJOR Achievement Unlocked!"
                message = "You've completed 100 assignments! You're in the academic hall of fame!"
                break
              default:
                message = `You've completed ${milestone} assignments. Keep up the great work!`
            }

            addUniqueNotification({
              id: `achievement-${milestone}-assignments`,
              title,
              message,
              type: "achievement",
              priority: "medium",
              read: false,
              dismissed: false,
            })
          }
        })
      }

      // Fetch user points
      const { data: pointsData, error: pointsError } = await supabase
        .from("user_points")
        .select("*")
        .eq("user_id", user.id)
        .single()

      if (pointsError && pointsError.code !== "PGRST116") {
        console.error("Error fetching user points:", pointsError)
      } else if (pointsData) {
        const currentPoints = pointsData.points
        const pointsMilestones = [50, 100, 250, 500, 1000]

        pointsMilestones.forEach((milestone) => {
          if (
            currentPoints >= milestone &&
            !notificationHistory.achievementMilestones.pointsEarned.includes(milestone)
          ) {
            // Add to history
            setNotificationHistory((prev) => ({
              ...prev,
              achievementMilestones: {
                ...prev.achievementMilestones,
                pointsEarned: [...prev.achievementMilestones.pointsEarned, milestone],
              },
            }))

            let message = ""
            let title = "Points Milestone!"

            switch (milestone) {
              case 50:
                message = "You've earned 50 points! You're off to a great start."
                break
              case 100:
                message = "You've earned 100 points! Keep collecting to unlock more rewards."
                break
              case 250:
                message = "You've earned 250 points! Your hard work is paying off."
                break
              case 500:
                message = "You've earned 500 points! You're a serious point collector now!"
                break
              case 1000:
                title = "MAJOR Points Milestone!"
                message = "You've earned 1000 points! That's an incredible achievement!"
                break
              default:
                message = `You've earned ${milestone} points! Keep up the great work!`
            }

            addUniqueNotification({
              id: `points-milestone-${milestone}`,
              title,
              message,
              type: "achievement",
              actionUrl: "/dashboard/rewards",
              actionText: "View Rewards",
              priority: "medium",
              read: false,
              dismissed: false,
            })
          }
        })
      }
    } catch (error) {
      console.error("Error checking for milestones:", error)
    }
  }, [user, supabase, notificationHistory, addUniqueNotification])

  // Refresh notifications (for deadline-based notifications)
  const refreshNotifications = useCallback(async () => {
    if (!user || !supabase) return

    try {
      // Fetch assignments for deadline notifications
      const { data: assignments, error: assignmentsError } = await supabase
        .from("assignments")
        .select("*")
        .eq("user_id", user.id)
        .eq("completed", false)
        .order("deadline", { ascending: true })

      if (assignmentsError) {
        console.error("Error fetching assignments:", assignmentsError)
      } else if (assignments) {
        const now = new Date()

        // Process assignments for deadline notifications
        assignments.forEach((assignment) => {
          const deadline = new Date(assignment.deadline)
          const daysUntilDeadline = differenceInDays(deadline, now)
          const hoursUntilDeadline = differenceInHours(deadline, now)

          // Create unique IDs for each notification type
          const todayId = `assignment-today-${assignment.id}`
          const tomorrowId = `assignment-tomorrow-${assignment.id}`
          const threeDaysId = `assignment-3days-${assignment.id}`
          const overdueId = `assignment-overdue-${assignment.id}`

          // Assignment due today
          if (
            daysUntilDeadline === 0 &&
            hoursUntilDeadline > 0 &&
            hoursUntilDeadline <= 24 &&
            !notificationHistory.shownNotificationIds.includes(todayId)
          ) {
            addUniqueNotification({
              id: todayId,
              title: "Assignment Due Today!",
              message: `Your assignment "${assignment.title}" is due today. Make sure to complete it on time.`,
              type: "deadline",
              actionUrl: "/dashboard/assignments",
              actionText: "View Assignment",
              priority: "high",
              sourceId: assignment.id,
            })
          }
          // Assignment due tomorrow
          else if (daysUntilDeadline === 1 && !notificationHistory.shownNotificationIds.includes(tomorrowId)) {
            addUniqueNotification({
              id: tomorrowId,
              title: "Assignment Due Tomorrow",
              message: `Your assignment "${assignment.title}" is due tomorrow. Don't leave it to the last minute!`,
              type: "reminder",
              actionUrl: "/dashboard/assignments",
              actionText: "View Assignment",
              priority: "medium",
              sourceId: assignment.id,
            })
          }
          // Assignment due in 3 days
          else if (daysUntilDeadline === 3 && !notificationHistory.shownNotificationIds.includes(threeDaysId)) {
            addUniqueNotification({
              id: threeDaysId,
              title: "Assignment Due Soon",
              message: `Your assignment "${assignment.title}" is due in 3 days. Start working on it now to avoid stress later.`,
              type: "reminder",
              actionUrl: "/dashboard/assignments",
              actionText: "View Assignment",
              priority: "low",
              sourceId: assignment.id,
            })
          }
          // Assignment overdue
          else if (daysUntilDeadline < 0 && !notificationHistory.shownNotificationIds.includes(overdueId)) {
            addUniqueNotification({
              id: overdueId,
              title: "Assignment Overdue!",
              message: `Your assignment "${assignment.title}" was due on ${format(deadline, "MMM d")}. Complete it as soon as possible!`,
              type: "warning",
              actionUrl: "/dashboard/assignments",
              actionText: "View Assignment",
              priority: "high",
              sourceId: assignment.id,
            })
          }
        })
      }

      // Check for milestone achievements
      await checkForMilestones()
    } catch (error) {
      console.error("Error refreshing notifications:", error)
    }
  }, [user, supabase, notificationHistory.shownNotificationIds, addUniqueNotification, checkForMilestones])

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        addNotification,
        markAsRead,
        dismissNotification,
        markAllAsRead,
        clearAllNotifications,
        refreshNotifications,
        // Event-driven notification methods
        notifyAssignmentCompleted,
        notifyPointsEarned,
        notifyRewardRedeemed,
        notifyRewardActivated,
        notifyTaskCompleted,
        notifyGoalProgress,
        notifyGoalCompleted,
        checkForMilestones,
      }}
    >
      {children}
    </NotificationContext.Provider>
  )
}

export function useNotifications() {
  const context = useContext(NotificationContext)
  if (context === undefined) {
    throw new Error("useNotifications must be used within a NotificationProvider")
  }
  return context
}
